import json
import csv
import time
import requests
from datetime import date, datetime as dt
from random import randint
from xbmcgui import Dialog, DialogProgress
from xbmcvfs import translatePath, delete, exists, copy
import sqlite3
import re
import unicodedata
from modules.kodi_utils import get_armani_user, kodi_refresh, notification, local_string as ls, logger
from modules.armani_utils import truncate_complete_sentences

DB = translatePath('special://profile/addon_data/plugin.video.armaniflix/databases/armani.db')
CONFIG = translatePath('special://profile/addon_data/plugin.video.armaniflix/armani.json')
TEMP = translatePath('special://profile/addon_data/plugin.video.armaniflix/temp.json')

PLAYLIST_PATH = translatePath('special://profile/addon_data/plugin.video.armaniflix/playlists.json')

GIT = {
    'config': 'https://sisyphussam.github.io/defaults/config.json',
    'database': 'https://sisyphussam.github.io/defaults/armani.db'
}

MEDIA_TYPES = {
    'movies': ls(32028),
    'tvshows': ls(32029)
}

CATEGORIES = {
    'alpha': ls(33621),
    'genres': ls(33622),
    'decades': ls(33623)
}

SORTS = {
    'rating': ls(33515),
    'votes': ls(33516),
    'year': ls(33517),
    'random': ls(33218)
}

NUM_EXAMPLES = 6
FETCH_LIMIT = 200
PLAYLIST_LIMIT = 100

TMDB_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI1NTFiYWEzYjU4YTM0MmM0NGUwNmM5OGE1NTYwODA4ZiIsInN1YiI6IjYzZWM3ODAzMWYzZ" \
             "TYwMDA3ZmI1ZTQxYSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.YFH_FtAhTLPZcWLKUYvofUKiPsfiHFpN9pZK" \
             "I-M9O7o"
TMDB_HEADERS = {'Authorization': 'Bearer %s' % TMDB_TOKEN, 'accept': 'application/json'}
IMDB_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "DNT": "1",
                "Connection": "close",
                "Upgrade-Insecure-Requests": "1"}

PLAYLIST_MAIN_MENU = {
    'media_types': {'exec': 'select_media_type()', 'label': 33628, 'info': 33629},
    'watched_content': {'exec': 'select_watched_status()', 'label': 33630, 'info': 33631},
    'decades': {'exec': 'select_decades()', 'label': 33632, 'info': 33633},
    'languages': {'exec': 'select_languages()', 'label': 33634, 'info': 33635},
    'genres_any': {'exec': 'select_genres("genres_any")', 'label': 33636, 'info': 33637},
    'genres_all': {'exec': 'select_genres("genres_all")', 'label': 33638, 'info': 33639},
    'genres_none': {'exec': 'select_genres("genres_none")', 'label': 33640, 'info': 33641},
    'search_any': {'exec': 'search_terms("search_any")', 'label': 33649, 'info': 33651},
    'search_all': {'exec': 'search_terms("search_all")', 'label': 33650, 'info': 33652},
    'size_filter': {'exec': 'set_size_filter()', 'label': 33644, 'info': 33645},
    'reset': {'exec': 'reset()', 'label': 33642, 'info': 33643}
}

SIZE_FILTERS = {
    'votes_desc': {'label': 'Highest Vote Count (IMDb)', 'order': 'votes DESC, rating DESC'},
    'votes_asc': {'label': 'Lowest Vote Count (IMDb)', 'order': 'votes ASC, rating DESC'},
    'rating_desc': {'label': 'Highest Rating (IMDb)', 'order': 'rating DESC, votes DESC'},
    'rating_asc': {'label': 'Lowest Rating (IMDb)', 'order': 'rating ASC, votes DESC'},
    'year_asc': {'label': 'Oldest Releases', 'order': 'release_date ASC, votes DESC'},
    'year_desc': {'label': 'Latest Releases', 'order': 'release_date DESC, votes DESC'}
}


def _search_string(s):
    s = unicodedata.normalize('NFD', s)
    s = s.encode('ascii', 'ignore')
    s = s.decode("utf-8")
    s = re.sub(r'[^A-Za-z\d]+', '', s)
    return s


def _db_types_to_where(db_types: str):
    db_types = [t.strip().lower() for t in db_types.split(',')]
    where = ' OR '.join(['db_type = ?'] * len(db_types))
    return where, db_types

    
def run_playlist_command(key):
    exec('self.%s' % PLAYLIST_MAIN_MENU[key]['exec'])
    
    
class ArmaniPlaylist:
    def __init__(self):
        self.user = get_armani_user()
        try:
            with open(PLAYLIST_PATH, 'r') as fp:
                self.playlist = json.load(fp)
            if self.user not in self.playlist:
                self.reset(False)
        except:
            self.playlist = {}
            self.reset(False)
        self.fix_errors()

        armani.cursor.execute('SELECT original_language, year, genre_ids FROM media')
        results = armani.cursor.fetchall()
        languages = list(dict.fromkeys([r[0] for r in results]))
        languages.sort()
        decades = list(dict.fromkeys([10 * int(r[1] / 10) for r in results]))
        decades.sort(reverse=True)
        genre_ids = list(dict.fromkeys(', '.join([r[2] for r in results]).split(', ')))
        genre_ids.sort()
        genre_names = armani.get_genres()
        
        self.languages = [{'label': lang, 'value': lang} for lang in languages]
        self.decades = [{'label': '%d - %d' % (d, d + 9), 'value': str(d)} for d in decades]
        self.genres = [{'label': genre_names[g], 'value': g} for g in genre_ids]
        
    def create_menu(self):
        from modules.kodi_utils import build_url, make_listitem, add_item, sys, set_content, external_browse, set_view_mode, end_directory
        
        handle = int(sys.argv[1])
        playlist = self.get_playlist()
        for key, params in PLAYLIST_MAIN_MENU.items():
            url = build_url({'mode': 'armani.playlist_command', 'exec': params['exec']})
            info = ls(params['info'])
            label = ls(params['label'])
            label2 = ''
            if playlist.get(key):
                if key.startswith('genres_'):
                    label2_list = [i['label'] for i in self.genres if i['value'] in playlist[key]]
                elif key == 'languages':
                    label2_list = [i['label'] for i in self.languages if i['value'] in playlist[key]]
                elif key == 'decades':
                    label2_list = ['%ss' % i['value'] for i in self.decades if i['value'] in playlist[key]]
                elif key == 'size_filter':
                    label2_list = [SIZE_FILTERS[playlist.get('size_filter')]['label']]
                else:
                    label2_list = playlist[key]
                label2 = ' | '.join(label2_list)
                info += '[CR][CR][B]Selected[/B][CR]%s' % ' | '.join(label2_list)
            info += '[CR][CR]' + ls(33646)
            listitem = make_listitem()
            listitem.setLabel(label)
            listitem.setLabel2(label2)
            if label2:
                listitem.setProperty('playlist_value', label2)
            info_tag = listitem.getVideoInfoTag()
            info_tag.setMediaType('program')
            info_tag.setPlot(info)
            add_item(handle, url, listitem, False)
        
        set_content(handle, '')
        end_directory(handle)
        if not external_browse(): set_view_mode('view.main', '')
        
    def set_size_filter(self):
        playlist = self.get_playlist()
        ret = Dialog().contextmenu([s['label'] for s in SIZE_FILTERS.values()])
        if ret < 0:
            if not playlist.get('size_filter'):
                playlist['size_filter_order'] = list(SIZE_FILTERS.keys())[0]
                self.__save()
                kodi_refresh()
            return
        playlist['size_filter'] = list(SIZE_FILTERS.keys())[ret]
        self.__save()
        kodi_refresh()
        
    def select_media_type(self):
        playlist = self.get_playlist()
        values = [['movie'], ['tvshow'], ['movie', 'tvshow']]
        ret = Dialog().contextmenu(['Movies', 'TV Shows', 'Movies & TV Shows'])
        if ret < 0:
            return
        playlist['media_types'] = values[ret]
        self.__save()
        kodi_refresh()
        
    def select_watched_status(self):
        playlist = self.get_playlist()
        values = [['watched', 'unwatched'], ['watched'], ['unwatched']]
        ret = Dialog().contextmenu(['All', 'Watched Only', 'Unwatched Only'])
        if ret < 0:
            return
        playlist['watched_content'] = values[ret]
        self.__save()
        kodi_refresh()
        
    def select_decades(self):
        self.__context_add('decades', self.decades)
        
    def select_languages(self):
        self.__context_add('languages', self.languages)
        
    def select_genres(self, key):
        self.__context_add(key, self.genres)
        
    def __context_add(self, key, items):
        playlist = self.get_playlist()
        items = {i['value']: i['label'] for i in items if i['value'] not in playlist.get(key, [])}
        values = list(items.keys())
        labels = list(items.values())
        
        ret = Dialog().contextmenu([ls(33625)] + labels)
        if ret < 0:
            return
        if ret == 0:
            playlist[key] = []
            self.__save()
            kodi_refresh()
            return
        playlist[key].append(values[ret - 1])
        self.__save()
        kodi_refresh()
        
    def search_terms(self, key):
        playlist = self.get_playlist()
        dlg = Dialog()
        options = [ls(33626)]
        term_count = len(playlist.get(key, []))
        ret = 0
        if term_count > 0:
            options += [ls(33625)]
            if term_count > 1:
                options += [ls(33647) % (t if len(t) < 18 else '%s...' % t[0:15]) for t in playlist[key]]
            ret = dlg.contextmenu(options)
            if ret < 0:
                return
        
        if ret == 0:
            t = dlg.input(ls(33627)).strip().lower()
            if not t:
                return
            playlist[key].append(t)
        elif ret == 1:
            playlist[key] = []
        else:
            index = ret - 2
            playlist[key].pop(index)
            
        self.__save()
        kodi_refresh()
    
    def fix_errors(self):
        pass
            
    def reset(self, refresh=True):
        self.playlist[self.user] = {
            'media_types': ['movie'],
            'watched_content': ['unwatched'],
            'decades': [],
            'languages': [],
            'genres_any': [],
            'genres_all': [],
            'genres_none': [],
            'search_any': [],
            'search_all': [],
            'size_filter_order': 'votes DESC, rating DESC'
        }
        self.__save()
        if refresh:
            kodi_refresh()
            
    def __save(self):
        self.get_playlist()['created'] = dt.now().strftime('%Y-%m-%d %H:%M:%S')
        with open(PLAYLIST_PATH, 'w') as fp:
            json.dump(self.playlist, fp)

    def get_playlist(self):
        return self.playlist[self.user]

        
        
class ArmaniCache:
    """ A database containing all movies and TV shows listed in GitHub CSV files. """
    
    def __init__(self):
        self.config = {}
        self.language = 'en-US'
        self.conn = sqlite3.connect(DB)
        self.cursor = self.conn.cursor()
        self.__load_config()
        
    def __load_config(self):
        if not exists(CONFIG):
            with open(CONFIG, 'w') as fp:
                json.dump({}, fp)
            self.config = {}
    
        with open(CONFIG, 'r') as fp:
            self.config = json.load(fp)
            
        if any(s not in self.config for s in ('tmdb_token', 'imdb_lists', 'genres', 'languages', 'countries')):
            self.download_default_config()
            self.download_default_database()

    def __save_config(self):
        with open(CONFIG, 'w') as fp:
            json.dump(self.config, fp, indent=2)
            
    def get_menu(self):
        return self.config.get('menu') or {
            'movies': {'alpha': {}, 'decades': {}, 'genres': {}},
            'tvshows': {'alpha': {}, 'decades': {}, 'genres': {}}
        }
    
    def get_genres(self):
        return self.config.get('genres', {})
    
    def download_defaults(self, silent=False) -> bool:
        """ Get configuration data and database from GitHub
        
        Returns: True if successful, False otherwise
        
        """
        download_db, download_config = True, True
        if not silent:
            ret = Dialog().yesnocustom(
                'RESTORE DEFAULTS',
                'What would you like to restore?[CR][COLOR yellow](Note: updates will be lost)[/COLOR]',
                'Both', 'Database', 'Config'
            )
            if ret < 0:
                return False
            download_db = ret == 0 or ret == 2
            download_config = ret == 1 or ret == 2
            
        success = True
        if download_config:
            if not self.download_default_config():
                notification('[COLOR red]Failed to restore config[/COLOR]')
                success = False
            else:
                notification('[COLOR lime]Config restored[/COLOR]')
        if download_db:
            if not self.download_default_database():
                notification('[COLOR red]Failed to restore database[/COLOR]')
                success = False
            else:
                notification('[COLOR lime]Database restored[/COLOR]')
        
        return success
        
    def download_default_config(self) -> bool:
        """ Download configuration file from GitHub
        
        Returns: True if successful, False otherwise
        
        """
        response = requests.get(GIT['config'])
        if response.status_code != 200:
            return False
        data = response.json()
        self.config['tmdb_token'] = data['tmdb_token']
        self.config['imdb_lists'] = data['imdb_lists']
        self.config['genres'] = data['genres']
        self.config['languages'] = data['languages']
        self.config['countries'] = data['countries']
        self.__save_config()
        return True
    
    def download_default_database(self) -> bool:
        """ Download database from GitHub
        
        Returns: True if successful, False otherwise
        
        """
        response = requests.get(GIT['database'])
        if response.status_code != 200:
            return False
        
        self.conn.close()
        delete(DB)
        with open(DB, 'wb') as out_file:
            out_file.write(response.content)
            
        self.conn = sqlite3.connect(DB)
        self.cursor = self.conn.cursor()
        self.__setup_menu()
        return True

    def download_updates(self) -> bool:
        """ Fetches IMDb lists (config) and updates the database.
        
        If an entry exists in the database, then its rating, votes, title, sort_title, and
        TV show status (if applicable) are updated. Otherwise, a new entry is added to
        the database.

        Returns: True if all database rows were updated (i.e., not canceled), False otherwise

        """
        def _row_error(msg):
            logger('ArmaniFlix / Row error', '%s - %s' % (msg, str(row)))
    
        lists = {k: v for k, v in self.config['imdb_lists'].items() if v}
        prog = DialogProgress()
        prog.create('UPDATING DATABASE', 'Initializing...')
        all_rows = []
    
        session = requests.Session()
        i = 0
        for list_name, list_id in lists.items():
            prog.update(int(100 * i / len(lists)), 'Fetching IMDb list:[CR]     [COLOR yellow]%s[/COLOR]' % list_name)
            i += 1
            csv_url = 'https://www.imdb.com/list/%s/export?ref_=ttls_exp' % list_id
            time.sleep(randint(1, 3))
            download = session.get(csv_url, headers=IMDB_HEADERS)
            if download.status_code != 200:
                Dialog().ok('CSV ERROR', 'The CSV for "%s" could not be downloaded' % list_name)
                logger('IMDB Import (%s)' % list_name, 'Error retrieving CSV')
                return False
            decoded_content = download.content.decode('utf-8')
            rows = list(csv.reader(decoded_content.splitlines(), delimiter=','))
            rows.pop(0)  # remove header row
            if not rows:
                continue
            all_rows.extend(rows)
            if prog.iscanceled():
                return False

        failure_count, new_count, delete_count = 0, 0, 0
        if all_rows:
            self.cursor.execute('SELECT imdb_id FROM media')
            delete_ids = [r[0] for r in self.cursor.fetchall() if r[0] not in [i[1] for i in all_rows]]
            delete_count = len(delete_ids)
            for delete_id in delete_ids:
                self.cursor.execute('DELETE FROM media WHERE imdb_id = ?', (delete_id,))
            self.conn.commit()
    
        valid_genres = self.config['genres']
        i = 0
        canceled = False
        
        for row in all_rows:
            if prog.iscanceled():
                canceled = True
                break
            prog_string = 'Fetching metadata for entry %d of %d.' % (i + 1, len(all_rows))
            if failure_count > 0:
                prog_string += '[CR][COLOR red](Failed to add %d entries)[/COLOR]' % failure_count
            
            prog.update(int(100 * i / len(all_rows)), prog_string)
            i += 1

            imdb_id = row[1]
            imdb_rating = float(row[8]) if row[8] else 0.0
            imdb_votes = int(row[12]) if row[12] else 0
            comment = [s.strip() for s in row[4].split('||')]
            title, sort_title, genre_ids = None, None, None
            if len(comment) == 3:
                sort_title = comment[0].strip().upper()
                title = comment[1].strip()
                genre_ids = [g.lower().strip() for g in comment[2].split(',')]
                if not title:
                    _row_error('Invalid title')
                    failure_count += 1
                    continue
                if not sort_title:
                    _row_error('Invalid sort title')
                    failure_count += 1
                    continue
                if any(g not in valid_genres for g in genre_ids):
                    _row_error('Invalid genre')
                    failure_count += 1
                    continue
            
            self.cursor.execute('SELECT extra_info, db_type, tmdb_id FROM media where imdb_id = ?', (imdb_id,))
            existing = self.cursor.fetchone()
            if existing:
                if not title:
                    self.cursor.execute('UPDATE media SET rating = ?, votes = ? WHERE imdb_id = ?',
                                        (imdb_rating, imdb_votes, imdb_id))
                else:
                    alpha = sort_title[0] if sort_title[0].isalpha() else '#'
                    db_type = existing[1]
                    tmdb_id = existing[2]
                    extra_info = json.loads(existing[0])
                    extra_info['genres'] = [valid_genres[g] for g in genre_ids]
                    if db_type == 'tvshow' and extra_info['status'] == 'Returning Series':
                        url = 'https://api.themoviedb.org/3/tv/%d?language=en-US' % tmdb_id
                        tmdb_response = session.get(url, headers=TMDB_HEADERS)
                        if tmdb_response.status_code != 200:
                            _row_error('Unable to retrieve TMDb details')
                        else:
                            tmdb_details = tmdb_response.json()
                            extra_info['status'] = tmdb_details['status']
                            extra_info['num_seasons'] = tmdb_details['number_of_seasons']
                            extra_info['num_episodes'] = tmdb_details['number_of_episodes']
                    self.cursor.execute("""
                        UPDATE media
                        SET title = ?, sort_title = ?, starting_letter = ?, genre_ids = ?, rating = ?, votes = ?,
                            extra_info = ?
                        WHERE imdb_id = ?
                    """, (title, sort_title, alpha, ', '.join(genre_ids), imdb_rating, imdb_votes,
                          json.dumps(extra_info), imdb_id))
            else:
                if self.insert_or_update(imdb_id, False, session, title, sort_title, genre_ids):
                    new_count += 1
                    # Commit occasionally in case of crash
                    if new_count % 100 == 0:
                        self.conn.commit()
                else:
                    failure_count += 1
                
        self.conn.commit()
        self.conn.execute('VACUUM')
        session.close()
        self.__setup_menu()
        prog.close()
        status_string = '[CR][COLOR lime]%d added[/COLOR]' % new_count
        if delete_count > 0:
            status_string += ' | [COLOR yellow]%d removed[/COLOR]' % delete_count
        if failure_count > 0:
            status_string += ' | [COLOR red]%d failed[/COLOR]' % failure_count
        
        if canceled:
            Dialog().ok('UPDATE INCOMPLETE', 'The update was cancelled.' + status_string)
            return False
        
        Dialog().ok('UPDATE COMPLETE', 'The update has completed.' + status_string)
        return True
        
    def insert_or_update(self, imdb_id: str, commit=True, session=None, title: str = None, sort_title: str = None,
                         genre_ids=None):
        """ Insert new entries or update existing entries.
        
        All metadata will be downloaded from IMDb and TMDb.

        Args:
            imdb_id: tt#######
            commit: Commit changes to the database?
            session: requests.Session
            title: If not set, title will be obtained from IMDb
            sort_title: If not set, sort_title will be obtained from title
            genre_ids: If not set, genre_ids will be obtained from IMDb

        Returns: True if no error occurred, False otherwise

        """
        from modules.kodi_utils import notification
        from modules.armani_utils import get_sort_title
        
        def _get_tmdb(url_tail):
            url = 'https://api.themoviedb.org/3/' + url_tail
            tmdb_response = session.get(url, headers=TMDB_HEADERS)
            if tmdb_response.status_code != 200:
                raise ValueError('Unable to retrieve: %s - %s' % (url, tmdb_response.text))
            return tmdb_response.json()
        
        def _error(msg):
            notification(32760)
            logger('ArmaniFlix / add_entry[%s]' % imdb_id, str(msg))
        
        if not session:
            session = requests.Session()
            
        # Get IMDb data
        response = session.get('https://www.imdb.com/title/%s' % imdb_id, headers=IMDB_HEADERS)
        if response.status_code != 200:
            _error('Unable to retrieve IMDB details')
            return False
        json_text = response.text.split('{"props":{"pageProps"')[1].split('"aboveTheFoldData":')[1]
        json_text = json_text.split(',"mainColumnData":{')[0]
        imdb_data = json.loads(json_text)
        
        # Details from IMDb data
        if not title:
            title = imdb_data['titleText']['text']
        if not sort_title:
            sort_title = get_sort_title(title)
        alpha = sort_title[0] if sort_title[0].isalpha() else '#'
        if not genre_ids:
            imdb_genres = {
                'Action': 'act', 'Adult': 'adu', 'Adventure': 'adv', 'Animation': 'ani', 'Biography': 'bio',
                'Comedy': 'com', 'Crime': 'cri', 'Documentary': 'doc', 'Drama': 'dra', 'Family': 'fam',
                'Fantasy': 'fan', 'Film Noir': 'fil', 'Game Show': 'gam', 'History': 'his', 'Horror': 'hor',
                'Musical': 'mus', 'Mystery': 'mys', 'News': 'new', 'Reality-TV': 'rea', 'Romance': 'rom',
                'Sci-Fi': 'sci', 'Short': 'sho', 'Sport': 'spo', 'Talk-Show': 'tal', 'Thriller': 'thr',
                'War': 'war', 'Western': 'wes'
            }
            genre_ids = [imdb_genres[g['text']] for g in imdb_data['genres']['genres']]
        genre_ids = [g for g in genre_ids if g in self.config['genres']]
        db_type = 'movie' if imdb_data['titleType']['id'] in ('movie', 'tvMovie', 'short') else 'tvshow'
        media_type = 'movie' if db_type == 'movie' else 'tv'
        imdb_rating = imdb_data['ratingsSummary']['aggregateRating']
        imdb_votes = imdb_data['ratingsSummary']['voteCount']
        plot = truncate_complete_sentences(imdb_data['plot']['plotText']['plainText'])
        
        # Get tmdb data
        tmdb_details, tmdb_release_dates, tmdb_credits, tmdb_ratings = None, None, None, None
        try:
            tmdb_find = _get_tmdb('find/%s?external_source=imdb_id' % imdb_id)
            found = tmdb_find['movie_results'] if db_type == 'movie' else tmdb_find['tv_results']
            if not found:
                _error('TMDB ID not found')
                return False
            tmdb_id = found[0]['id']
            tmdb_details = _get_tmdb('%s/%d?language=en-US' % (media_type, tmdb_id))
            if db_type == 'movie':
                tmdb_credits = _get_tmdb('movie/%d/credits' % tmdb_id)
                tmdb_release_dates = _get_tmdb('movie/%s/release_dates' % tmdb_id)['results']
            else:
                tmdb_credits = _get_tmdb('tv/%d/aggregate_credits' % tmdb_id)
                tmdb_ratings = _get_tmdb('tv/%s/content_ratings' % tmdb_id)['results']
                
        except ValueError as e:
            _error(e)
            return False
        
        # Details from TMDb data
        original_language = self.config['languages'][tmdb_details['original_language']]
        extra_info = {
            'genres': [self.config['genres'][g] for g in genre_ids],
            'countries': '',
            'num_episodes': 0,
            'num_seasons': 0,
            'status': tmdb_details['status']
        }
        
        # Movie details from TMDb data
        director_jobs = ('director', 'directed by')
        writer_jobs = ('author', 'book', 'comic book', 'graphic novel', 'novel', 'original story', 'screenplay',
                       'screenplay by', 'short story', 'story', 'story by', 'writer', 'written by')
        if db_type == 'movie':
            # Movie credits
            cast = tmdb_credits['cast']
            crew = sorted(tmdb_credits['crew'], key=lambda d: d['popularity'], reverse=True)
            directors = [p for p in crew if p['job'].lower() in director_jobs]
            creators = []
            writers = [p for p in crew if p['job'].lower() in writer_jobs]
            
            release_dates = []
            for d in tmdb_release_dates:
                release_dates.extend([rd['release_date'][:10] for rd in d['release_dates']])
            release_date = min(release_dates)
            runtime = tmdb_details['runtime']
    
            release_dates = {r['iso_3166_1']: r['release_dates'] for r in tmdb_release_dates}
            if 'US' not in release_dates:
                mpaa = 'NR'
            else:
                mpaa_list = [r['certification'] for r in release_dates['US'] if r['certification']]
                mpaa = 'NR' if not mpaa_list else mpaa_list[0]
    
            extra_info['countries'] = [c['name'] for c in tmdb_details['production_countries']]
            
        # TV details from TMDb data
        else:
            # TV credits
            cast = sorted(tmdb_credits['cast'], key=lambda d: d['total_episode_count'], reverse=True)
            cast = [c for c in cast if c['order'] < 8]
            for c in cast:
                c['character'] = sorted(c['roles'], key=lambda d: d['episode_count'], reverse=True)[0][
                    'character']
            creators = [{'id': c['id'], 'name': c['name']} for c in tmdb_details.get('created_by', [])]
            directors = []
            writers = []
            for c in tmdb_credits['crew']:
                for j in c['jobs']:
                    if j['job'].lower() in director_jobs:
                        directors.append(
                            {'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
                    elif j['job'].lower() in writer_jobs:
                        writers.append({'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
            directors = [{'id': p['id'], 'name': p['name']}
                         for p in sorted(directors, key=lambda d: d['episode_count'], reverse=True)][0:2]
            writers = [{'id': p['id'], 'name': p['name']}
                       for p in sorted(writers, key=lambda d: d['episode_count'], reverse=True)][0:2]
            
            release_date = tmdb_details['first_air_date']
            if tmdb_details['episode_run_time']:
                runtime = tmdb_details['episode_run_time'][0]
            else:
                episode_details = _get_tmdb('tv/%s/season/1/episode/1?language=en-US' % tmdb_id)
                runtime = episode_details['runtime'] or 0
    
            certs = {r['iso_3166_1']: r['rating'] for r in tmdb_ratings if r['rating']}
            mpaa = 'NR' if 'US' not in certs else certs['US']
            extra_info['countries'] = [self.config['countries'][c] for c in tmdb_details['origin_country']]
            extra_info['num_seasons'] = tmdb_details['number_of_seasons']
            extra_info['num_episodes'] = tmdb_details['number_of_episodes']

        # Finalize credits
        cast = [{'id': p['id'], 'name': p['name'], 'role': p['character'], 'order': p['order']} for p in cast]
        director = [{'id': p['id'], 'name': p['name']} for p in directors]
        writer = [{'id': p['id'], 'name': p['name']} for p in writers]
        cast = list({p['id']: p for p in cast}.values())
        cast = sorted(cast, key=lambda d: d['order'])
        director = list({p['id']: p for p in director}.values())
        writer = list({p['id']: p for p in writer}.values())
        all_credits = {
            'director': director[0:2],
            'creator': creators[0:2],
            'writer': writer[0:2],
            'cast': cast[0:8]
        }
        
        creator = [p['name'] for p in all_credits.get('creator', [])]
        director = [p['name'] for p in all_credits.get('director', [])]
        writer = [p['name'] for p in all_credits.get('writer', [])]
        cast = [p['name'] for p in all_credits.get('cast', [])]

        credit_lines = []
        credit_string = '[CR][B]%s:[/B] %s'
        if creator:
            credit_lines.append(credit_string % ('Creator', ', '.join(creator)))
        elif director:
            credit_lines.append(credit_string % ('Director', ', '.join(director)))
        if cast:
            credit_lines.append(credit_string % ('Stars', ', '.join(cast[0:3])))
        plot += '[CR]' + ''.join(credit_lines)
        
        search_words = [title, sort_title] + creator + director + writer + cast
        search_words = '|'.join(list(dict.fromkeys([_search_string(w) for w in search_words])))

        self.cursor.execute(
            'INSERT OR REPLACE INTO media VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            (imdb_id, db_type, tmdb_id, title, sort_title, alpha, mpaa, runtime, imdb_rating, imdb_votes, plot,
             original_language, release_date, int(release_date[:4]), ', '.join(genre_ids), search_words,
             json.dumps(extra_info), str(date.today())))
        if commit:
            self.conn.commit()
        return True
    
    def __setup_menu(self):
        def _menu_create(menu_id, menu_name):
            results = [{'imdb_id': r[0], 'title': r[1], 'sort_title': r[2], 'release_date': r[3]}
                       for r in self.cursor.fetchall()]
            if not results:
                return None
        
            samples = results[0:10]
            samples.sort(key=lambda x: x['release_date'])
            samples.sort(key=lambda x: x['sort_title'])
            return {
                'id': menu_id,
                'name': menu_name,
                'where': 'WHERE db_type = "%s" AND (%s)' % (db_type, filter_string),
                'count': len(results),
                'summary': '[CR]'.join([s['title'] for s in samples])
            }
    
        menu = {'movies': {'genres': {}, 'decades': {}, 'alpha': {}},
                'tvshows': {'genres': {}, 'decades': {}, 'alpha': {}}}
        sql_select = 'SELECT imdb_id, title || " (" || year || ")", sort_title, release_date ' \
                     'FROM media WHERE db_type = ? AND %s ORDER BY RANDOM()'
        valid_genres = self.config['genres']
        for db_type in ('movie', 'tvshow'):
            menu_type = 'movies' if db_type == 'movie' else 'tvshows'
            for g in valid_genres:
                filter_string = 'genre_ids LIKE ' + '"%' + g + '%"'
                self.cursor.execute(sql_select % 'genre_ids LIKE ?', (db_type, '%' + g + '%'))
                menu_entry = _menu_create(g, valid_genres[g])
                if menu_entry:
                    menu[menu_type]['genres'][g] = menu_entry
        
            for a in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
                filter_string = 'starting_letter = "%s"' % a
                self.cursor.execute(sql_select % 'starting_letter = ?', (db_type, a))
                menu_entry = _menu_create(a, a)
                if menu_entry:
                    menu[menu_type]['alpha'][a] = menu_entry
        
            for d in (1900, 1910, 1920, 1930, 1940, 1950, 1960, 1970, 1980, 1990, 2000, 2010, 2020, 2030):
                filter_string = 'year >= %d AND year <= %d' % (d, d + 9)
                self.cursor.execute(sql_select % 'year >= ? AND year <= ?', (db_type, d, d + 9))
                menu_entry = _menu_create(str(d), '%d - %d' % (d, d + 9))
                if menu_entry:
                    menu[menu_type]['decades'][str(d)] = menu_entry
        self.config['menu'] = menu
        self.__save_config()
    
    def get_meta_list(self, where="", where_values=None, sort_order='sort_title, release_date'):
        if where_values is None:
            where_values = ()
        
        try:
            self.cursor.execute(f"""
                SELECT
                    imdb_id, db_type, tmdb_id, title, sort_title, mpaa, runtime, rating, votes, plot,
                    original_language, release_date, year, genre_ids, search_string, extra_info,
                    date_added, starting_letter
                FROM
                    media
                {where}
                ORDER BY
                    {sort_order}
            """, where_values)
        except sqlite3.Error:
            return []
        
        meta = []
        for row in self.cursor.fetchall():
            extra_info = json.loads(row[15])
            
            meta.append({
                'imdb_id': row[0],
                'db_type': row[1],
                'media_type': row[1],
                'tmdb_id': row[2],
                'title': row[3] if row[10] == 'English' else '%s [COLOR grey][%s][/COLOR]' % (row[3], row[10]),
                'rootname': '%s (%d)' % (row[3], row[12]),
                'sort_title': row[4],
                'starting_letter': row[17],
                'mpaa': row[5],
                'duration': row[6],
                'rating': row[7],
                'votes': row[8],
                'plot': row[9],
                'original_language': row[10],
                'premiered': row[11],
                'year': row[12],
                'decade': int(row[12] / 10) * 10,
                'genre_ids': row[13],
                'search_string': row[14],
                'original_title': row[3],
                'date_added': row[16],
                'genre': ', '.join(extra_info['genres']),
                'country': extra_info['countries'],
                'cast': '',
                'director': '',
                'writer': '',
                'keywords': '',
                'total_seasons': extra_info['num_seasons'],
                'total_aired_eps': extra_info['num_episodes']
            })
        return meta

    def fetch(self, params):
        db_types = params.get('db_types', 'movie, movie_set, tvshow')
        values = [t.strip().lower() for t in db_types.split(',')]
        where = '(%s)' % ' OR '.join(['db_type = ?'] * len(values))
    
        if 'years' in params:
            years = params['years'].split('-', maxsplit=1)
            if len(years) == 1:
                year_where = '(year = ?)'
                year_values = [int(years)]
            else:
                year_where = "(year >= ? AND year <= ?)"
                year_values = [int(years[0]), int(years[1])]
        
            values += year_values
            where += ' AND %s' % year_where
    
        if 'alpha' in params:
            values += [params['alpha'].upper()]
            where += ' AND starting_letter = ?'
    
        if 'genres' in params:
            values += ['%' + g.strip() + '%' for g in params['genres'].split(',')]
            where += ' AND %s' % ' AND '.join(['genre_ids LIKE ?'])
    
        if 'query' in params:
            values += ['%' + _search_string(params['query']) + '%']
            where += ' AND search_string LIKE ?'
    
        sort_order = params.get('sort_order', 'sort_title, release_date')
        if 'limit' not in sort_order.lower():
            sort_order += ' LIMIT %d' % FETCH_LIMIT
    
        return self.get_meta_list('WHERE %s' % where, values, sort_order)

    def can_fetch(self, params):
        return len(self.fetch(params)) > 0
    
    def get_meta_tmdb(self, db_type, tmdb_id):
        results = self.get_meta_list('WHERE db_type = ? AND tmdb_id = ?', (db_type, tmdb_id))
        return {} if not results else results[0]
    
    def get_meta_action(self, action):
        from caches.favorites import Favorites
        from modules.watched_status import armani_get_watch_history
        from modules.kodi_utils import get_armani_user
        results = []
        if action == 'favorites':
            results = [self.get_meta_tmdb(r[1], r[0]) for r in Favorites().get_all_favorites()]
        elif action == 'watched':
            results = [self.get_meta_tmdb(r[1], r[0]) for r in armani_get_watch_history()]
        elif action == 'playlist':
            results = self.get_meta_playlist()
        
        return [r for r in results if r]
    
    def get_meta_playlist(self):
        from modules.watched_status import armani_remove_watched, armani_remove_unwatched
        playlist = ArmaniPlaylist().get_playlist()

        filters = []
        values = []
        if playlist.get('media_types'):
            filters.append('db_type IN (%s)' % ', '.join(['?'] * len(playlist['media_types'])))
            values.extend(playlist['media_types'])
        if playlist.get('genres_all'):
            filters.append(' AND '.join(['genre_ids LIKE ?'] * len(playlist['genres_all'])))
            values.extend(['%' + g + '%' for g in playlist['genres_all']])
        if playlist.get('genres_any'):
            filters.append(' OR '.join(['genre_ids LIKE ?'] * len(playlist['genres_any'])))
            values.extend(['%' + g + '%' for g in playlist['genres_any']])
        if playlist.get('genres_none'):
            filters.append(' AND '.join(['genre_ids NOT LIKE ?'] * len(playlist['genres_none'])))
            values.extend(['%' + g + '%' for g in playlist['genres_none']])
        if playlist.get('decades'):
            filters.append(' OR '.join(['(year >= ? AND year <= ?)'] * len(playlist['decades'])))
            for d in playlist['decades']:
                values.extend([int(d), int(d) + 9])
        if playlist.get('languages'):
            filters.append(' OR '.join(['original_language = ?'] * len(playlist['languages'])))
            values.extend(playlist['languages'])
        if playlist.get('search_any'):
            filters.append(' OR '.join(['search_string LIKE ?'] * len(playlist['search_any'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_any']])
        if playlist.get('search_all'):
            filters.append(' AND '.join(['search_string LIKE ?'] * len(playlist['search_all'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_all']])

        s_filter = '' if not filters else 'WHERE %s' % ' AND '.join('(%s)' % f for f in filters)
        order = SIZE_FILTERS[playlist.get('size_filter', 'votes_desc')]['order']
        
        results = self.get_meta_list(s_filter, values, order)
        if 'unwatched' not in playlist['watched_content']:
            results = armani_remove_unwatched(results)
        elif 'watched' not in playlist['watched_content']:
            results = armani_remove_watched(results)
        else:
            results = armani_remove_watched(results, playlist['created'])
            
        results = results[0:PLAYLIST_LIMIT]
        results.sort(key=lambda x: x['premiered'])
        results.sort(key=lambda x: x['sort_title'])
        return results
    
    def get_header(self, main_key, category_key=None, sort_type=""):
        """ Returns Content Type / Category / Category Key [sort type] header

        Examples:
            get_header('movies_genres')
            get_header('movies_alpha', 'A')
            get_header('movies_decades', 1920, 'year asc')

        Args:
            main_key: movies_genres, tvshows_decades, movies_alpha, etc.
            category_key: action, 1960, #, etc. (optional)
            sort_type: rating, votes, year asc, year desc, random (optional)

        Returns:
            The header associated with the main key, category key, and sort type

        """
        content_type, category = main_key.split('_')
        h = [MEDIA_TYPES[content_type], CATEGORIES[category]]
        header = '%s / %s' % (h[0], h[1])
        if category_key is not None:
            header += ' / %s' % self.get_menu()[content_type][category][category_key]['name']
            if sort_type in SORTS:
                header += ' [%s]' % SORTS[sort_type].lower()
        return header
    
    def get_list(self, main_key):
        """
        Returns a dict containing the title, summary and count associated with the specified key
        (used for menu InfoLabels).

        Example:
            get_list('tvshows_decades')

        Args:
            main_key: movies_genres, tvshows_decades, movies_alpha, etc.

        Returns:
            A dict containing key, title, summary, and count. For example:

            {'key': '1980', 'title': '1980 - 1989', 'summary': EXAMPLE_LIST, 'count': NUM_RESULTS}
        """
        content_type, category = main_key.split('_')
        m = self.get_menu()[content_type][category]
        
        return {k: {'key': k, 'title': v['name'], 'summary': v['summary'],
                    'count': v['count'], 'where': v['where']} for k, v in m.items()}
    
    def get_content(self, params):
        content_type, category = params['action'].split('_')
        m = self.get_menu()[content_type][category][str(params['value'])]
        order_str = 'sort_title, release_date'
        if 'order' in params:
            order_str = params['order']
            if 'limit' in params:
                order_str += ' LIMIT ' + params['limit']
        return self.get_meta_list(m['where'], sort_order=order_str)
    
    def fetch_hash(self, imdb_id) -> str:
        """
        Return the saved hash associated with the specified IMDb id if it exists.
        (A saved hash will have a higher priority when sources are generated.)

        Args:
            imdb_id: the IMDb id (e.g., tt0095016)

        Returns:
            The hash string if it exists, empty string otherwise
        """
        hashes = self.config.get('hashes', {})
        return "" if imdb_id not in hashes else hashes[imdb_id]
    
    def save_hash(self, imdb_id, source):
        """
        Store a hash from a source in the database (one hash per IMDb ID).
        (A saved hash will have a higher priority when sources are generated.)

        Args:
            imdb_id: the IMDb id (e.g., tt0095016)
            source: a dict containing a 'hash' value
        """
        if 'hashes' not in self.config:
            self.config['hashes'] = {}
        self.config['hashes'][imdb_id] = source['hash']
        self.__save_config()


armani = ArmaniCache()
