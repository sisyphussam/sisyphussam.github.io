# -*- coding: utf-8 -*-
from xbmc import executebuiltin

executebuiltin('RunPlugin(plugin://plugin.video.armaniflix/?mode=kodi_refresh)')
