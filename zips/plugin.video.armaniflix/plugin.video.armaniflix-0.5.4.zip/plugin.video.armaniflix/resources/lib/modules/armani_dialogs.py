from xbmcgui import Dialog, ListItem
from xbmc import executebuiltin
from modules.kodi_utils import logger, local_string as ls, notification, close_all_dialog, build_url
from typing import List


class KeyMenu:
    def __init__(self, heading, menu_type=0, preselect_key=None):
        """ Create a dictionary menu (selection returns the key).

        Args:
            heading: dialog heading
            menu_type: [opt] 0 - simple menu, 1 - detail menu, 2 - double menu
            preselect_key: [opt] string - the key of the preselected item
        """
        self.heading = heading
        self.dialog = Dialog()
        
        if menu_type == 0:
            self.use_details = False
            self.menu_name = 'menu'
            self.max_rows = 11
        elif menu_type == 1:
            self.use_details = True
            self.menu_name = 'detail'
            self.max_rows = 11
        else:
            self.use_details = True
            self.menu_name = 'double'
            self.max_rows = 8
        
        self.items = {}
        self.preselect_key = preselect_key
        self.preselect = -1
        self.label_formats = (
            ('[COLOR white]%s[/COLOR]', '[COLOR lightyellow]%s[/COLOR]'),
            ('[COLOR yellow]%s[/COLOR]', '[COLOR grey][I]%s[/I][/COLOR]'),
            ('[COLOR orange]%s[/COLOR]', '[COLOR grey][I]%s[/I][/COLOR]'),
            ('[COLOR red]%s[/COLOR]', '[COLOR grey][I]%s[/I][/COLOR]')
        )
        
    def add_item(self, key: str, label: str, label2: str = "", info: str = "", format_index=0, visible=True):
        fmt1, fmt2 = self.label_formats[format_index]
        list_item = ListItem(fmt1 % label, offscreen=True)
        if label2:
            list_item.setLabel2(fmt2 % label2)
        if info:
            list_item.setProperty('info', info)
        self.items[key] = {'list_item': list_item, 'value_format': fmt2, 'visible': visible}
        if key == self.preselect_key:
            self.preselect = len(self.items) - 1
        
    def set_value(self, key: str, value: str):
        fmt = self.items[key]['value_format']
        self.items[key]['list_item'].setLabel2('' if not value else fmt % value)
        
    def get_label2(self, key: str):
        return self.items[key]['list_item'].getLabel2()
        
    def set_info(self, key: str, info: str):
        self.items[key]['list_item'].setProperty('info', info)
        
    def set_preselect(self, key: str):
        keys = list(self.items.keys())
        self.preselect = -1 if key not in keys else keys.index(key)
        
    def set_visible(self, key: str, visible: bool):
        self.items[key]['visible'] = visible
        
    def select(self):
        keys = list(self.items.keys())
        list_items = [v['list_item'] for v in self.items.values() if v['visible']]
        menu_name = '%s%d' % (self.menu_name, min(self.max_rows, len(list_items)))
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        i = self.dialog.select(self.heading.upper(), list_items, 0, self.preselect, self.use_details)
        executebuiltin('ClearProperty(select_type,home)')
        if i < 0:
            return None
        self.preselect = i
        return keys[i]
    
    
def numeric_date(heading, default=""):
    executebuiltin('SetProperty(numeric_header,%s,home)' % heading)
    value = Dialog().numeric(1, 'Day/Month/Year', default)
    executebuiltin('ClearProperty(numeric_header,home)')
    return value


def numeric(heading, message, default="", hidden=False) -> str:
    executebuiltin('SetProperty(numeric_header,%s,home)' % heading)
    value = Dialog().numeric(0, message, default, hidden)
    executebuiltin('ClearProperty(numeric_header,home)')
    return value


def _launch_menu(menu_name, heading, items, preselect, multi=False, use_details=False):
    if preselect is None:
        preselect = [] if multi else -1
    executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
    if multi:
        ret = Dialog().multiselect(heading, items, 0, preselect, use_details)
    else:
        ret = Dialog().select(heading.upper(), items, 0, preselect, use_details)
    executebuiltin('ClearProperty(select_type,home)')
    return ret


def menu(heading, labels, preselect=None, multi=False, max_rows=11):
    menu_name = 'menu%d' % min(max_rows, len(labels))
    return _launch_menu(menu_name, heading, labels, preselect, multi)


def detail_menu(heading, items: List[ListItem], preselect=None, multi=False):
    menu_name = 'detail%d' % max(2, min(11, len(items)))
    return _launch_menu(menu_name, heading, items, preselect, multi, True)


def double_line_menu(heading, items: List[ListItem], preselect=None, multi=False):
    menu_name = 'double%d' % min(8, len(items))
    return _launch_menu(menu_name, heading, items, preselect, multi, True)


def info_menu(heading, list_items, preselect=-1):
    executebuiltin('SetProperty(select_type,info_select,home)')
    i = Dialog().select(heading.upper(), list_items, 0, preselect)
    executebuiltin('ClearProperty(select_type,home)')
    return i


def alpha_menu(heading, labels, preselect=-1):
    import math
    num_rows = min(5, math.ceil(len(labels) / 6.0))
    menu_name = 'alpha%d' % num_rows
    return _launch_menu(menu_name, heading, labels, preselect)


def genre_menu(heading, labels, preselect=None, multi=False):
    import math
    num_rows = min(8, math.ceil(len(labels) / 4.0))
    menu_name = 'genres%d' % num_rows
    return _launch_menu(menu_name, heading, labels, preselect, multi)


def decade_menu(heading, labels, preselect, multi=False):
    import math
    num_rows = min(4, math.ceil(len(labels) / 4.0))
    menu_name = 'decades%d' % num_rows
    return _launch_menu(menu_name, heading, labels, preselect, multi)


def year_range(default_range=None, valid_years=None):
    from datetime import date
    from modules.armani_utils import int_to_bounds

    if not valid_years:
        valid_years = range(1900, 1 + date.today().year)

    if not default_range:
        min_year, max_year = valid_years[0], valid_years[-1]
    else:
        min_year = int_to_bounds(default_range[0], valid_years[0], valid_years[-1])
        max_year = int_to_bounds(default_range[1], valid_years[0], valid_years[-1])

    pre = -1 if min_year not in valid_years else valid_years.index(min_year)
    j = menu('Select First Year', [str(y) for y in valid_years], pre)
    if j < 0:
        return min_year, max_year
    min_year, max_year = valid_years[j], valid_years[-1]
    years = [y for y in valid_years if y >= min_year]
    if len(years) > 1:
        j = menu('Select Last Year', [str(y) for y in years])
        if j > -1:
            max_year = years[j]

    return min_year, max_year


def rating_range(min_rating=None):
    ratings = [0.0] + [i / 10.0 for i in range(50, 91)]
    max_rating = 10.0
    if min_rating not in ratings:
        min_rating = 0.0

    i = menu('Minimum Rating', [str(r) for r in ratings], ratings.index(min_rating))
    if i > -1:
        min_rating = ratings[i]
    if min_rating < 9.0:
        start_max = 50 if min_rating == 0.0 else int(min_rating * 10)
        max_ratings = [i / 10.0 for i in range(start_max, 91)] + [10]
        max_ratings.reverse()
        i = menu('Maximum Rating', [str(r) for r in max_ratings], 0)
        max_rating = 10.0 if i < 0 else max_ratings[i]

    if min_rating == 0.0:
        min_rating = None
    if max_rating == 10.0:
        max_rating = None

    return min_rating, max_rating


def vote_range(min_votes=None, max_votes=None):
    votes = [0, 250, 500, 750,
             1000, 2500, 5000, 7500,
             10000, 25000, 50000, 75000,
             100000, 250000, 500000, 750000,
             1000000]
    
    pre = 0 if min_votes not in votes else votes.index(min_votes)
    i = menu('Min. Votes', [f'{v:,}' for v in votes], pre)
    if i == 0:
        min_votes = None
    elif i > 0:
        min_votes = votes[i]
        
    votes.reverse()
    m = 0 if not min_votes else min_votes
    votes = [v for v in votes if v > m]
    if votes:
        pre = 0 if max_votes not in votes else votes.index(max_votes) + 1
        i = menu(f'Max. Votes ({m:,} - ?)', ['MAX'] + [f'{v:,}' for v in votes], pre)
        if i == 0:
            max_votes = None
        elif i > 0:
            max_votes = votes[i - 1]
    else:
        max_votes = None
    
    return min_votes, max_votes


def get_rating_vote_strings(min_rating, max_rating, min_votes, max_votes):
    rating_string = f'{min_rating or 0.0} - {max_rating or 10.0}'
    s_vote_min = '0' if not min_votes else f'{min_votes:,}'
    s_vote_max = 'MAX' if not max_votes else f'{max_votes:,}'
    vote_string = f'{s_vote_min} - {s_vote_max}'
    return rating_string, vote_string, '%s (%s)' % (rating_string, vote_string)


def rating_votes(defaults=None):
    if not defaults:
        defaults = None, None, None, None
    min_rating, max_rating, min_votes, max_votes = defaults
    
    m = KeyMenu('IMDb Rating', 2)
    m.add_item('reset', 'Reset', 'Clear rating and votes', format_index=1)
    m.add_item('rating', 'Rating')
    m.add_item('votes', 'Vote Count')
    
    while 1:
        rating_vote_strings = get_rating_vote_strings(min_rating, max_rating, min_votes, max_votes)
        m.set_value('rating', rating_vote_strings[0])
        m.set_value('votes', rating_vote_strings[1])
        selection = m.select()
        if selection is None:
            break
        if selection == 'reset':
            min_rating = max_rating = min_votes = max_votes = None
        elif selection == 'rating':
            min_rating, max_rating = rating_range(min_rating)
        elif selection == 'votes':
            min_votes, max_votes = vote_range(min_votes, max_votes)
    return min_rating, max_rating, min_votes, max_votes


def person_alpha(current_people=None):
    from caches.armani_media import armani
    people = armani.get_people()
    if current_people is None:
        current_people = []
    if current_people:
        people = [p for p in people if p['id'] not in (c['id'] for c in current_people)]
    alpha_list = list(dict.fromkeys(p['name'][0].upper() for p in people))

    i = -1
    while 1:
        i = alpha_menu('People', alpha_list, i)
        if i < 0:
            return None
        alpha = alpha_list[i]
        alpha_people = [p for p in people if p['name'].upper().startswith(alpha)]
        j = menu(f'People / {alpha}', [p['name'] for p in alpha_people])
        if j > -1:
            return alpha_people[j]
    
class MainMenu:
    def __init__(self):
        from caches.armani_media import armani
        from caches.armani_users import UserSettings
        self.__media = armani
        self.__save_key = 'home_menu'
        with UserSettings() as user_settings:
            self.home_menu = user_settings.get_json(self.__save_key)
            
    def __save(self):
        from caches.armani_users import UserSettings
        with UserSettings() as user_settings:
            user_settings.save_json(self.__save_key, self.home_menu)

    def media_alpha(self, db_type):
        if db_type == 'movie':
            title = 'Movie / A - Z'
        else:
            title = 'TV / A - Z'
        alpha = self.__media.get_existing_alpha(db_type)
        if not alpha:
            return
    
        options = alpha + ['All']
    
        i = self.__open_menu(title, options, alpha_menu, 'alpha_%s' % db_type)
        if i < 0:
            return
    
        where = 'WHERE db_type = "%s"' % db_type
        if i < len(alpha):
            a = alpha[i]
            where += ' AND starting_letter = "%s"' % a
        else:
            a = 'All Titles'
    
        title += ' / ' + a
        self.__launch_menu_item(title, where)
        
    def media_genre(self, db_type):
        if db_type == 'movie':
            title = 'Movies / Genres'
        else:
            title = 'TV / Genres'
        genres = self.__media.get_existing_genres(db_type)

        i = self.__open_menu(title, [g['name'] for g in genres], genre_menu, 'genres_%s' % db_type)
        if i < 0:
            return
        g = genres[i]
        where = 'WHERE db_type = "%s"' % db_type
        where += ' AND genre_ids LIKE "%' + g['id'] + '%"'
        title += ' / ' + g['name']
        self.__launch_menu_item(title, where)

    def media_decade(self, db_type):
        if db_type == 'movie':
            title = 'Movies / Decades'
        else:
            title = 'TV / Decades'
        decades = self.__media.get_existing_decades(db_type)
    
        i = self.__open_menu(title, ['%ds' % d for d in decades], decade_menu, 'decades_%s' % db_type)
        if i < 0:
            return
        d = decades[i]
        where = 'WHERE db_type = "%s"' % db_type
        where += ' AND decade = %d' % d
        title += ' / %d - %d' % (d, d + 9)
        self.__launch_menu_item(title, where)
        
    def people_alpha(self):
        p = self.__alpha_person('people_alpha')
        if not p:
            return
        self.__launch_menu_item(p['name'], 'WHERE ' + p['where'])
        
    def people_collaboration(self):
        def _select_person():
            alpha_list = list(dict.fromkeys(p['name'][0].upper() for p in new_people))
            while 1:
                _i = alpha_menu('Add Person', alpha_list)
                if _i < 0:
                    return
                _a = alpha_list[_i]
                _people = [_p for _p in new_people if _p['name'][0].upper() == _a]
                _i = menu('Add Person / %s' % _a, [_p['name'] for _p in _people])
                if _i > -1:
                    current_ids.append(_people[_i]['id'])
                    return
                
        def _save():
            self.home_menu['people_collaboration'] = ','.join(current_ids)
            self.__save()

        s = self.home_menu.get('people_collaboration')
        all_people = self.__media.get_people()
        current_ids = [] if not s else [i.strip() for i in s.split(',')]
        fmt1, fmt2, fmt3 = '[COLOR white]%s[/COLOR]', '[COLOR lightgrey][I]%s[/I][/COLOR]', '[COLOR yellow]%s[/COLOR]'
        
        m = KeyMenu('People Working Together', 2)
        m.add_item('add', 'Add two or more people')
        m.add_item('remove', 'Remove', 'Delete names or start over', format_index=1)
        m.add_item('view', 'View Results', format_index=1, visible=False)
        
        while 1:
            selected_people = [p for p in all_people if p['id'] in current_ids]
            new_people = [p for p in all_people if p['id'] not in current_ids]
            current_ids = [p['id'] for p in selected_people]  # get_people sorts names
            
            where_list = []
            for person_id in current_ids:
                s = '%<' + person_id + '>%'
                where_list.append('(cast_ids LIKE "%s" OR crew_ids LIKE "%s")' % (s, s))
            where = ''
            results = []
            if where_list and len(selected_people) > 1:
                where = 'WHERE ' + ' AND '.join(where_list)
                self.__media.cursor.execute('SELECT title FROM media %s' % where)
                results = [r[0] for r in self.__media.cursor.fetchall()]
                
            if selected_people:
                s_people = ', '.join(p['name'] for p in selected_people)
            else:
                s_people = fmt2 % 'Add two or more people'
                
            m.set_value('add', s_people)
            m.set_value('view', '%d matches' % len(results))
            m.set_visible('view', len(current_ids) > 1)
            selection = m.select()
        
            if selection is None:
                _save()
                return
            if selection == 'add':
                _select_person()
            elif selection == 'remove':
                if len(current_ids) == 1:
                    current_ids = []
                elif len(current_ids) > 1:
                    sel = menu('Remove People', [p['name'] for p in selected_people], [], True)
                    if sel:
                        for index in sorted(sel, reverse=True):
                            del current_ids[index]
            elif selection == 'view':
                if not results:
                    notification('No matches')
                else:
                    _save()
                    title = ', '.join(p['name'] for p in selected_people)
                    self.__launch_menu_item(title, where)
                    return
            
    def __alpha_person(self, alpha_key):
        people = self.__media.get_people()
        alpha_list = list(dict.fromkeys(p['name'][0].upper() for p in people))
        i = self.__open_menu('People', alpha_list, alpha_menu, alpha_key)
        if i < 0:
            return None
        a = alpha_list[i]
        people = [p for p in people if p['name'][0].upper() == a]
        i = self.__open_menu(f'People / {a}', [p['name'] for p in people], menu, f'{alpha_key}_{a}')
        if i < 0:
            return self.__alpha_person(alpha_key)
    
        person = people[i]
        s = '%<' + person['id'] + '>%'
        return {'name': person['name'], 'where': 'cast_ids LIKE "%s" OR crew_ids LIKE "%s"' % (s, s)}
        
    def __launch_menu_item(self, title, where):
        self.__media.cursor.execute('SELECT * FROM media %s LIMIT 1' % where)
        if not self.__media.cursor.fetchall():
            notification('No titles found')
            return
    
        url = {'mode': 'armani_fetch', 'where': where, 'armani_title': title}
        close_all_dialog()
        executebuiltin('RunPlugin(%s)' % build_url(url))

    def __open_menu(self, heading, options, menu_func, index_key) -> int:
        if not options:
            return -1
        pre = self.home_menu.get(index_key) or -1

        i = menu_func(heading, options, pre)
        if i < 0:
            return -1
        self.home_menu[index_key] = i
        self.__save()
        return i
    
    
class SearchDialog:
    def __init__(self):
        from caches.armani_users import UserSettings
        with UserSettings() as user_settings:
            self.__advanced_search_data = user_settings.get_json('advanced_search')
            self.__search_history = user_settings.get_json('search_history') or {
                'title': [], 'person': []
            }
        if not self.__advanced_search_data:
            self.__reset_advanced_search()
            
    def __save_search_history(self):
        from caches.armani_users import UserSettings
        self.__search_history['title'] = self.__search_history['title'][0:10]
        self.__search_history['person'] = self.__search_history['person'][0:10]
        with UserSettings() as user_settings:
            user_settings.save_json('search_history', self.__search_history)

    def armani_search(self):
        from caches.armani_users import UserSettings
        with UserSettings() as user_settings:
            menu_key = user_settings.get('search_menu_key') or 'title'

        m = KeyMenu('ArmaniFlix Search Options', 2, menu_key)
        m.add_item('title', "Titles", "Search for one or more titles")
        m.add_item('person', "Person", "Find titles of an actor, director, or writer")
        m.add_item('advanced', "Advanced", "Use ArmaniFlix's advanced search")
        selected = m.select()
        
        if selected == 'title':
            self.__title_search()
        elif selected == 'person':
            self.__person_search()
        elif selected == 'advanced':
            self.__advanced_search()

        if selected is not None:
            with UserSettings() as user_settings:
                user_settings.save('search_menu_key', selected)
    
    def imdb_search(self):
        from caches.armani_media import armani
        from caches.armani_users import UserSettings
    
        with UserSettings() as user_settings:
            imdb_key = user_settings.get('imdb_menu_key') or 'title'

        executebuiltin('SetFocus(30000)')
    
        m = KeyMenu('IMDb Search Options', 2, imdb_key)
        m.add_item('title', "Title", "Find a specific title")
        m.add_item('person', "Credits", "Find titles of an actor, director, or writer")
        m.add_item('advanced', "Advanced", "Use IMDb's advanced search")
    
        selected = m.select()
        if selected == 'title':
            self.__imdb_title()
        elif selected == 'person':
            self.__imdb_person_credits()
        elif selected == 'advanced':
            armani.imdb_find_advanced()

        executebuiltin('SetFocus(8001)')
    
        if selected is not None:
            with UserSettings() as user_settings:
                user_settings.save('imdb_menu_key', selected)

    def imdb_find_advanced(self, params):
        from xbmcgui import ListItem
        from caches.armani_users import UserSettings
        from datetime import date
        from modules.armani_utils import get_search_string
        from apis.armani_imdb_api import GENRE_MAP, KEYWORD_MAP, IMDB_ADVANCED_LANGUAGES, IMDB_ADVANCED_CERTIFICATES
        from apis.armani_imdb_api import imdb_advanced_search
    
        def _defaults():
            return {
                'type_index': 1,
                'title': '',
                'person': None,
                'genre_keys': {'include': [], 'exclude': []},
                'keywords': [],
                'language_index': 0,
                'mpaa_indices': [],
                'years': [1900, date.today().year],
                'rating_votes': (None, None, None, None),
                'page_index': 2
            }
    
        def _reset():
            values.update(_defaults())
            _more_init()
            with UserSettings() as user_settings:
                user_settings.save_json('imdb_find_advanced', values)
    
        def _load():
            with UserSettings() as user_settings:
                values.update(user_settings.get_json('imdb_find_advanced'))
            if 'db_type' in params:
                values['type_index'] = 1 if params['db_type'] == 'movie' else 2
            if 'title' in params:
                values['title'] = params['title'].strip()
            if 'person' in params:
                values['person'] = params['person']
            if 'genre_id' in params:
                _g = params['genre_id']
                if _g in GENRE_MAP:
                    values['genre_keys']['include'] = [_g]
                elif _g in KEYWORD_MAP:
                    values['keywords'] = [KEYWORD_MAP[_g]]
            if 'decade' in params:
                _d = int(params['decade'])
                values['years'] = [_d, _d + 9]
    
        def _save():
            _keys = ('type_index', 'title', 'person', 'genre_keys', 'keywords',
                     'language_index', 'years', 'mpaa_indices', 'rating_votes', 'page_index')
            with UserSettings() as user_settings:
                user_settings.save_json('imdb_find_advanced', {k: values[k] for k in _keys})
    
        def _genres_init():
            try:
                _include_values = [GENRE_MAP[k] for k in values['genre_keys']['include']]
                _exclude_values = [GENRE_MAP[k] for k in values['genre_keys']['exclude']]
            except:
                values['genre_keys'] = {'include': [], 'exclude': []}
                _include_values, _exclude_values = [], []
        
            _combined_values = _include_values + [f'!{g}' for g in _exclude_values]
            values['genre_string'] = ', '.join(_combined_values) or 'None'
            values['genre_values'] = ','.join(_combined_values)
            menu_genres.set_value('include', ', '.join(_include_values) or 'None')
            menu_genres.set_value('exclude', ', '.join(_exclude_values) or 'None')
    
        def _more_init():
            _genres_init()
        
            s_rating_votes = get_rating_vote_strings(
                values['rating_votes'][0], values['rating_votes'][1],
                values['rating_votes'][2], values['rating_votes'][3])[2]
            menu_more.set_value('date', '%d - %d' % (values['years'][0], values['years'][1]))
            menu_more.set_value('person', 'None' if not values['person'] else values['person']['name'])
            menu_more.set_value('genres', values['genre_string'])
            menu_more.set_value('keywords', ', '.join(values['keywords']) or 'None')
            menu_more.set_value('language', IMDB_ADVANCED_LANGUAGES[values['language_index']][0])
            menu_more.set_value('mpaa', ', '.join(IMDB_ADVANCED_CERTIFICATES[_i]['label']
                                                  for _i in values['mpaa_indices']) or 'All')
            menu_more.set_value('rating', s_rating_votes)
            menu_more.set_value('pages', page_counts[values['page_index']])
        
            _default_values = _defaults()
            _all_values = {}
            _more_values = []
            for _value_key, _menu_key in (('years', 'date'),
                                          ('person', 'person'),
                                          ('genre_keys', 'genres'),
                                          ('keywords', 'keywords'),
                                          ('language_index', 'language'),
                                          ('mpaa_indices', 'mpaa'),
                                          ('rating_votes', 'rating'),
                                          ('page_index', 'pages')):
            
                if _default_values[_value_key] == values[_value_key]:
                    continue
                _more_values.append(menu_more.get_label2(_menu_key))
            values['more_string'] = ' | '.join(_more_values) or 'Defaults'
    
        def _show_genre_menu():
            _genres_init()
            _selected = menu_genres.select()
            if _selected is None:
                return
            if _selected == 'reset':
                values['genre_keys'] = {'include': [], 'exclude': []}
            else:
                _pre = [genre_keys.index(k) for k in values['genre_keys'][_selected]]
                _sel = genre_menu('Genres to %s' % _selected.capitalize(), genre_values, _pre, True)
                if _sel is not None:
                    values['genre_keys'][_selected] = [genre_keys[_i] for _i in _sel]
        
            _show_genre_menu()
    
        def _show_more_menu():
            while 1:
                _more_init()
                _selected = menu_more.select()
                if _selected is None:
                    return
                if _selected == 'date':
                    values['years'] = list(year_range((values['years'][0], values['years'][1])))
                elif _selected == 'person':
                    from caches.armani_media import armani
                    person = self.__find_or_add_person()
                    if person:
                        values['person'] = person
                elif _selected == 'genres':
                    _show_genre_menu()
                elif _selected == 'keywords':
                    t = Dialog().input('Enter IMDb keywords[CR][I]Use commas to delimit words[/I]',
                                       ','.join(values['keywords'])).strip()
                    values['keywords'] = [] if not t else ['-'.join(w.strip().split()) for w in t.split(',')]
                elif _selected == 'language':
                    _i = genre_menu('Languages', [v[0] for v in IMDB_ADVANCED_LANGUAGES], values['language_index'])
                    if _i > -1:
                        values['language_index'] = _i
                elif _selected == 'mpaa':
                    _sel = double_line_menu('Certificates', mpaa_items, values['mpaa_indices'], True)
                    if _sel is not None:
                        values['mpaa_indices'] = _sel
                elif _selected == 'rating':
                    values['rating_votes'] = rating_votes(values['rating_votes'])
                elif _selected == 'pages':
                    _i = menu('Pages to Scan', page_counts, values['page_index'])
                    if _i > -1:
                        values['page_index'] = _i
    
        title_types = [
            ('All', 'movie,tvMovie,short,tvSeries,tvMiniSeries'),
            ('Movies', 'movie,tvMovie,short'),
            ('TV Shows', 'tvSeries,tvMiniSeries')
        ]
        page_counts = ['1', '2', '3', '4', '5',
                       '6', '7', '8', '9', '10']
        genre_keys = list(GENRE_MAP.keys())
        genre_values = list(GENRE_MAP.values())
    
        values = _defaults()
        _load()
    
        main_menu = KeyMenu('IMDb Search', 1, 'title')
        main_menu.add_item('reset', 'RESET', format_index=3)
        main_menu.add_item('title', 'Title')
        main_menu.add_item('type', 'Media Type')
        main_menu.add_item('more', 'More Options...')
        main_menu.add_item('search', 'SEARCH', format_index=1)
    
        menu_more = KeyMenu('More Options', 1)
        menu_more.add_item('date', 'Release Date')
        menu_more.add_item('person', 'Person')
        menu_more.add_item('genres', 'Genres')
        menu_more.add_item('keywords', 'Keywords')
        menu_more.add_item('language', 'Language')
        menu_more.add_item('mpaa', 'Certificate')
        menu_more.add_item('rating', 'IMDb Rating')
        menu_more.add_item('pages', 'Max. Pages')
    
        menu_genres = KeyMenu('Genres', 2)
        menu_genres.add_item('reset', 'Reset', 'Clear genres', format_index=1)
        menu_genres.add_item('include', 'Include Genres')
        menu_genres.add_item('exclude', 'Exclude Genres')
    
        _more_init()
    
        mpaa_items = [ListItem(m['label'], m['label2']) for m in IMDB_ADVANCED_CERTIFICATES]
    
        while 1:
            main_menu.set_value('title', values['title'])
            main_menu.set_value('type', title_types[values['type_index']][0])
            main_menu.set_value('more', values['more_string'])
            selection = main_menu.select()
            if selection is None:
                _save()
                return None
            if selection == 'reset':
                _reset()
            elif selection == 'title':
                values['title'] = Dialog().input('Search for a title', values['title']).strip()
            elif selection == 'type':
                i = menu('Media Type', [t[0] for t in title_types], values['type_index'])
                if i > -1:
                    values['type_index'] = i
            elif selection == 'more':
                _show_more_menu()
            elif selection == 'search':
                _save()
                url_params = [
                    'title_type=%s' % title_types[values['type_index']][1],
                    'release_date=%d-01-01,%d-12-31' % (values['years'][0], values['years'][1])
                ]
                if values['rating_votes'][0] or values['rating_votes'][1]:
                    rating = ('' if not values['rating_votes'][0] else str(values['rating_votes'][0]),
                              '' if not values['rating_votes'][1] else str(values['rating_votes'][1]))
                    url_params.append('user_rating=%s,%s' % rating)
                if values['title']:
                    url_params.append('title=%s' % values['title'])
                if values['person']:
                    url_params.append('role=%s' % values['person']['id'])
                if values['genre_values']:
                    url_params.append('genres=%s' % values['genre_values'])
                if values['keywords']:
                    url_params.append('keywords=%s' % ','.join(values['keywords']))
                if values['language_index'] > 0:
                    url_params.append(IMDB_ADVANCED_LANGUAGES[values['language_index']][1])
                if values['mpaa_indices']:
                    url_params.append('certificates=%s' % ','.join(IMDB_ADVANCED_CERTIFICATES[i]['value']
                                                                   for i in values['mpaa_indices']))
            
                url_tail = '&'.join(url_params)
                pages = int(page_counts[values['page_index']])
                min_votes = 0 if not values['rating_votes'][2] else values['rating_votes'][2]
                max_votes = -1 if not values['rating_votes'][3] else values['rating_votes'][3]
                return imdb_advanced_search(url_tail, pages, min_votes, max_votes)

    def __title_search(self, default=''):
        import json
        
        def _search():
            close_all_dialog()
            url_params = build_url({'mode': 'build_armani_results', 'armani_title': f'"{title.upper()}"',
                                    'fetch_params': json.dumps({'query': title})})
            executebuiltin('ActivateWindow(Videos,%s,return)' % url_params)
            self.__search_history['title'].insert(0, title)
            self.__search_history['title'] = list(dict.fromkeys(self.__search_history['title']))
            self.__save_search_history()

        history = self.__search_history['title']
        if history:
            i = menu('Find a Title', ['[COLOR yellow][NEW SEARCH][/COLOR]'] + history)
            if i < 0:
                return
            if i > 0:
                title = history[i - 1]
                return _search()
        
        title = Dialog().input(ls(33620), default).strip()
        if title:
            _search()
        
    def __person_search(self):
        from caches.armani_media import armani
        from modules.armani_utils import get_search_string
        from caches.armani_people import ArmaniPeople, view_credits
        
        def _save(_person):
            if _person['id'] in [p['id'] for p in self.__search_history['person']]:
                self.__search_history['person'].remove(_person)
            self.__search_history['person'].insert(0, _person)
            self.__save_search_history()
            
        history = self.__search_history['person']
        if history:
            i = menu('Find a Person', ['[COLOR yellow][NEW SEARCH][/COLOR]'] + [p['name'] for p in history])
            if i < 0:
                return
            if i > 0:
                person = history[i - 1]
                _save(person)
                view_credits(person)
                return
        
        query = Dialog().input(ls(33619)).strip()
        if not query:
            return
        q = get_search_string(query)
        people = [p for p in armani.get_people() if q in get_search_string(p['name'])]
        if not people:
            if not Dialog().yesno('No Results', 'No names matching "%s" were found. Add a new name?' % query):
                return
            person = ArmaniPeople().add_person(query, True, True)
            if person:
                _save(person)
                view_credits(person)
        elif len(people) == 1:
            _save(people[0])
            view_credits(people[0])
        else:
            i = menu('"%s"' % query, [p['name'] for p in people])
            if i < 0:
                return
            _save(people[i])
            view_credits(people[i])
            
    def __advanced_search(self):
        from caches.armani_media import armani
        from modules.armani_utils import get_language_items
        
        get_language_items()
    
        adv_values = {
            'media_type': self.__get_advanced_media_types(),
            'language': self.__get_advanced_language(),
            'years': self.__get_advanced_years(),
            'mpaa': self.__get_advanced_mpaa(),
            'rating': self.__get_advanced_rating(),
            'genres': self.__get_advanced_genres(),
            'people': self.__get_advanced_people()
        }
    
        watched_status = self.__get_advanced_watch_status()
        sort_order = self.__get_advanced_sort()
        executebuiltin('SetFocus(30000)')
        
        m = KeyMenu('Advanced Search', 1)
        m.add_item('search', 'SEARCH', format_index=1)
        m.add_item('media_type', 'Type')
        m.add_item('genres', 'Genres')
        m.add_item('years', 'Release Date')
        m.add_item('people', 'Cast / Crew')
        m.add_item('language', 'Language')
        m.add_item('mpaa', 'Certificate')
        m.add_item('rating', 'IMDb Rating')
        m.add_item('watched_status', 'Watched Status')
        m.add_item('sort', 'Sort By')
        m.add_item('reset', 'RESET', format_index=3)
        
        while 1:
            where_list = ['(%s)' % v['where'] for v in adv_values.values() if v['where']]
            if not where_list:
                num_results = len(armani.get_meta_list(watched_status=watched_status['value']))
            else:
                num_results = len(armani.get_meta_list(f'WHERE {" AND ".join(where_list)}',
                                                       watched_status=watched_status['value']))
                
            m.set_value('search', f'{num_results} titles')
            m.set_value('watched_status', watched_status['string'])
            m.set_value('sort', sort_order['string'])
            [m.set_value(k, adv_values[k]['string']) for k in ('media_type', 'language', 'years', 'mpaa', 'rating',
                                                               'genres', 'people')]
            selection = m.select()
        
            if selection is None:
                executebuiltin('SetFocus(8001)')
                return
            if selection == 'reset':
                self.__reset_advanced_search()
                return self.__advanced_search()
            if selection == 'search':
                if num_results == 0:
                    notification('No Results')
                    continue
                break
                
            if selection == 'media_type':
                adv_values['media_type'] = self.__advanced_media_type()
            elif selection == 'language':
                adv_values['language'] = self.__advanced_language()
            elif selection == 'years':
                adv_values['years'] = self.__advanced_years()
            elif selection == 'mpaa':
                adv_values['mpaa'] = self.__advanced_mpaa()
            elif selection == 'rating':
                adv_values['rating'] = self.__advanced_rating()
            elif selection == 'genres':
                adv_values['genres'] = self.__advanced_genres()
            elif selection == 'people':
                adv_values['people'] = self.__advanced_people()
            elif selection == 'watched_status':
                watched_status = self.__advanced_watch_status()
            elif selection == 'sort':
                sort_order = self.__advanced_sort()
    
        executebuiltin('SetFocus(8001)')

        window_action = 'ActivateWindow(Videos,%s,return)'
        close_all_dialog()
        executebuiltin(window_action % build_url({'mode': 'build_armani_results',
                                                  'armani_title': 'Advanced Search Results',
                                                  'where': 'WHERE ' + ' AND '.join(where_list),
                                                  'watched': watched_status['value'],
                                                  'sort': sort_order['sort']}))
        
    def __imdb_title(self):
        from caches.armani_media import armani

        history = self.__search_history['title']
        if history:
            i = menu('IMDb Title Search', ['[COLOR yellow][NEW SEARCH][/COLOR]'] + history)
            if i < 0:
                return
            if i > 0:
                title = history[i - 1]
                return armani.imdb_find_title(title, input_title=False)

        title = Dialog().input('Search for the title of a movie or show').strip()
        if not title:
            return
        
        self.__search_history['title'].insert(0, title)
        self.__search_history['title'] = list(dict.fromkeys(self.__search_history['title']))
        self.__save_search_history()
        armani.imdb_find_title(title, input_title=False)
        
    def __find_or_add_person(self):
        from caches.armani_media import armani
        from modules.armani_utils import get_search_string
        from caches.armani_people import ArmaniPeople
    
        def _save(_person):
            if _person['id'] in [p['id'] for p in self.__search_history['person']]:
                self.__search_history['person'].remove(_person)
            self.__search_history['person'].insert(0, _person)
            self.__save_search_history()
    
        history = self.__search_history['person']
        if history:
            i = menu('Select a Person', ['[COLOR yellow][NEW SEARCH][/COLOR]'] + [p['name'] for p in history])
            if i < 0:
                return
            if i > 0:
                person = history[i - 1]
                _save(person)
                return person
    
        query = Dialog().input(ls(33619)).strip()
        if not query:
            return None
        q = get_search_string(query)
        people = [p for p in armani.get_people() if q in get_search_string(p['name'])]
        if not people:
            if not Dialog().yesno('No Results', 'No names matching "%s" were found. Add a new name?' % query):
                return None
            person = ArmaniPeople().add_person(query, True, True)
            if person:
                _save(person)
                return person
        elif len(people) == 1:
            _save(people[0])
            return people[0]
        else:
            i = menu('"%s"' % query, [p['name'] for p in people])
            if i < 0:
                return None
            _save(people[i])
            return people[i]
        
    def __imdb_person_credits(self):
        from caches.armani_media import armani
        
        person = self.__find_or_add_person()
        if not person:
            return
        armani.imdb_add_person_credits(person)

    def imdb_get_person_credits(self, person):
        from apis.armani_imdb_api import imdb_person_title_search
        from caches.armani_users import UserSettings
        
        def _defaults():
            return {'job': 0, 'db_type': 0, 'min_votes': 0, 'min_rating': 0}
        
        with UserSettings() as user_settings:
            saved = user_settings.get_json('credit_search') or _defaults()
            
        labels = {
            'job': 'Job',
            'db_type': 'Media Type',
            'min_votes': 'Min. Votes',
            'min_rating': 'Min Rating'
        }
        
        db_types = {'Movies': 'movie', 'TV Shows': 'tvshow'}
        
        lists = {
            'job': person['jobs'].split(','),
            'db_type': ['Movies', 'TV Shows'],
            'min_votes': ['0', '1,000', '2,500', '5,000', '10,000', '25,000', '50,000', '100,000', '250,000',
                          '500,000', '1,000,000'],
            'min_rating': ['0', '5', '6', '6.5', '7', '7.5', '8', '8.5', '9']
        }
        for k in ('job', 'db_type', 'min_votes', 'min_rating'):
            if saved[k] > len(lists[k]) - 1:
                saved[k] = 0
        
        search_selected = False
        m = KeyMenu(person['name'], 1, 'search')
        m.add_item('search', 'SEARCH', format_index=1)
        if len(lists['job']) > 1:
            m.add_item('job', 'Job')
        m.add_item('db_type', 'Media Type')
        m.add_item('min_rating', 'Min. Rating')
        m.add_item('min_votes', 'Min. Votes')
        m.add_item('reset', 'RESET', format_index=2)
        
        while 1:
            for k in ('job', 'db_type', 'min_votes', 'min_rating'):
                if len(lists[k]) > 1:
                    m.set_value(k, lists[k][saved[k]])
                    
            selected = m.select()
            if selected is None:
                break
            if selected == 'reset':
                saved = _defaults()
            elif selected == 'search':
                search_selected = True
                break
            else:
                i = menu(labels[selected], lists[selected], saved[selected])
                if i > -1:
                    saved[selected] = i
        with UserSettings() as user_settings:
            user_settings.save_json('credit_search', saved)
            
        if not search_selected:
            return None
        return imdb_person_title_search(person['id'],
                                        lists['job'][saved['job']],
                                        db_types[lists['db_type'][saved['db_type']]],
                                        lists['min_rating'][saved['min_rating']],
                                        lists['min_votes'][saved['min_votes']].replace(',', ''))
    
    def __reset_advanced_search(self):
        from caches.armani_users import UserSettings
        data = {
            'filters': {}, 'watch_status': {'string': 'Any', 'value': 0},
            'sort': {'string': 'Title', 'sort': 'sort_title, release_date'}
        }
        with UserSettings() as user_settings:
            user_settings.save_json('advanced_search', data)
        self.__advanced_search_data = data
    
    def __save_advanced_search(self):
        from caches.armani_users import UserSettings
        with UserSettings() as user_settings:
            user_settings.save_json('advanced_search', self.__advanced_search_data)
    
    def __get_advanced_watch_status(self):
        return self.__advanced_search_data.get('watch_status') or {
            'string': 'Any', 'value': 0
        }
    
    def __advanced_watch_status(self):
        saved = self.__get_advanced_watch_status()
        watched_items = ('Any', 'Watched', 'Unwatched')
    
        i = menu('Watched Status', watched_items, saved['value'])
        if i > -1:
            saved.update({'string': watched_items[i], 'value': i})
        self.__advanced_search_data['watch_status'] = saved
        self.__save_advanced_search()
        return saved
    
    def __get_advanced_media_types(self):
        return self.__advanced_search_data['filters'].get('media_type') or {
            'string': 'All', 'where': ''
        }
    
    def __get_advanced_language(self):
        return self.__advanced_search_data['filters'].get('language') or {
            'string': 'All', 'where': ''
        }
    
    def __get_advanced_years(self):
        from datetime import date
        y = date.today().year
        
        return self.__advanced_search_data['filters'].get('years') or {
            'string': '1900 - %d' % y, 'where': '', 'min_year': 1900, 'max_year': y
        }
    
    def __get_advanced_rating(self):
        return self.__advanced_search_data['filters'].get('rating') or {
            'string': '0 - 10 (0 - Max)', 'where': '',
            'min_rating': None, 'max_rating': None, 'min_votes': None, 'max_votes': None
        }
    
    def __get_advanced_genres(self):
        return self.__advanced_search_data['filters'].get('genres') or {
            'string': 'Any', 'where': '', 'any': [], 'all': [], 'none': []
        }
    
    def __get_advanced_people(self):
        return self.__advanced_search_data['filters'].get('people') or {
            'string': 'None', 'where': '', 'people': [], 'collaboration': False
        }
    
    def __get_advanced_mpaa(self):
        return self.__advanced_search_data['filters'].get('mpaa') or {
            'string': 'Any', 'where': ''
        }
    
    def __get_advanced_sort(self):
        return self.__advanced_search_data['sort'] or {
            'string': 'Title', 'sort': 'sort_title, release_date'
        }
    
    def __advanced_sort(self):
        sorts = {
            'Title': 'sort_title, release_date',
            'Newest': 'release_date DESC, sort_title',
            'Oldest': 'release_date, sort_title',
            'Highest Rated': 'rating DESC, votes DESC',
            'Lowest Rated': 'rating, votes',
            'Most Votes': 'votes DESC, sort_title',
            'Fewest Votes': 'votes, sort_title'
        }
        sort_keys = list(sorts.keys())
        saved = self.__get_advanced_sort()
        saved_sort = saved['string']
        if saved_sort not in sorts:
            saved_sort = 'Title'
        
        i = menu('Sort By', sort_keys, sort_keys.index(saved_sort))
        if i > -1:
            saved_sort = sort_keys[i]
        saved.update({'string': saved_sort, 'sort': sorts[saved_sort]})
        self.__advanced_search_data['sort'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_media_type(self):
        media_types = {
            'All': '',
            'Movies': 'db_type == "movie"',
            'TV Shows': 'db_type == "tvshow"',
            'Returning Series': 'db_type == "tvshow" AND status == "Returning Series"',
            'Completed Series': 'db_type == "tvshow" AND status != "Returning Series"'
        }
        media_type_keys = list(media_types.keys())
        saved = self.__get_advanced_media_types()
        media_type = saved['string']
        if media_type not in media_types:
            media_type = 'All'
        
        i = menu('Media Type', media_type_keys, media_type_keys.index(media_type))
        if i > -1:
            media_type = media_type_keys[i]
        saved.update({'string': media_type, 'where': media_types[media_type]})
        self.__advanced_search_data['filters']['media_type'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_language(self):
        from modules.armani_utils import get_language_items
        languages = get_language_items(False)
        language_keys = list(languages.keys())
        saved = self.__get_advanced_language()
        language = saved['string']
        if language not in languages:
            language = 'All'
        
        i = menu('Language', [v for v in language_keys], language_keys.index(language))
        if i > -1:
            language = language_keys[i]
        saved.update({'string': language, 'where': languages[language]})
        self.__advanced_search_data['filters']['language'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_years(self):
        from caches.armani_media import armani
        saved = self.__get_advanced_years()
        try:
            min_year = int(saved.get('min_year') or '0')
            max_year = int(saved.get('max_year') or '0')
        except ValueError:
            min_year, max_year = 0, 0
        
        armani.cursor.execute('SELECT DISTINCT year FROM media ORDER BY year')
        valid_years = [r[0] for r in armani.cursor.fetchall()]
        
        min_year, max_year = year_range((min_year, max_year), valid_years)
        where = []
        if min_year:
            where.append(f'year >= {min_year}')
        if max_year:
            where.append(f'year <= {max_year}')
        saved.update({'string': f'{min_year or "1900"} - {max_year or "Now"}',
                      'where': '' if not where else ' AND '.join(where),
                      'min_year': min_year, 'max_year': max_year})
        self.__advanced_search_data['filters']['years'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_mpaa(self):
        saved = self.__get_advanced_mpaa()
        items = {
            'Any': '',
            'No Rating': 'mpaa == "NR"',
            'G': 'mpaa IN ("G", "TV-Y", "TV-Y7", "TV-G")',
            'PG': 'mpaa IN ("PG", "TV-PG")',
            'PG-13': 'mpaa IN ("PG-13", "TV-14")',
            'R': 'mpaa IN ("R", "TV-MA")',
            'NC-17': 'mpaa == "NC-17"'
        }
        mpaa_labels = list(items.keys())
        mpaa_where = list(items.values())
        
        pre = -1 if saved['string'] not in mpaa_labels else mpaa_labels.index(saved['string'])
        i = menu('Certificate', mpaa_labels, pre)
        if i < 0:
            return saved
        
        saved.update({'string': mpaa_labels[i], 'where': mpaa_where[i]})
        self.__advanced_search_data['filters']['mpaa'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_rating(self):
        saved = self.__get_advanced_rating()
        min_rating = saved.get('min_rating')
        max_rating = saved.get('max_rating')
        min_votes = saved.get('min_votes')
        max_votes = saved.get('max_votes')
        min_rating, max_rating, min_votes, max_votes = rating_votes((min_rating, max_rating, min_votes, max_votes))
        
        where = []
        if min_rating:
            where.append(f'rating >= {min_rating}')
        if max_rating:
            where.append(f'rating <= {max_rating}')
        if min_votes:
            where.append(f'votes >= {min_votes}')
        if max_votes:
            where.append(f'votes <= {max_votes}')
            
        saved.update({
            'string': get_rating_vote_strings(min_rating, max_rating, min_votes, max_votes)[2],
            'where': '' if not where else ' AND '.join(where),
            'min_rating': min_rating, 'max_rating': max_rating,
            'min_votes': min_votes, 'max_votes': max_votes
        })
        self.__advanced_search_data['filters']['rating'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_genres(self):
        from caches.armani_media import armani
        saved = self.__get_advanced_genres()
        
        genres = armani.get_existing_genres()
        genre_ids = [g['id'] for g in genres]
        genre_names = [g['name'] for g in genres]
        genre_headings = {'any': 'Include ANY Genre', 'all': 'Include ALL Genres', 'none': 'Exclude Genres'}
        for k in ('any', 'all', 'none'):
            saved[k] = [g for g in saved[k] if g in genre_ids]

        m = KeyMenu('Genres', 2)
        m.add_item('reset', 'Reset', 'Clear genres', format_index=1)
        m.add_item('any', 'Any Genre')
        m.add_item('all', 'All Genres')
        m.add_item('none', 'Exclude Genres')
        
        while 1:
            genre_indices = {k: [genre_ids.index(g) for g in saved[k]] for k in ('any', 'all', 'none')}
            [m.set_value(k, ', '.join(genre_names[j] for j in genre_indices[k]) or 'None')
             for k in ('any', 'all', 'none')]
            selection = m.select()
            
            if selection is None:
                break
            if selection == 'reset':
                saved.update({'any': [], 'all': [], 'none': []})
            else:
                pre = [genre_ids.index(g) for g in saved[selection]]
                sel = genre_menu(genre_headings[selection], genre_names, pre, True)
                if sel is None:
                    continue
                saved[selection] = [genre_ids[i] for i in sel]
        
        strings = []
        where = []
        if genre_indices['any']:
            strings.append('ANY(%s)' % ','.join(genre_names[i] for i in genre_indices['any']))
            where.append('(%s)' % (' OR '.join('genre_ids LIKE "%s"' % ('%' + g + '%') for g in saved['any'])))
        if genre_indices['all']:
            strings.append('ALL(%s)' % ','.join(genre_names[i] for i in genre_indices['all']))
            where.append(' AND '.join('genre_ids LIKE "%s"' % ('%' + g + '%') for g in saved['all']))
        if genre_indices['none']:
            strings.append('EXCLUDE(%s)' % ','.join(genre_names[i] for i in genre_indices['none']))
            where.append(' AND '.join('genre_ids NOT LIKE "%s"' % ('%' + g + '%') for g in saved['none']))
        
        saved.update({'string': ' | '.join(strings) or 'None', 'where': ' AND '.join(where) or ''})
        self.__advanced_search_data['filters']['genres'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_people(self):
        saved = self.__get_advanced_people()
        
        saved_people = saved.get('people', [])
        collaboration = saved.get('collaboration', False)
        
        m = KeyMenu('People', 2)
        m.add_item('add', 'Add People')
        m.add_item('remove', 'Remove People')
        m.add_item('collaboration', 'Collaboration')
        
        while 1:
            m.set_value('add', ', '.join(p['name'] for p in saved_people) or 'None')
            m.set_value('remove', f'{len(saved_people)} people added')
            m.set_value('collaboration', 'Yes' if collaboration else 'No')
            selection = m.select()
            
            if selection is None:
                break
            elif selection == 'add':
                person = person_alpha(saved_people)
                if person:
                    saved_people.append(person)
                    saved_people.sort(key=lambda k: k['name'])
            elif selection == 'remove':
                if not saved_people:
                    continue
                if len(saved_people) == 1:
                    saved_people = []
                else:
                    sel = menu('Remove People', [p['name'] for p in saved_people], [], True)
                    if sel:
                        delete_ids = [saved_people[i]['id'] for i in sel]
                        saved_people = [p for p in saved_people if p['id'] not in delete_ids]
            elif selection == 'collaboration':
                collaboration = not collaboration
        
        strings = []
        where = []
        joiner = ' AND ' if collaboration else ' OR '
        for p in saved_people:
            s_id = '%<' + p['id'] + '>%'
            where.append(f'(cast_ids LIKE "{s_id}" OR crew_ids LIKE "{s_id}")')
            strings.append(p['name'])
        
        saved = {
            'string': joiner.join(strings) or 'None',
            'where': joiner.join(where),
            'people': saved_people,
            'collaboration': collaboration
        }
        self.__advanced_search_data['filters']['people'] = saved
        self.__save_advanced_search()
        return saved
    