import sqlite3
import json
from xbmcvfs import translatePath
from xbmcgui import Dialog, ListItem
from xbmc import executebuiltin
from modules.kodi_utils import logger, notification, kodi_refresh, close_all_dialog, local_string as ls, delete
from datetime import datetime

USER_DB = translatePath('special://profile/addon_data/plugin.video.armaniflix/armani_users.db')
WATCHED_PERCENT = 90

PLAYLIST_STRINGS = {
    'media_types': {'label': 'Media Types', 'info': 'Include movies and/or TV shows'},
    'watched_status': {'label': 'Watched Status', 'info': 'Include watched and/or unwatched content'},
    'decades': {'label': 'Decades', 'info': 'Match any selected decades'},
    'languages': {'label': 'Languages', 'info': 'Match any selected languages'},
    'genres_any': {'label': 'Genres (any)', 'info': 'Match any selected genres'},
    'genres_all': {'label': 'Genres (all)', 'info': 'Match every selected genre'},
    'genres_none': {'label': 'Genres (none)', 'info': 'Exclude selected genres'},
    'search_any': {'label': 'Search (any)', 'info': 'Match any entered keywords'},
    'search_all': {'label': 'Search (all)', 'info': 'Match every entered keyword'},
    'search_none': {'label': 'Search (none)', 'info': 'Exclude entered keywords'}
}

PLAYLIST_KEYS = ('media_types', 'watched_status', 'decades', 'languages', 'genres_any', 'genres_all', 'genres_none',
                 'search_any', 'search_all', 'search_none')

MASTER_PIN = '615243'


def get_pin(default=""):
    import modules.armani_dialogs as armani_dialogs
    return armani_dialogs.numeric(ls(33550), ls(33529), default, True)


class UserSettings(object):
    def __init__(self):
        from caches.armani_settings import ArmaniSettings
        settings = ArmaniSettings()
        self.user_id = settings.get('user_id')
        self.user_name = settings.get('user_name')
        
    def __enter__(self):
        self.connection = sqlite3.connect(USER_DB)
        self.cursor = self.connection.cursor()
        return self
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.connection.close()
        
    def clear(self):
        if not Dialog().yesno('Confirm Deletion',
                              'All user settings (including search history) will be erased. Proceed?'):
            return
        self.cursor.execute('DELETE FROM settings')
        self.connection.commit()
        notification('User settings cleared')
        
    def save(self, setting_key: str, setting_value: str):
        self.cursor.execute('INSERT OR REPLACE INTO settings (user_id, setting_key, setting_value) VALUES(?, ?, ?)',
                            (self.user_id, setting_key, setting_value))
        self.connection.commit()
        
    def save_json(self, setting_key: str, setting_value):
        self.save(setting_key, json.dumps(setting_value))
        
    def get(self, setting_key: str):
        self.cursor.execute('SELECT setting_value FROM settings WHERE user_id = ? AND setting_key = ?',
                            (self.user_id, setting_key))
        result = self.cursor.fetchone()
        value = None if not result else result[0]
        return value
    
    def get_json(self, setting_key: str):
        got = self.get(setting_key)
        return {} if not got else json.loads(got)
    
    
class ArmaniPlaylist:
    def __init__(self):
        from caches.armani_media import armani
        from caches.armani_settings import ArmaniSettings
        self.settings = ArmaniSettings()
        self.conn = sqlite3.connect(USER_DB)
        self.cursor = self.conn.cursor()
        self.user_id = self.settings.get('user_id')
        self.user_name = self.settings.get('user_name')
        self.genres = {g['id']: g['name'] for g in armani.get_existing_genres()}
        self.playlist = self.get_playlist()
        
        genre_items = [{'label': v, 'value': k} for k, v in self.genres.items()]
        self.list_items = {
            'media_types': [{'label': 'Movies', 'value': 'movie'}, {'label': 'TV Shows', 'value': 'tvshow'}],
            'watched_status': [{'label': 'Unwatched', 'value': 'unwatched'}, {'label': 'Watched', 'value': 'watched'}],
            'decades': [{'label': '%d - %d' % (d, d + 9), 'value': d} for d in armani.get_existing_decades()],
            'languages': [{'label': lang['name'], 'value': lang['name']} for lang in armani.get_existing_languages()],
            'genres_any': genre_items,
            'genres_all': genre_items,
            'genres_none': genre_items
        }
        self.input_items = {
            'search_any': {'label': 'Search (any)', 'header': 'Match any titles / names'},
            'search_all': {'label': 'Search (all)', 'header': 'Match every title / name'},
            'search_none': {'label': 'Search (none)', 'header': 'Exclude titles / names'}
        }
        
    def action(self, action):
        def _get_info():
            _values = self.playlist.get(key) or []
            if not _values:
                return [], []
            if key.startswith('genres'):
                _labels = [self.genres[v] for v in _values]
            elif key == 'decades':
                _labels = ['%ss' % str(v) for v in _values]
            elif key == 'media_types':
                _labels = ['Movies' if v == 'movie' else 'TV shows' for v in _values]
            else:
                _labels = [str(v) for v in _values]
            return _values, _labels
            
        if action == 'load':
            for key in PLAYLIST_KEYS:
                executebuiltin('SetProperty(%s,%s)' % (key, ' | '.join(_get_info()[1])))
        elif action == 'unload':
            for key in PLAYLIST_KEYS:
                executebuiltin('ClearProperty(%s)' % key)
        elif action in PLAYLIST_KEYS:
            key = action
            
            if key in self.input_items:
                dlg = Dialog()
                d = ', '.join(self.playlist.get(key) or [])
                ret = 0
                if d:
                    ret = dlg.yesnocustom(self.input_items[key]['label'] + ' - value already exists',
                                          'What would you like to do with the current value?[CR][I]%s[/I]' % d,
                                          'Clear', 'Modify', 'Replace')
                    if ret == 2:
                        d = ''
                if ret in (0, 1):
                    h = self.input_items[key]['header']
                    d = Dialog().input('%s[CR][I]Use commas to delimit multiple terms[/I]' % h,
                                       d if ret == 0 else '').strip() or d
                
                self.playlist[key] = [] if not d else [s.strip() for s in d.split(',')]
                executebuiltin('SetProperty(%s,%s)' % (key, ' | '.join(_get_info()[1])))
                self.save_playlist()
            elif key in self.list_items:
                items = self.list_items[key]
                
                executebuiltin('SetProperty(select_type,playlist_content,home)')
                executebuiltin('SetProperty(playlist_header,%s,home)' % PLAYLIST_STRINGS[key]['label'])
                executebuiltin('SetProperty(playlist_info,%s,home)' % PLAYLIST_STRINGS[key]['info'])
                sel = Dialog().multiselect(PLAYLIST_STRINGS[key]['label'], [item['label'] for item in items])
                executebuiltin('ClearProperty(playlist_header,home)')
                executebuiltin('ClearProperty(playlist_info,home)')
                executebuiltin('ClearProperty(select_type,home)')
                if sel is None:
                    return
                self.playlist[key] = [items[i]['value'] for i in sel]
                executebuiltin('SetProperty(%s,%s)' % (key, ' | '.join(_get_info()[1])))
                self.save_playlist()
                
    def get_playlist(self):
        self.cursor.execute('SELECT json FROM playlists WHERE user_id = ?', (self.user_id,))
        result = self.cursor.fetchone()
        if not result:
            return {'media_types': ['movie'], 'watched_status': ['unwatched'],
                    'created': datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        return json.loads(result[0])

    def save_playlist(self):
        existing_playlist = self.get_playlist()
        if self.playlist == existing_playlist:
            return
        self.playlist['created'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.cursor.execute('INSERT OR REPLACE INTO playlists(user_id, json) VALUES(?, ?)',
                            (self.user_id, json.dumps(self.playlist)))
        self.conn.commit()
        kodi_refresh()


class ArmaniUsers:
    def __init__(self):
        from caches.armani_settings import ArmaniSettings
        self.conn = sqlite3.connect(USER_DB)
        self.cursor = self.conn.cursor()
        self.settings = ArmaniSettings()
        try:
            self.user_id = int(self.settings.get('user_id') or '-1')
        except sqlite3.OperationalError:
            self.settings.create_database()
            self.user_id = int(self.settings.get('user_id') or '-1')
        
    def check(self):
        pass
    
    def create_database(self):
        self.cursor.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY,
                user_name TEXT NOT NULL UNIQUE,
                pin TEXT
            );
            CREATE TABLE IF NOT EXISTS favorites (
                user_id INTEGER,
                imdb_id TEXT,
                UNIQUE(user_id, imdb_id)
            );
            CREATE TABLE IF NOT EXISTS playlists (
                user_id INTEGER NOT NULL UNIQUE,
                json TEXT
            );
            CREATE TABLE IF NOT EXISTS settings (
                user_id INTEGER NOT NULL,
                setting_key TEXT NOT NULL,
                setting_value TEXT,
                UNIQUE(user_id, setting_key)
            );
        """)
        self.conn.commit()
            
    def get_users(self):
        """ Returns a dict list of all users (id, user_name, pin) """
        try:
            self.cursor.execute('SELECT id, user_name, pin FROM users ORDER BY user_name')
            return [{'id': r[0], 'user_name': r[1], 'pin': r[2]} for r in self.cursor.fetchall()]
        except:
            return []
    
    def get_current_user(self):
        """ Returns the saved user if it exists, or the default user the current user does not exist.

        Returns: Dict with keys 'id', 'user_name', 'pin'
        """
        user_id = int(self.settings.get('user_id') or '1')
        self.cursor.execute('SELECT id, user_name, pin FROM users WHERE id = ?', (user_id,))
        result = self.cursor.fetchone()
        if not result and user_id != 1:
            self.cursor.execute('SELECT id, user_name, pin FROM users WHERE id = 1')
            result = self.cursor.fetchone()
            self.settings.save('user_id', '1')
        if not result:
            # notification('Could not retrieve current user')
            return {}
        return {'id': result[0], 'user_name': result[1], 'pin': result[2]}
    
    def activate_user(self, user_id, silent=False) -> bool:
        """ Set the user with the specified id as the current user """
        self.cursor.execute('SELECT user_name, pin FROM users WHERE id = ?', (user_id,))
        result = self.cursor.fetchone()
        if not result:
            if not silent:
                notification('Invalid user: %d' % user_id)
            return False
        self.settings.save('user_id', user_id)
        self.user_id = user_id
        executebuiltin('SetProperty(user_id,%d,home)' % user_id)
        executebuiltin('SetProperty(user_name,%s,home)' % result[0])
        if not silent:
            notification(ls(33549) % result[0])
        return True
    
    def activate_current_user(self, silent=False) -> bool:
        """ Activate the current user (called when loading ArmaniFlix) """
        current_user = self.get_current_user()
        if not current_user:
            return False
        return self.activate_user(current_user['id'], silent)
    
    def reset_users(self, confirm=True):
        from modules.watched_status import delete_invalid_users
        if confirm and not Dialog().yesno('Confirm Reset', 'Resetting the user database will clear all favorites, playlists, and watch history. Proceed?'):
            return
        self.create_database()
        self.cursor.execute('SELECT id FROM users')
        self.cursor.execute('INSERT OR REPLACE INTO users(id, user_name, pin) VALUES(?, ?, ?)', (1, 'Default User', ''))
        self.cursor.execute('DELETE FROM users WHERE id != 1')
        self.cursor.execute('DELETE FROM favorites WHERE user_id != 1')
        self.cursor.execute('DELETE FROM playlists WHERE user_id != 1')
        self.conn.commit()
        delete_invalid_users()
        self.activate_user(1, True)
        notification('Reset user database')

    def select_user(self, require_pin_for_current=False) -> bool:
        import modules.armani_dialogs as armani_dialogs
        
        users = self.get_users()
        
        if not users:
            self.reset_users(False)
            return True
        
        current_user = self.get_current_user()

        if len(users) == 1:
            if not require_pin_for_current:
                self.activate_user(users[0]['id'])
                return True
            user = users[0]
        else:
            preselect = -1 if not current_user else users.index(current_user)
            index = armani_dialogs.menu(ls(33602), [u['user_name'] for u in users], preselect)
            if index < 0:
                return False
            elif index == preselect:
                if not require_pin_for_current:
                    self.activate_user(users[index]['id'])
                    return True

            user = users[index]
            
        if user['pin'] and get_pin() not in (user['pin'], MASTER_PIN):
            notification(33605)
            return False
        
        self.activate_user(user['id'])
        return True
        
    def get_ids(self):
        self.cursor.execute('SELECT id FROM users')
        return [r[0] for r in self.cursor.fetchall()]
    
    def delete_user(self, user_id=None):
        from modules.watched_status import delete_invalid_users
        import modules.armani_dialogs as armani_dialogs
        
        if user_id is None:
            users = [u for u in self.get_users() if u['id'] != 1]
            if not users:
                notification('You are the only user')
                return
            index = armani_dialogs.menu('Delete User', [u['user_name'] for u in users])
            if index < 0:
                return
            user_id = users[index]['id']

        self.cursor.execute('SELECT user_name, pin FROM users WHERE id = ?', (user_id,))
        user_data = self.cursor.fetchone()
        if not user_data:
            return
            
        if not Dialog().yesno('Delete Account?',
                              'Permanently delete [UPPERCASE][COLOR yellow]%s[/COLOR][/UPPERCASE]?' % user_data[0]):
            return

        self.cursor.execute('DELETE FROM users WHERE id = ?', (user_id,))
        self.cursor.execute('DELETE FROM favorites WHERE user_id = ?', (user_id,))
        self.cursor.execute('DELETE FROM playlists WHERE user_id = ?', (user_id,))
        self.conn.commit()
        delete_invalid_users()
        self.activate_current_user(True)
        notification('Account deleted')
    
    def modify_user(self, user_id=None):
        import modules.armani_dialogs as armani_dialogs
        
        if user_id is None:
            users = self.get_users()
            index = armani_dialogs.menu('Modify User', [u['user_name'] for u in users])
            if index < 0:
                return
            user_id = users[index]['id']
        
        user_id = int(user_id)
        self.cursor.execute('SELECT user_name, pin FROM users WHERE id = ?', (user_id,))
        user_data = self.cursor.fetchone()
        if not user_data:
            return
        user_name, user_pin = user_data
        if user_pin is None:
            user_pin = ''
            
        new_name = Dialog().input(ls(33527), user_name).strip() or user_name
        new_pin = get_pin(user_pin)
        self.cursor.execute('UPDATE users SET user_name = ?, pin = ? WHERE id = ?', (new_name, new_pin, user_id))
        self.conn.commit()
        notification(ls(33545) % user_name)
        self.activate_current_user(True)
        
    def add_user(self) -> bool:
        dlg = Dialog()
    
        user_name = dlg.input(ls(33527)).strip()
        if not user_name:
            return False
        
        self.cursor.execute('SELECT COUNT(*) FROM users WHERE user_name LIKE ?', (user_name,))
        if self.cursor.fetchone()[0] > 0:
            notification(ls(33528) % user_name.upper())
            return False
    
        user_pin = get_pin()
        if not user_pin:
            self.cursor.execute('INSERT INTO users(user_name) VALUES(?)', (user_name,))
        else:
            self.cursor.execute('INSERT INTO users(user_name,pin) VALUES(?,?)', (user_name, int(user_pin)))
            
        self.conn.commit()
        notification(ls(33530) % user_name)
        return True
    
    def is_favorite(self, imdb_id):
        self.cursor.execute('SELECT * FROM favorites WHERE user_id = ? AND imdb_id = ?', (self.user_id, imdb_id))
        return len(self.cursor.fetchall()) > 0
    
    def has_favorite(self):
        self.cursor.execute('SELECT COUNT(*) FROM favorites WHERE user_id = ?', (self.user_id,))
        return self.cursor.fetchone()[0] > 0
    
    def get_favorites(self):
        self.cursor.execute('SELECT imdb_id FROM favorites WHERE user_id = ?', (self.user_id,))
        results = self.cursor.fetchall()
        if not results:
            return []
        return [r[0] for r in results]
    
    def add_favorite(self, imdb_id):
        if self.user_id == -1:
            return
        self.cursor.execute('INSERT OR IGNORE INTO favorites(user_id, imdb_id) VALUES(?, ?)', (self.user_id, imdb_id))
        self.conn.commit()
        notification('Added', 2000)
        kodi_refresh()
        
    def remove_favorite(self, imdb_id):
        if self.user_id == -1:
            return
        self.cursor.execute('DELETE FROM favorites WHERE user_id = ? AND imdb_id = ?', (self.user_id, imdb_id))
        self.conn.commit()
        notification('Removed', 2000)
        kodi_refresh()
        
    def clear_favorites(self):
        self.cursor.execute('DELETE FROM favorites WHERE user_id = ?', (self.user_id,))
        self.conn.commit()
        kodi_refresh()
        notification('Cleared Favorites', 2000)
        
    def get_playlist(self):
        self.cursor.execute('SELECT json FROM playlists WHERE user_id = ?', (self.user_id,))
        result = self.cursor.fetchone()
        if not result:
            return {}
        return json.loads(result[0])
        
    def save_playlist(self, data: dict):
        if self.user_id == -1:
            return
        self.cursor.execute('INSERT OR REPLACE INTO playlists(user_id, json) VALUES(?, ?)',
                            (self.user_id, json.dumps(data)))
        self.conn.commit()
        