# -*- coding: utf-8 -*-
from modules import kodi_utils, settings
from modules.utils import adjust_premiered_date, get_datetime
from modules.watched_status import get_watched_info_tv, get_watched_status_season
from indexers.armani import next_episode

logger = kodi_utils.logger

make_listitem, build_url, external_browse, ls = kodi_utils.make_listitem, kodi_utils.build_url, kodi_utils.external_browse, kodi_utils.local_string
sys, add_items, set_content, end_directory, set_view_mode = kodi_utils.sys, kodi_utils.add_items, kodi_utils.set_content, kodi_utils.end_directory, kodi_utils.set_view_mode
kodi_version, xbmc_actor = kodi_utils.kodi_version, kodi_utils.xbmc_actor
adjust_premiered_date_function, get_datetime_function, get_watched_status, get_watched_info = adjust_premiered_date, get_datetime, get_watched_status_season, get_watched_info_tv
metadata_user_info, watched_indicators_info, show_unaired_info = settings.metadata_user_info, settings.watched_indicators, settings.show_unaired
get_art_provider, show_specials, use_season_title_info = settings.get_art_provider, settings.show_specials, settings.use_season_title
poster_empty, fanart_empty, build_content, make_placeholder = kodi_utils.empty_poster, kodi_utils.addon_fanart, kodi_utils.build_content, kodi_utils.make_placeholder_listitem
fen_str, trakt_str, season_str, watched_str, unwatched_str = ls(33200), ls(32037), ls(32537), ls(32642), ls(32643)
extras_str, options_str, refr_widg_str = ls(32645), ls(32646), ls(40001)
string, run_plugin, unaired_label, tmdb_poster_prefix = str, 'RunPlugin(%s)', '[COLOR red][I]%s[/I][/COLOR]', 'https://image.tmdb.org/t/p/'
view_mode, content_type = 'view.seasons', 'seasons'
season_name_str = '%s %s'


def build_season_list(params):
    def _process():
        
        for season_number in range(1, armani_meta['total_seasons'] + 1):
            season_episodes = armani_meta['episodes'][str(season_number)]
            if not season_episodes:
                break
            min_ep = min(season_episodes.keys())
            max_ep = max(season_episodes.keys())
            episode_count = len(season_episodes)
            first_episode = season_episodes[min_ep]
            last_episode = season_episodes[max_ep]
            release_date = first_episode['release_date']
            if not release_date:
                break
            title = 'Season %s' % season_number
            year = release_date.split('-')[0]
            plot = 'Premiered: %s[CR]Ended: %s' % (first_episode['release_date'], last_episode['release_date'])
            plot += '[CR][CR][I]%s[/I][CR]%s' % (first_episode['title'], first_episode['plot'])
            try:
                listitem = make_listitem()
                set_properties = listitem.setProperties
                playcount, overlay, watched, unwatched = get_watched_status(watched_info,
                                                                            str(armani_meta['tmdb_id']),
                                                                            season_number, episode_count)
                try:
                    progress = int((float(watched) / episode_count) * 100)
                except:
                    progress = 0
                
                # Watched status
                watched_params, unwatched_params = '', ''
                if playcount or progress:
                    unwatched_params = build_url(
                        {'mode': 'watched_status.mark_season', 'action': 'mark_as_unwatched', 'title': title,
                         'year': year, 'tmdb_id': tmdb_id,
                         'tvdb_id': '', 'season': season_number})
                else:
                    watched_params = build_url(
                        {'mode': 'watched_status.mark_season', 'action': 'mark_as_watched', 'title': title,
                         'year': year, 'tmdb_id': tmdb_id,
                         'tvdb_id': '', 'season': season_number})
                set_properties({'fen.unwatched_params': unwatched_params, 'fen.watched_params': watched_params})

                armani_insert_params = {'mode': 'armani_admin', 'action': 'imdb_search', 'db_type': 'tvshow'}
                url_params = build_url({'mode': 'build_episode_list', 'imdb_id': imdb_id, 'tmdb_id': tmdb_id, 'season': season_number})
                if progress:
                    if hide_watched: continue
                    set_properties({'watchedepisodes': string(watched), 'unwatchedepisodes': string(unwatched)})
                set_properties({'totalepisodes': string(episode_count), 'watchedprogress': string(progress),
                                'fen.playcount': string(playcount), 'armani_add_params': build_url(armani_insert_params)})
                
                info_tag = listitem.getVideoInfoTag()
                info_tag.setMediaType('season')
                info_tag.setTitle(title)
                info_tag.setOriginalTitle(title)
                info_tag.setTvShowStatus(armani_meta['status'])
                info_tag.setTvShowTitle(armani_meta['original_title'])
                info_tag.setSeason(season_number)
                info_tag.setPlot(plot)
                info_tag.setYear(int(year))
                info_tag.setFirstAired(release_date)
                info_tag.setStudios(('',))
                info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id)})
                info_tag.setIMDBNumber(imdb_id)
                info_tag.setGenres(armani_meta['genre'].split(', '))
                info_tag.setPlaycount(playcount)

                if armani_meta.get('status') == 'Returning Series':
                    listitem.setProperty('armani_episode_refresh', build_url({'mode': 'armani_admin',
                                                                              'imdb_id': imdb_id,
                                                                              'action': 'update_episodes'}))
                
                listitem.setLabel(title)
                if is_widget: set_properties({'fen.widget': 'true'})
                yield (url_params, listitem, True)
            except:
                pass
    
    handle, is_widget = int(sys.argv[1]), external_browse()
    if build_content():
        from caches.armani_cache import armani
        armani_meta = armani.get_meta_imdb(params['imdb_id'])
        if not armani_meta['episodes']:
            armani.update_metadata(params['imdb_id'])
        armani_meta = armani.get_meta_imdb(params['imdb_id'])
        imdb_id = armani_meta['imdb_id']
        tmdb_id = armani_meta['tmdb_id']
        
        meta_user_info, watched_indicators, show_unaired = metadata_user_info(), watched_indicators_info(), show_unaired_info()
        watched_info, current_date, use_season_title = get_watched_info(
            watched_indicators), get_datetime_function(), use_season_title_info()
        image_resolution, hide_watched = meta_user_info['image_resolution']['poster'], is_widget and meta_user_info[
            'widget_hide_watched']
        
        next_ep = next_episode(armani_meta)
        if next_ep:
            add_items(handle, [next_ep])
        add_items(handle, list(_process()))
    else:
        add_items(handle, make_placeholder())
    set_content(handle, content_type)
    end_directory(handle, False if is_widget else None)
    if not is_widget: set_view_mode(view_mode, content_type)
