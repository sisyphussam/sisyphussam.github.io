import requests
import json
from modules.kodi_utils import notification, logger
from xbmcgui import Dialog, DialogProgress
from modules.armani_utils import get_sort_title, get_file_path
from time import sleep
from random import randint
from datetime import datetime, timedelta

TODAY = datetime.today()

IMDB_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "DNT": "1",
                "Connection": "close",
                "Upgrade-Insecure-Requests": "1"}

IMDB_URL_ADVANCED_BASE = 'https://www.imdb.com/search/title/?sort=num_votes,desc&country_of_origin=!IN,!TR,!PK&'
IMDB_URL_PERSON_FIND = 'https://www.imdb.com/find/?s=nm&q=%s'
DEFAULT_TITLE_TYPE = 'title_type=feature,short,tv_series,tv_miniseries,tv_movie'

IMDB_GENRES = {
    'Action': 'act', 'Adult': 'adu', 'Adventure': 'adv', 'Animation': 'ani', 'Biography': 'bio',
    'Comedy': 'com', 'Crime': 'cri', 'Documentary': 'doc', 'Drama': 'dra', 'Family': 'fam',
    'Fantasy': 'fan', 'Film-Noir': 'fil', 'Game-Show': 'gam', 'History': 'his', 'Horror': 'hor',
    'Music': 'muc', 'Musical': 'mus', 'Mystery': 'mys', 'News': 'new', 'Reality-TV': 'rea',
    'Romance': 'rom', 'Sci-Fi': 'sci', 'Short': 'sho', 'Sport': 'spo', 'Talk-Show': 'tal',
    'Thriller': 'thr', 'War': 'war', 'Western': 'wes'
}

IMDB_KEYWORDS = [
    ('action-hero', 'Action Hero'),
    ('anime', 'Anime'),
    ('based-on-true-story', 'Based on True Story'),
    ('child-protagonist', 'Child Protagonist'),
    ('dc-comics', 'Comics: DC'),
    ('marvel-comics', 'Comics: Marvel'),
    ('marvel-cinematic-universe', 'Comics: MCU'),
    ('courtroom-drama', 'Courtroom Drama'),
    ('alien', 'Creatures: Aliens'),
    ('monster', 'Creatures: Monsters'),
    ('vampire', 'Creatures: Vampires'),
    ('werewolf', 'Creatures: Werewolves'),
    ('zombie', 'Creatures: Zombies'),
    ('dark-comedy', 'Dark Comedy'),
    ('dystopia', 'Dystopian'),
    ('high-school', 'High School'),
    ('official-bond-film', 'James Bond'),
    ('neo-noir', 'Neo Noir'),
    ('silent-film', 'Silent Film'),
    ('slasher', 'Slasher'),
    ('superhero', 'Superhero'),
    ('surrealism', 'Surrealism'),
    ('survival-horror', 'Survival Horror'),
    ('teenage-protagonist', 'Teenage Protagonist'),
    ('teen-comedy', 'Teen Comedy'),
    ('teen-drama', 'Teen Drama')
]

IMDB_TITLE_TYPES = [
    ('feature', 'Feature Film'),
    ('tv_movie', 'TV Movie'),
    ('short', 'Short Film'),
    ('tv_series', 'TV Series'),
    ('tv_miniseries', 'TV Miniseries'),
    ('tv_special', 'TV Special')
]

IMDB_CERTIFICATES = [
    'G', 'PG', 'PG-13', 'R', 'NC-17'
]

IMDB_ADVANCED_LANGUAGES = [
    ('Any', ''),
    ('English', '&primary_language=en'),
    ('Non-English', '&primary_language=!en'),
    ('Arabic', '&primary_language=ar'),
    ('Chinese', '&primary_language=zh,yue,cmn'),
    ('Danish', '&primary_language=da'),
    ('French', '&primary_language=fr'),
    ('German', '&primary_language=de'),
    ('Italian', '&primary_language=it'),
    ('Japanese', '&primary_language=ja'),
    ('Korean', '&primary_language=ko'),
    ('Norwegian', '&primary_language=no'),
    ('Persian', '&primary_language=fa'),
    ('Portuguese', '&primary_language=pt'),
    ('Russian', '&primary_language=ru'),
    ('Spanish', '&primary_language=es'),
    ('Swedish', '&primary_language=sv')
]

IMDB_SEARCH_FILTER = get_file_path('imdb/search_filter.json')
IMDB_CUSTOM = get_file_path('imdb/custom_values.json')
IMDB_LISTS = get_file_path('imdb/lists.json')
IMDB_USER_ID = 'ur163156999'


def check():
    from xbmcvfs import mkdir, exists
    imdb_path = get_file_path('imdb/')
    if not exists(imdb_path):
        mkdir(imdb_path)
        
        
def get_imdb_text(url, session=None) -> str:
    """ Returns the HTML of a web page.

    Args:
        url: IMDb URL
        session: (optional) requests session

    Returns:
        Returns the text (HTML) of a web page if it is successfully retrieved, an empty string otherwise

    """
    response = requests.get(url, headers=IMDB_HEADERS) if not session else session.get(url, headers=IMDB_HEADERS)
    if response.status_code != 200:
        notification('Error retrieving url')
        logger('get_imdb_text: failed', url)
        return ''
    return response.text


def get_imdb_json(url: str, split_a: str, split_b: str, session=None) -> dict:
    """ Return JSON found between two strings in a web page containing javascript.

    Args:
        url: IMDb URL
        split_a: JSON begins after this string
        split_b: JSON begins before this string
        session: (optional) requests session

    Returns:
        Returns the JSON if it exists, an empty dictionary otherwise

    """
    # Perform the search and extract results from javascript JSON
    json_text = get_imdb_text(url, session)
    if not json_text:
        return {}
    try:
        json_text = json_text.split(split_a)[1].split(split_b)[0]
    except IndexError:
        notification('Error retrieving data')
        logger('get_imdb_json: scrape error', url)
    
    try:
        data = json.loads(json_text)
        return data
    except json.JSONDecodeError:
        notification('Error retrieving data')
        logger('get_imdb_json: parse error', url)
        return {}


def get_imdb_lists() -> dict:
    """ Load list data from "imdb_lists.json"

    Returns:
        Returns a dict containing IMDb lists and their items

    """
    try:
        with open(IMDB_LISTS, 'r') as fp:
            data = json.load(fp)
    except:
        data = {}
    return data


def get_imdb_list_items() -> dict:
    """ Get items from all lists sorted by sort title

    Returns:
        Returns a dict of sorted items from IMDb lists

    """
    data = get_imdb_lists()
    imdb_lists = [{'id': k, 'name': v['name'], 'count': v['count'], 'items': v['items']} for k, v in data.items()]
    if not imdb_lists:
        return {}
    imdb_dict = {}
    for imdb_list in imdb_lists:
        imdb_dict.update({r['imdb_id']: r for r in imdb_list['items']})
    sorted_items = list(imdb_dict.values())
    sorted_items.sort(key=lambda k: k['release_date'])
    sorted_items.sort(key=lambda k: k['sort_title'])
        
    return {d['imdb_id']: d for d in sorted_items}


def refresh_imdb_lists():
    """ Download and saves IMDb lists to "imdb_lists.json" """
    from modules.armani_utils import str_to_int
    from xbmcgui import DialogProgressBG

    list_data = {}
    imdb_lists = []
    months = {
        'January': '01', 'February': '02', 'March': '03', 'April': '04', 'May': '05',
        'June': '06', 'July': '07', 'August': '08', 'September': '09',
        'October': '10', 'November': '11', 'December': '12'
    }
    
    # Get HTML of user's IMDb lists page
    html = get_imdb_text('https://www.imdb.com/user/%s/lists?sort=name&order=asc' % IMDB_USER_ID)
    if not html:
        notification('Lists not found')
        return
    html = html.replace('\n', '')
    if '<a class="list-name" href="/list/' not in html:
        notification('Lists not found')
        return
    
    # Parse HTML to create list dictionary
    html_rows = html.split('<a class="list-name" href="/list/')
    html_rows.pop(0)
    for h in html_rows:
        try:
            list_id, h = h.split('/', maxsplit=1)
            list_name, h = h.split('">', maxsplit=1)[1].split('</a>', maxsplit=1)
            list_count = str_to_int(h.split('<div class="list-meta">')[1].split(' titles')[0])
            modified = h.split('<div>Modified ')[1].split(' |')[0]
            d, m, y = modified.split(maxsplit=2)
            list_modified = '%s-%s-%s' % (y, months[m], d.zfill(2))
            imdb_lists.append({'id': list_id, 'name': list_name, 'count': list_count, 'modified': list_modified})
        except:
            continue
    if not imdb_lists:
        notification('Lists not found')
        return

    # Create list data from downloaded CSV files and save
    prog = DialogProgressBG()
    prog.create('Updating Lists')
    i = 0
    for imdb_list in imdb_lists:
        list_id = imdb_list['id']
        data = {'name': imdb_list['name'], 'count': imdb_list['count'], 'modified': imdb_list['modified']}
        items = _download_imdb_csv(list_id)
        if items:
            prog.update(int(i * 100 / len(imdb_lists)), 'Updated [COLOR yellow]%s[/COLOR]' % data['name'])
            data['items'] = items
            list_data[list_id] = data
            sleep(randint(2, 3))
        i += 1
    with open(IMDB_LISTS, 'w') as fp:
        json.dump(list_data, fp)
    prog.close()


def _download_imdb_csv(list_id):
    """ Retrieve parsed CSV associated with the specified list """
    import csv
    import requests
    from modules.armani_utils import get_sort_title, get_search_string
    from modules.kodi_utils import notification
    
    # Download the CSV
    csv_url = 'https://www.imdb.com/list/%s/export?ref_=ttls_exp' % list_id
    download = requests.get(csv_url, headers=IMDB_HEADERS)
    if download.status_code != 200:
        notification('CSV could not be downloaded')
        return None
    decoded_content = download.content.decode('utf-8')
    rows = list(csv.reader(decoded_content.splitlines(), delimiter=','))
    rows.pop(0)  # remove header row
    if not rows:
        notification('Empty list')
        return None
    
    results = []
    
    for row in rows:
        # Load defaults from CSV columns
        row_data = {
            'imdb_id': row[1],
            'db_type': 'movie' if row[7] in ('movie', 'short', 'tvMovie') else 'tvshow',
            'title': row[5],
            'sort_title': None,
            'release_date': row[13],
            'year': int(row[10]),
            'runtime': int(row[9]),
            'genre_ids': [IMDB_GENRES[g] for g in row[11].split(', ')],
            'director': '' if not row[14] else row[14].split(', ')[0],
            'rating': float(row[8]),
            'votes': int(row[12]),
            'index': int(row[0]),
            'created': row[2],
            'modified': row[3],
        }
        
        # Parse comment for custom title, sort title, and genre IDs
        comment = row[4].strip()
        if comment:
            lines = comment.split('||')
            for line in lines:
                if '=' not in line:
                    logger('%s: Invalid comment' % list_id, str(row))
                    continue
                if line.count('=') > 1:
                    logger('%s: Too many "="' % list_id, row)
                    continue
                k, v = line.split('=')
                k = k.strip().lower()
                v = v.strip()
                if not k or not v:
                    logger('%s: invalid comment')
                    continue
                if k == 't':
                    row_data['title'] = v
                elif k == 's':
                    row_data['sort_title'] = v.upper()
                elif k == 'g':
                    genre_ids = [g.strip() for g in v.split(',')]
                    row_data['genre_ids'] = genre_ids
                else:
                    logger('%s: Invalid key (%s)' % (list_id, k), str(row))
        
        # Set the sort_title if a custom sort_title wasn't in the comment, and set the starting letter
        if not row_data.get('sort_title'):
            row_data['sort_title'] = get_sort_title(row_data['title'])
        row_data['alpha'] = row_data['sort_title'][0] if row_data['sort_title'][0].isalpha() else '#'
        
        # Search string contains the original and custom title
        search_words = [row[5], row_data['title']]
        if row[14].strip():
            search_words.append(row[14].strip())
        search_words = list(dict.fromkeys(search_words))
        row_data['search_string'] = '||'.join(get_search_string(w) for w in search_words)
        
        results.append(row_data)
    
    return results


def imdb_person_search() -> dict:
    """ Search IMDb for a person's name

    Returns:
        A dict containing the id, name, and "known for" title of the found person

    """
    # Get query
    dlg = Dialog()
    query = dlg.input('Find a person').strip()
    if not query:
        return {}
    
    # Perform the search and extract results from javascript JSON
    json_text = get_imdb_text(IMDB_URL_PERSON_FIND % query)
    if not json_text:
        return {}
    json_text = json_text.split('"nameResults":')[1].split(',"titleResults":')[0]
    data = json.loads(json_text)
    data = data['results']
    if not data:
        notification('No results for "%s"' % query)
        return {}
    
    # Remove people that don't have a "known_for" field
    results = {}
    for d in data:
        try:
            r = {'id': d['id'], 'name': d['displayNameText'],
                 'known_for': '%s (%s)' % (d['knownForTitleText'], d['knownForTitleYear'])}
            results[d['id']] = r
            pass
        except KeyError:
            continue
    if not results:
        notification('No results for "%s"' % query)
        return {}
        
    results = list(results.values())
    return results[0]


def imdb_person_title_search(min_rating=5, min_votes=2000, pages=5):
    person = imdb_person_search()
    if not person:
        return None
    url_tail = 'min_rating=%.1f&role=%s' % (min_rating, person['id'])
    return imdb_advanced_search_url(url_tail, pages, min_votes)


def imdb_title_search(min_rating=0, min_votes=2000, pages=3):
    from xbmcgui import Dialog
    title = Dialog().input('Search for the title of a movie or show').strip()
    if not title:
        return None
    url_tail = 'min_rating=%.1f&title=%s' % (min_rating, title)
    return imdb_advanced_search_url(url_tail, pages, min_votes)
    

def imdb_advanced_search_menu(load_previous=False, num_pages=5):
    """ Perform an advanced search using a menu and return results

    Returns:
        Returns a list of search results

    """
    from xbmcgui import ListItem, Dialog
    from modules.armani_utils import dialog_detail_menu, dialog_menu, dialog_include_exclude, dialog_min_max
    
    def _get_default_filter() -> dict:
        return {
            'title': '',
            'title_types': [0],
            'genres': [],
            'keywords': [],
            'language': 0,
            'years': [1900, TODAY.year],
            'certificate': '',
            'person': {},
            'rating': [50, 100],
            'min_votes': 5000
        }

    def _get_search_filter() -> dict:
        with open(IMDB_SEARCH_FILTER, 'r') as _fp:
            _data = json.load(_fp)
        return {
            'title': _data.get('title', ''),
            'title_types': _data.get('title_types', [0]),
            'genres': _data.get('genres', []),
            'keywords': _data.get('keywords', []),
            'language': _data.get('language', 0),
            'years': _data.get('years', [1900, TODAY.year]),
            'certificate': _data.get('certificate', ''),
            'person': _data.get('person', {}),
            'rating': _data.get('rating', [50, 100]),
            'min_votes': _data.get('min_votes', 5000),
        }

    def _save_search_filter():
        with open(IMDB_SEARCH_FILTER, 'w') as fp:
            json.dump(cur_filter, fp)
    
    def _update_filters():
        _v = cur_filter['title']
        filters['title'].update({'label2': _v, 'param': '' if not _v else '&title=%s' % _v})

        _v = [IMDB_TITLE_TYPES[i] for i in cur_filter['title_types']]
        filters['title_types'].update({'label2': ', '.join(t[1] for t in _v),
                                       'param': '&title_type=%s' % ','.join(t[0] for t in _v)})
        
        _v = cur_filter['certificate']
        filters['certificate'].update({'label2': _v, 'param': '' if not _v else '&certificates=US:%s' % _v})

        _v = cur_filter['genres']
        filters['genres'].update({'label2': ', '.join(_v),
                                  'param': '' if not _v else '&genres=%s' % ','.join(_v)})
        
        _v = cur_filter['keywords']
        filters['keywords'].update({'label2': ', '.join(_v),
                                    'param': '' if not _v else '&keywords=%s' % ','.join(_v)})
        
        _v = cur_filter['language']
        filters['language'].update({'label2': IMDB_ADVANCED_LANGUAGES[_v][0],
                                    'param': IMDB_ADVANCED_LANGUAGES[_v][1]})
        
        _v = cur_filter['years']
        filters['years'].update({'label2': '%d - %d' % (_v[0], _v[1]),
                                 'param': '&release_date=%d-01-01,%d-12-31' % (_v[0], _v[1])})

        _v = cur_filter['person']
        if _v:
            filters['person'].update({'label2': _v['name'], 'param': '&role=%s' % _v['id']})
        else:
            filters['person'].update({'label2': '', 'param': ''})

        _v = cur_filter['rating']
        if _v[0] == 0 and _v[1] == 100:
            filters['rating'].update({'label2': '0 - 100', 'param': ''})
        else:
            _r1, _r2 = '%.1f' % float(_v[0] / 10), '%.1f' % float(_v[1] / 10)
            filters['rating'].update({'label2': '%d - %d' % (_v[0], _v[1]),
                                      'param': '&user_rating=%s,%s' % (_r1, _r2)})
            
        filters['min_votes']['label2'] = str(cur_filter['min_votes'])
            
    def _select_main():
        _items = [ListItem('[COLOR white]%s[/COLOR]' % f['label'],
                           '[COLOR lightgrey]%s[/COLOR]' % f['label2']) for f in filter_values]
        _items.append(ListItem('[COLOR yellow][B]SEARCH[/B][/COLOR]'))
        
        _pre = -1
        if selection in filters:
            _pre = filter_keys.index(selection)
        elif selection == 'search':
            _pre = len(_items) - 1
            
        _i = dialog_detail_menu('IMDb Advanced Search', _items, True, _pre, 'advanced_search')
        if _i < 0:
            return 'cancel'
        if _i == len(_items) - 1:
            return 'search'
        return filter_keys[_i]
    
    def _perform_search() -> list:
        _url_tail = ''
        for _f in filter_values:
            if 'param' not in _f:
                continue
            _url_tail += _f['param']
            
        _results = imdb_advanced_search_url(_url_tail, num_pages, cur_filter['min_votes'])
        _save_search_filter()
        
        if not _results:
            return []
        return _results

    filters = {
        'title': {'label': 'Title'},
        'title_types': {'label': 'Media Types'},
        'person': {'label': 'Cast or Crew'},
        'genres': {'label': 'Genres'},
        'keywords': {'label': 'Keywords'},
        'years': {'label': 'Release Dates'},
        'language': {'label': 'Primary Language'},
        'certificate': {'label': 'Certificate'},
        'rating': {'label': 'IMDb Rating'},
        'min_votes': {'label': 'Minimum Vote Count'}
    }
    filter_keys = list(filters.keys())
    filter_values = list(filters.values())
    
    cur_filter = _get_search_filter() if load_previous else _get_default_filter()
    genre_dic = {k: k for k in IMDB_GENRES.keys()}
    keyword_dic = {w[0]: w[1] for w in IMDB_KEYWORDS}
    
    votes = [0, 250, 500, 1000, 2500, 5000, 10000, 25000, 50000, 100000, 250000, 500000, 1000000, 2500000]
    
    dlg = Dialog()
    selection = ''
    
    while 1:
        _update_filters()
        
        selection = _select_main()
        if selection == 'cancel':
            return None
        
        if selection == 'search':
            results = _perform_search()
            if results:
                return results
        elif selection == 'title':
            cur_filter['title'] = dlg.input('Search for a title').strip()
        elif selection == 'title_types':
            sel = dlg.multiselect('Media Types', [t[1] for t in IMDB_TITLE_TYPES])
            if sel is None:
                continue
            cur_filter['title_types'] = [0] if not sel else sel
        elif selection == 'genres':
            cur_filter['genres'] = dialog_include_exclude('Genres', genre_dic, cur_filter['genres'])
                
        elif selection == 'keywords':
            cur_filter['keywords'] = dialog_include_exclude('Keywords', keyword_dic, cur_filter['keywords'])
            
        elif selection == 'years':
            cur_filter['years'] = dialog_min_max('Release Year', (1900, TODAY.year),
                                                 cur_filter['years'][0], cur_filter['years'][1])
                
        elif selection == 'language':
            i = dialog_menu('Primary Languages', [p[0] for p in IMDB_ADVANCED_LANGUAGES], cur_filter['language'])
            if i > -1:
                cur_filter['language'] = i
        elif selection == 'certificate':
            i = dialog_menu('Certificate', IMDB_CERTIFICATES)
            cur_filter['certificate'] = '' if i < 0 else IMDB_CERTIFICATES[i]
        elif selection == 'person':
            cur_filter['person'] = imdb_person_search()
        elif selection == 'rating':
            cur_filter['rating'] = dialog_min_max('IMDb Rating', (0, 100),
                                                  cur_filter['rating'][0], cur_filter['rating'][1])
        elif selection == 'min_votes':
            pre = -1 if cur_filter['min_votes'] not in votes else votes.index(cur_filter['min_votes'])
            i = dialog_menu('Minimum Vote Count', [str(v) for v in votes], pre)
            if i < 0:
                continue
            cur_filter['min_votes'] = votes[i]
           

def imdb_advanced_search_url(url_tail: str, total_pages=3, min_votes=5000) -> list:
    """ Return advanced search results with the most votes sorted by title

    Args:
        url_tail: The URL parameters (e.g, "user_rating=8,&role=nm1010101")
        total_pages: The number of pages to parse (each contains 50 titles)
        min_votes: The minimum vote count (num_votes must not be in url_tail)

    Returns:
        Returns a list of sorted search results

    """
    if not url_tail:
        return []
    
    if 'title_type' not in url_tail:
        url_tail += '&' + DEFAULT_TITLE_TYPE
    if url_tail.startswith('&'):
        url_tail = url_tail[1:]
    url = IMDB_URL_ADVANCED_BASE + url_tail
    
    list_data = get_imdb_list_items()
    
    results = {}
    
    page_count = 0
    max_votes = -1
    
    prog = DialogProgress()
    h = 'Fetching list of titles...'
    prog.create('Performing search', 'Please wait...')
    while page_count < total_pages:
        if -1 < max_votes <= min_votes:
            break
        if prog.iscanceled():
            break
        
        page_url = url + '&num_votes=%d,' % min_votes
        
        if max_votes > -1:
            page_url += '%d' % max_votes
        logger('ADVANCED SEARCH', page_url)
        prog.update(int(100 * page_count / total_pages),
                    '%s\n  Page: %d of %d\n  Scanned: %d titles' % (h, page_count + 1, total_pages, len(results)))
        
        if page_count > 0:
            sleep(randint(2, 3))
        page_count += 1
        
        json_text = get_imdb_text(page_url)
        if not json_text:
            break
        
        try:
            json_text = json_text.split('"titleListItems":')[1].split(',"total":')[0]
        except IndexError:
            notification('Error parsing URL')
            logger('PARSE FAILURE', page_url)
            break
        
        json_data = json.loads(json_text)
        last_page = len(json_data) < 50
        for d in json_data:
            if not d['genres']:
                continue
            data = {
                'id': d['titleId'],
                'title': d['titleText'],
                'sort_title': get_sort_title(d['titleText']),
                'year': d['releaseYear'],
                'genres': d['genres'],
                'type': d['titleType']['id'],
                'plot': d['plot'],
                'rating': d['ratingSummary']['aggregateRating'],
                'votes': d['ratingSummary']['voteCount']
            }
            data['release_date'] = '%s-01-01' % data['year']
            if data['id'] in list_data:
                data['title'] = list_data[data['id']]['title']
                data['sort_title'] = list_data[data['id']]['sort_title']
                data['release_date'] = list_data[data['id']]['release_date']
            
            max_votes = data['votes']
            data['media_type'] = 'TV' if data['type'] in ('tvSeries', 'tvMiniSeries') else 'MOVIE'
            
            data['label'] = '%s / %s (%d) | %.1f (%d)' % (
                data['media_type'], data['title'], data['year'], data['rating'], data['votes'])
            results[d['titleId']] = data
        if last_page:
            break
            
    prog.close()
    
    output = sorted(list(results.values()), key=lambda k: k['release_date'])
    output.sort(key=lambda k: k['sort_title'])
    output.sort(key=lambda k: k['media_type'])
    return output
