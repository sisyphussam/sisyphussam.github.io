from modules.kodi_utils import logger

import sqlite3
from xbmcvfs import translatePath
import json

SETTINGS_DB = translatePath('special://profile/addon_data/plugin.video.armaniflix/armani_settings.db')


class ArmaniSettings:
    def __init__(self):
        self.conn = sqlite3.connect(SETTINGS_DB)
        self.cursor = self.conn.cursor()
        
    def check(self):
        pass
    
    def get(self, setting_id: str):
        self.cursor.execute('SELECT value FROM settings WHERE id = ?', (setting_id,))
        result = self.cursor.fetchone()
        if not result:
            return None
        return result[0]
    
    def get_json(self, setting_id: str):
        return json.loads(self.get(setting_id) or "{}")
    
    def save_config(self, data):
        self.save_json('genres', data['genres'])
        self.save_json('countries', data['countries'])
        self.save_json('languages', data['languages'])
    
    def source_manager(self):
        from xbmcgui import Dialog
        from modules.kodi_utils import notification
        from caches.armani_cache import armani
        
        self.cursor.execute('SELECT imdb_id FROM sources')
        results = self.cursor.fetchall()
        if not results:
            notification('No sources have been saved')
            return
        delete_ids = [r[0] for r in results if not armani.get_meta_imdb(r[0])]
        if delete_ids:
            for imdb_id in delete_ids:
                self.cursor.execute('DELETE FROM sources WHERE imdb_id = ?', (imdb_id,))
            self.conn.commit()
            notification('Cleaned sources (%d removed)' % len(delete_ids))
            
        imdb_ids = [r[0] for r in results if r[0] not in delete_ids]
        meta_list = armani.get_meta_list('WHERE imdb_id IN (%s)' % ','.join(['?'] * len(imdb_ids)),
                                         imdb_ids, 'db_type, sort_title, release_date')
        labels = ['%s/%s (%s)' % (m['db_type'], m['title'], m['year']) for m in meta_list]

        sel = Dialog().multiselect('Delete Saved Sources', labels)
        if not sel:
            return
        
        delete_ids = [meta_list[i]['imdb_id'] for i in sel]
        for imdb_id in delete_ids:
            self.cursor.execute('DELETE FROM sources WHERE imdb_id = ?', (imdb_id,))
        self.conn.commit()
        notification('Removed %d sources' % len(delete_ids))
        
    def set_source_url(self, url, imdb_id, season='', episode=''):
        self.cursor.execute('INSERT OR REPLACE INTO source_info (url, imdb_id, season, episode) VALUES(?, ?, ?, ?)',
                            (url, imdb_id, season, episode))
        self.conn.commit()
        
    def get_source_url(self, imdb_id, season='', episode=''):
        self.cursor.execute('SELECT url FROM source_info WHERE imdb_id = ? AND season = ? and episode = ?',
                            (imdb_id, season, episode))
        result = self.cursor.fetchone()
        return None if not result else result[0]
    
    def is_source(self, imdb_id, hash_string):
        self.cursor.execute('SELECT COUNT(*) FROM sources WHERE imdb_id = ? AND hash = ?', (imdb_id, hash_string))
        result = self.cursor.fetchone()
        return result[0] > 0
    
    def set_source(self, imdb_id, hash_string):
        self.cursor.execute('INSERT OR REPLACE INTO sources (imdb_id, hash) VALUES(?, ?)', (imdb_id, hash_string))
        self.conn.commit()
        
    def is_resetting(self, value: str):
        return value in self.__get_reset_list()
        
    def add_reset(self, value: str):
        reset_list = self.__get_reset_list()
        if value in reset_list:
            return
        reset_list.append(value)
        self.save('reset', ','.join(reset_list))
        
    def remove_reset(self, value):
        reset_list = self.__get_reset_list()
        if value not in reset_list:
            return
        reset_list.remove(value)
        self.save('reset', ','.join(reset_list))
        
    def __get_reset_list(self):
        self.cursor.execute('SELECT reset FROM settings')
        result = self.cursor.fetchone()
        return [] if not result else result[0].split(',')
        
    def get_user(self):
        return self.get('user_id'), self.get('user_name')
    
    def set_user(self, user_id: str, user_name: str):
        self.save('user_id', user_id)
        self.save('user_name', user_name)
        
    def save(self, setting_id: str, setting_value: str):
        self.cursor.execute('INSERT OR REPLACE INTO settings(id, value) VALUES(?, ?)', (setting_id, setting_value))
        self.conn.commit()
        
    def save_json(self, setting_id: str, setting_json: dict):
        self.save(setting_id, json.dumps(setting_json))
        