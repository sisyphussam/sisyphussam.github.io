import sqlite3
from xbmcvfs import translatePath
from xbmc import executebuiltin
from xbmcgui import Dialog
import json


SETTINGS_DB = translatePath('special://profile/addon_data/plugin.video.armaniflix/armani_settings.db')


def admin_commands():
    def _clear_caches():
        from modules.kodi_utils import favorites_db, metacache_db, maincache_db, debridcache_db, notification
        dbcon = sqlite3.connect(favorites_db)
        dbcon.execute('DELETE FROM favourites')  # ArmaniFlix doesn't use them anyway
        dbcon.commit()
        dbcon.close()
        
        dbcon = sqlite3.connect(metacache_db)
        dbcon.execute('DELETE FROM metadata')
        dbcon.execute('DELETE FROM season_metadata')
        dbcon.execute('DELETE FROM function_cache')
        dbcon.commit()
        dbcon.close()
        
        dbcon = sqlite3.connect(maincache_db)
        dbcon.execute('DELETE FROM maincache')
        dbcon.commit()
        dbcon.close()

        dbcon = sqlite3.connect(debridcache_db)
        dbcon.execute('DELETE FROM debrid_data')
        dbcon.commit()
        dbcon.close()
        notification('Cleared all caches')
        
    
    from caches.armani_users import ArmaniUsers
    from caches.armani_cache import armani
    
    dlg = Dialog()
    armani_users = ArmaniUsers()
    
    if armani_users.user_id != 1:
        dlg.ok('Permission Denied', 'Only the primary user can access the advanced options.')
        return
    
    options = [
        {'label': 'Update Database', 'exec': 'armani.download_updates(False)'},
        {'label': 'Add Media Entry', 'exec': 'armani.add_edit_entry()'},
        {'label': 'Add User', 'exec': 'armani_users.add_user()'},
        {'label': 'Real-Debrid Info',
         'exec': 'executebuiltin("PlayMedia(plugin://plugin.video.armaniflix/?mode=real_debrid.rd_account_info)")'},
        {'label': 'Settings: [COLOR yellow]ArmaniFlix[/COLOR]',
         'exec': 'executebuiltin("Addon.OpenSettings(plugin.video.armaniflix)")'},
        {'label': 'Settings: [COLOR yellow]Kodi[/COLOR]',
         'exec': 'executebuiltin("ActivateWindow(settings)")'},
        {'label': 'Settings: [COLOR yellow]Cocoscrapers[/COLOR]',
         'exec': 'executebuiltin("Addon.OpenSettings(script.module.cocoscrapers)")'},
        {'label': 'Settings: [COLOR yellow]A4k Subtitles[/COLOR]',
         'exec': 'executebuiltin("Addon.OpenSettings(service.subtitles.a4ksubtitles)")'},
    ]
    
    options.extend([
        {'label': 'User [COLOR yellow]%s[/COLOR]' % u['user_name'],
         'exec': 'armani_users.modify_user(%d)' % u['id']} for u in armani_users.get_users()
    ])
    options.extend([
        {'label': 'Reset Database', 'exec': 'armani.download_updates(True)'},
        {'label': 'Reset Users', 'exec': 'armani_users.reset_users()'},
        {'label': 'Clear Caches', 'exec': '_clear_caches()'},
    ])
    
    index = -1
    while 1:
        executebuiltin('SetProperty(select_type,menu,home)')
        index = dlg.select('Armani Admin', [o['label'] for o in options], preselect=index)
        executebuiltin('ClearProperty(select_type,home)')
        if index < 0:
            return
        exec(options[index]['exec'])
    

class ArmaniSettings:
    def __init__(self):
        self.conn = sqlite3.connect(SETTINGS_DB)
        self.cursor = self.conn.cursor()
        
    def get(self, setting_id: str):
        self.cursor.execute('SELECT value FROM settings WHERE id = ?', (setting_id,))
        result = self.cursor.fetchone()
        if not result:
            return None
        return result[0]
    
    def get_json(self, setting_id: str):
        return json.loads(self.get(setting_id) or "{}")
    
    def is_source(self, imdb_id, hash_string):
        self.cursor.execute('SELECT COUNT(*) FROM sources WHERE imdb_id = ? AND hash = ?', (imdb_id, hash_string))
        result = self.cursor.fetchone()
        return result[0] > 0
    
    def set_source(self, imdb_id, hash_string):
        self.cursor.execute('INSERT OR REPLACE INTO sources (imdb_id, hash) VALUES(?, ?)', (imdb_id, hash_string))
        self.conn.commit()
        
    def is_resetting(self, value: str):
        return value in self.__get_reset_list()
        
    def add_reset(self, value: str):
        reset_list = self.__get_reset_list()
        if value in reset_list:
            return
        reset_list.append(value)
        self.save('reset', ','.join(reset_list))
        
    def remove_reset(self, value):
        reset_list = self.__get_reset_list()
        if value not in reset_list:
            return
        reset_list.remove(value)
        self.save('reset', ','.join(reset_list))
        
    def __get_reset_list(self):
        self.cursor.execute('SELECT reset FROM settings')
        result = self.cursor.fetchone()
        return [] if not result else result[0].split(',')
        
    def get_user(self):
        return self.get('user_id'), self.get('user_name')
    
    def set_user(self, user_id: str, user_name: str):
        self.save('user_id', user_id)
        self.save('user_name', user_name)
        
    def save(self, setting_id: str, setting_value: str):
        self.cursor.execute('INSERT OR REPLACE INTO settings(id, value) VALUES(?, ?)', (setting_id, setting_value))
        self.conn.commit()
        
    def save_json(self, setting_id: str, setting_json: dict):
        self.save(setting_id, json.dumps(setting_json))