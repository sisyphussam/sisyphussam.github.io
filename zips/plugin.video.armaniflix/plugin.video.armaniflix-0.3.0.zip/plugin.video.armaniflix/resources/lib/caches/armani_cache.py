import json

import requests
from datetime import date, datetime as dt
from xbmcgui import Dialog, DialogProgressBG, DialogProgress
from xbmcvfs import translatePath
import sqlite3
import re
import unicodedata
from modules.kodi_utils import kodi_refresh, notification, local_string as ls, logger
from caches.armani_settings import ArmaniSettings

from modules.armani_utils import truncate_complete_sentences
from modules.settings import tmdb_api_key

ARMANI_STR = ls(32036).upper()
ADDON_DATA = 'special://profile/addon_data/plugin.video.armaniflix/%s'
MEDIA_DB = translatePath(ADDON_DATA % 'armani_media.db')
GIT = {
    'config': 'https://sisyphussam.github.io/defaults/armani.json',
    'database': 'https://sisyphussam.github.io/defaults/armani_media.db'
}

MEDIA_TYPES = {
    'movies': ls(32028),
    'tvshows': ls(32029)
}

CATEGORIES = {
    'alpha': ls(33621),
    'genres': ls(33622),
    'decades': ls(33623)
}

SORTS = {
    'rating': ls(33515),
    'votes': ls(33516),
    'year': ls(33517),
    'random': ls(33218)
}

NUM_EXAMPLES = 6
FETCH_LIMIT = 250
PLAYLIST_LIMIT = 250

IMDB_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "DNT": "1",
                "Connection": "close",
                "Upgrade-Insecure-Requests": "1"}
GIT_HEADERS = {"Cache-Control": "no-cache", "Pragma": "no-cache"}


PLAYLIST_MAIN_MENU = {
    'reset': {'exec': 'reset()', 'label': 33642, 'info': 33643},
    'media_types': {'exec': 'select_media_type()', 'label': 33628, 'info': 33629},
    'watched_content': {'exec': 'select_watched_status()', 'label': 33630, 'info': 33631},
    'decades': {'exec': 'select_decades()', 'label': 33632, 'info': 33633},
    'languages': {'exec': 'select_languages()', 'label': 33634, 'info': 33635},
    'genres_any': {'exec': 'select_genres("genres_any")', 'label': 33636, 'info': 33637},
    'genres_all': {'exec': 'select_genres("genres_all")', 'label': 33638, 'info': 33639},
    'genres_none': {'exec': 'select_genres("genres_none")', 'label': 33640, 'info': 33641},
    'search_any': {'exec': 'search_terms("search_any")', 'label': 33649, 'info': 33651},
    'search_all': {'exec': 'search_terms("search_all")', 'label': 33650, 'info': 33652},
    'search_none': {'exec': 'search_terms("search_none")', 'label': 33648, 'info': 33653},
    'size_filter': {'exec': 'set_size_filter()', 'label': 33644, 'info': 33645}
}

SIZE_FILTERS = {
    'votes_desc': {'label': 'Highest Vote Count (IMDb)', 'order': 'votes DESC, rating DESC'},
    'votes_asc': {'label': 'Lowest Vote Count (IMDb)', 'order': 'votes ASC, rating DESC'},
    'rating_desc': {'label': 'Highest Rating (IMDb)', 'order': 'rating DESC, votes DESC'},
    'rating_asc': {'label': 'Lowest Rating (IMDb)', 'order': 'rating ASC, votes DESC'},
    'year_asc': {'label': 'Oldest Releases', 'order': 'release_date ASC, votes DESC'},
    'year_desc': {'label': 'Latest Releases', 'order': 'release_date DESC, votes DESC'}
}


ANIMATION_SUBGENRES = ['com', 'dra', 'act', 'fan', 'sci', 'hor']

UPDATE_DAYS = 7


def _search_string(s):
    s = unicodedata.normalize('NFD', s)
    s = s.encode('ascii', 'ignore')
    s = s.decode("utf-8")
    s = re.sub(r'[^A-Za-z\d]+', '', s)
    return s


def _db_types_to_where(db_types: str):
    db_types = [t.strip().lower() for t in db_types.split(',')]
    where = ' OR '.join(['db_type = ?'] * len(db_types))
    return where, db_types

    
def run_playlist_command(key):
    exec('self.%s' % PLAYLIST_MAIN_MENU[key]['exec'])


def _get_tmdb(url_tail, session=None):
    api_str = '&api_key=%s' if '?' in url_tail else '?api_key=%s'
    url = 'https://api.themoviedb.org/3/' + url_tail + api_str % tmdb_api_key()
    
    if not session:
        tmdb_response = requests.get(url)
    else:
        tmdb_response = session.get(url)
    if tmdb_response.status_code != 200:
        return {}
    return tmdb_response.json()


class ArmaniCache:
    """ A database containing all movies and TV shows listed in IMDb CSV files. """
    
    def __init__(self):
        self.settings = ArmaniSettings()
        self.language = 'en-US'
        self.conn = sqlite3.connect(MEDIA_DB)
        self.cursor = self.conn.cursor()
        
        self.menu = self.settings.get_json('main_menu')
        self.imdb_lists = self.settings.get_json('imdb_lists')
        self.last_update = self.settings.get('last_update')
        self.genres = self.settings.get_json('genres')
        self.languages = self.settings.get_json('languages')
        self.countries = self.settings.get_json('countries')
        self.in_use = self.settings.get_json('in_use')
        
    def check(self):
        """ If necessary, download config and/or media database from GitHub """
        if any(not self.settings.get(k) for k in ('genres', 'languages', 'countries')):
            self.download_config()
        
        # Download default database from GitHub if the current one is empty
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        if not self.cursor.fetchall():
            self.clear_database(False)
            self.download_default_database(False)

    def download_config(self) -> bool:
        """ Download the latest config from GitHub

        Returns: True if successful, False otherwise
        """
        response = requests.get(GIT['config'], headers=GIT_HEADERS)
        if response.status_code != 200:
            logger(ARMANI_STR, 'Failed to download config from GitHub')
            notification('Failed to download config')
            return False
        data = response.json()
    
        self.imdb_lists = data['imdb_lists']
        self.settings.save_json('imdb_lists', self.imdb_lists)
        self.genres = data['genres']
        self.countries = data['countries']
        self.languages = data['languages']
        self.settings.save_json('genres', self.genres)
        self.settings.save_json('countries', self.countries)
        self.settings.save_json('languages', self.languages)
        notification('Downloaded config')
        return True

    def clear_database(self, confirm=True):
        if confirm and not Dialog().yesno('Confirm Deletion', 'Delete all entries in the media database?'):
            return False
    
        self.cursor.executescript("""
            DROP TABLE IF EXISTS media;

            CREATE TABLE media (
                imdb_id TEXT NOT NULL UNIQUE,
                tmdb_id INTEGER NOT NULL,
                db_type TEXT NOT NULL,
                title TEXT,
                sort_title TEXT,
                starting_letter TEXT,
                plot TEXT,
                main_credits TEXT,
                genre_ids TEXT,
                mpaa TEXT,
                original_language TEXT,
                release_date TEXT,
                year INTEGER,
                decade INTEGER,
                runtime INTEGER,
                rating REAL,
                votes INTEGER,
                search_string TEXT,
                extra_info TEXT,
                status TEXT,
                date_added TEXT,
                date_updated TEXT,
                UNIQUE(tmdb_id, db_type)
            );
        """)
    
        self.conn.commit()
        self.__post_update()
        notification('Database is empty')
        return True

    def download_default_database(self, confirm=True):
        from modules.armani_utils import dialog_yesnocancel
        replace = True
        if confirm:
            ret = dialog_yesnocancel('Default Database',
                                     'Select "update" if you want to keep any changes you have made. '
                                     'Select "replace" to synchronize the database with the default IMDb lists.',
                                     'Update', 'Replace')
            if ret < 0:
                return False
            replace = ret == 1
        
        try:
            [(v['name'], v['id'], v['filter']) for v in self.imdb_lists]
        except TypeError:
            self.download_config()
            
        success = []
        for imdb_list in self.imdb_lists:
            if replace:
                success.append(self.import_list(imdb_list['id'], imdb_list['name'], imdb_list['filter']))
            else:
                success.append(self.import_list(imdb_list['id'], imdb_list['name']))
        return any(s for s in success)
        
    def import_list(self, list_id, list_name="", synchronize_filter="") -> bool:
        from modules.armani_utils import current_date, download_imdb_list
        if not list_name:
            list_name = list_id
    
        prog_header = 'Importing "%s"' if not synchronize_filter else 'Synchronizing "%s"'
        prog = DialogProgress()
        prog.create(prog_header % list_name)
    
        imdb_rows = download_imdb_list(list_id)
        if not imdb_rows:
            return False
    
        insert_count = 0
        update_count = 0
        fail_count = 0
    
        with requests.Session() as session:
            # Add (or update) each row to the media database
            i = 0
            for row in imdb_rows:
                if prog.iscanceled():
                    break
            
                self.cursor.execute('SELECT extra_info, db_type, tmdb_id, title, sort_title, genre_ids, status '
                                    'FROM media where imdb_id = ?', (row['imdb_id'],))
                existing = self.cursor.fetchone()
                progress = int(100 * i / len(imdb_rows))
            
                # If the entry exists, update title, sort title, genres, status, and season / episode counts
                if existing:
                    existing_genre_ids = self.__get_fixed_genres([g.strip() for g in existing[5].split(',')])
                    title = row['title'] or existing[3]
                    sort_title = row['sort_title'] or existing[4]
                    genre_ids = row['genre_ids'] or existing_genre_ids
                    if existing[6] == 'Returning Series':
                        prog.update(progress, 'Updating returning series: %s [%s]' % (title, row['imdb_id']))
                        if self.__insert_or_update(row['imdb_id'], session, title, sort_title, genre_ids):
                            update_count += 1
                        else:
                            fail_count += 1
                    else:
                        prog.update(progress, 'Updating: %s [%s]' % (title, row['imdb_id']))
                        alpha = sort_title[0] if sort_title[0].isalpha() else '#'
                        extra_info = json.loads(existing[0])
                        extra_info['genres'] = [self.genres[g] for g in genre_ids]
                        self.cursor.execute("""
                             UPDATE media
                             SET title = ?, sort_title = ?, starting_letter = ?, genre_ids = ?, rating = ?, votes = ?,
                                 extra_info = ?, date_updated = ?
                             WHERE imdb_id = ?
                         """, (title, sort_title, alpha, ', '.join(genre_ids), row['imdb_rating'], row['imdb_votes'],
                               json.dumps(extra_info), current_date(), row['imdb_id']))
                        update_count += 1
                else:
                    prog.update(progress, 'Adding new entry: ' + row['imdb_id'])
                    # Add a new entry
                    added = self.__insert_or_update(row['imdb_id'], session, row['title'], row['sort_title'],
                                                    row['genre_ids'])
                    if added:
                        insert_count += 1
                    else:
                        fail_count += 1
                i += 1
    
        self.conn.commit()
        self.conn.execute('VACUUM')
    
        # If synchronizing, remove matching entries not in the IMDb list
        if synchronize_filter:
            row_ids = [r['imdb_id'] for r in imdb_rows]
            self.cursor.execute('SELECT imdb_id FROM media WHERE %s' % synchronize_filter)
            delete_ids = [r[0] for r in self.cursor.fetchall() if r[0] not in row_ids]
            logger('Synchronizing list', 'removing %d entries' % len(delete_ids))
            self.cursor.execute('DELETE FROM media WHERE imdb_id IN(%s)' % ', '.join(['?'] * len(delete_ids)),
                                delete_ids)
            self.conn.commit()
    
        prog.close()
        self.__post_update()
        report = 'Out of the %d rows in list %s, %d new entries were added, %d existing entries were updated, ' \
                 'and %d failed.' % (len(imdb_rows), list_name, insert_count, update_count, fail_count)
        notification('Imported "%s"' % list_name)
        logger('List import', report)
        return True

    def add(self):
        from modules.armani_utils import dialog_menu
    
        index = dialog_menu('Add Movies / Shows', [
            'Movie',
            'Movie Set',
            'TV Show',
            'IMDb ID',
            'Advanced'
        ])
    
        if index < 0:
            return
        if index == 0:
            added = self.add_entry('movie')
        elif index == 1:
            added = self.add_entry('collection')
        elif index == 2:
            added = self.add_entry('tv')
        elif index == 3:
            imdb_id = Dialog().input('Enter IMDb ID (movie, TV show, or list)').strip().lower()
            if not imdb_id:
                return
            if not imdb_id.startswith(('ls', 'tt')):
                notification('Invalid IMDb ID')
                return
            if imdb_id.startswith('ls'):
                added = self.import_list(imdb_id)
            else:
                self.cursor.execute('SELECT title, year FROM media WHERE imdb_id = ?', (imdb_id,))
                result = self.cursor.fetchone()
                if result:
                    notification('Already exists!')
                    return
                added = self.__insert_or_update(imdb_id)
        else:
            added = self.add_advanced()
    
        if added:
            self.__post_update()
            kodi_refresh()

    def add_entry(self, search_type):
        from modules.armani_utils import dialog_menu, get_sort_title
        if search_type == 'collection':
            media_label = 'movie collection'
        elif search_type == 'movie':
            media_label = 'movie'
        else:
            media_label = 'TV show'
    
        dlg = Dialog()
        query = dlg.input('Find a ' + media_label).strip()
        if not query:
            return False
    
        with requests.Session() as session:
            t = _get_tmdb('search/%s?query=%s' % (search_type, query), session)
            if not t.get('results', []):
                notification('No matches')
                return False
            results = t['results']
        
            sort_title = None
            if search_type == 'collection':
                i = 0
                if len(results) > 1:
                    i = dialog_menu('Select Collection', [r['name'] for r in results])
                    if i < 0:
                        return False
                collection_id = results[i]['id']
                sort_title = get_sort_title(t['results'][i]['name'].replace(' Collection', '').upper())
                t = _get_tmdb('collection/%d?language=en-US"' % collection_id, session)
                if 'parts' not in t:
                    notification('Invalid collection')
                    return False
                results = [p for p in t['parts'] if p.get('release_date')]
                results.sort(key=lambda k: k['release_date'])
            elif search_type == 'person':
                i = 0
                if len(results) > 1:
                    new_results = []
                    for r in results:
                        if not r.get('known_for'):
                            continue
                        known_for = r['known_for'][0]
                        title = known_for.get('title') if known_for['media_type'] == 'movie' else known_for.get('name')
                        new_results.append({'id': r['id'], 'label': '%s - %s' % (r['name'], title)})
                    results = new_results
                    i = dialog_menu('Select Person', [r['label'] for r in results])
                    if i < 0:
                        return False
                person_id = results[i]['id']
                t = _get_tmdb('person/%d/combined_credits?language=en-US"' % person_id)
                min_popularity = 4
                crew_credits = [c for c in t.get('crew', []) if c['job'] == 'Director' or c['department'] == 'Writing']
                crew_credits = [c for c in crew_credits if c['popularity'] > min_popularity]
                crew_credits = [c for c in crew_credits if c.get('episode_count', 100) > 3]
                cast_credits = [c for c in t.get('cast', []) if c['popularity'] > min_popularity]
                all_credits = [{'media_type': c['media_type'], 'id': c['id'],
                                'title': c.get('title') or c.get('name'),
                                'sort_title': get_sort_title(c.get('title') or c.get('name')) or "",
                                'release_date': c.get('release_date') or c.get('first_air_date')}
                               for c in crew_credits + cast_credits]
                results = [dict(t) for t in {tuple(d.items()) for d in all_credits}]
                results.sort(key=lambda k: k['sort_title'])
        
            items = []
        
            for m in results:
                media_type = search_type if search_type in ('movie', 'tv') else m.get('media_type')
                tmdb_id = m['id']
                db_type = 'movie' if media_type == 'movie' else 'tvshow'
                title = m.get('title') or m.get('name')
                release_date = m.get('release_date') or m.get('first_air_date')
            
                if not title or not release_date:
                    continue
            
                self.cursor.execute('SELECT imdb_id FROM media WHERE db_type = ? AND tmdb_id = ?', (db_type, tmdb_id))
                if self.cursor.fetchone():
                    continue
            
                items.append({'media_type': media_type, 'tmdb_id': tmdb_id,
                              'label': '%s (%s)' % (title, release_date.split('-')[0])})
        
            if not items:
                notification('No new matches')
                return False
        
            sel = dlg.multiselect('What are you adding?', [i['label'] for i in items])
            if not sel:
                return False
        
            prog = DialogProgress()
            prog.create('Adding Entries')
            i = 0
            added = []
            failures = []
            for index in sel:
                if prog.iscanceled():
                    break
                prog.update(int(100 * (i / len(sel))), items[index]['label'])
                i += 1
                t = _get_tmdb('%s/%d/external_ids' % (items[index]['media_type'], items[index]['tmdb_id']))
                if not t.get('imdb_id'):
                    logger('Failed to add', str(items[index]))
                    notification('Something went wrong')
                    failures.append('[COLOR red]%s[/COLOR]' % items[index]['label'])
                    continue
                if self.__insert_or_update(t['imdb_id'], sort_title=sort_title):
                    added.append(items[index]['label'])
    
        prog.close()
        dlg.ok('Added %d Entries' % len(added), 'Nothing added' if not added else ', '.join(added))
        return True

    def add_advanced(self):
        from xbmcgui import ListItem
        from modules.armani_utils import dialog_menu, dialog_numeric, get_sort_title, dialog_yesnocancel
        from time import sleep
    
        def _add_entries():
            media_type = main_menu[0]['value']
            db_type = 'movie' if media_type == 'movie' else 'tvshow'
            filters = []
            if main_menu[1]['value']:
                filters.append(main_menu[1]['value'])
            if main_menu[2]['value']:
                filters.append(main_menu[2]['value'])
            if main_menu[3]['value']:
                filters.append(main_menu[3]['value'][media_type])
            if main_menu[4]['value']:
                filters.append('with_cast=%s' % main_menu[4]['value'])
            if main_menu[5]['value']:
                filters.append('with_crew=%s' % main_menu[5]['value'])
            if not filters:
                notification('No Filters Set')
                return False
        
            url = 'discover/%s?include_adult=false&include_video=false&language=en-US&sort_by=vote_count.desc' % media_type
            url += '&' + '&'.join(filters) + '&page=%d'
        
            results = []
            prog = DialogProgress()
            prog.create('Fetching Results')
            page = 1
            total_pages = 2
            while page <= total_pages:
                if prog.iscanceled():
                    break
                t = _get_tmdb(url % page, session)
                if not t:
                    notification('Could not retrieve')
                    break
                if page == 1:
                    total_pages = t['total_pages']
                    if total_pages == 0:
                        logger('No Results', url % page)
                        notification('No Results')
                        return False
                    if total_pages > 20 and not dlg.yesno('Too Many Results',
                                                          'Your query yielded too many results (%d). Load the most '
                                                          'popular results?' % t['total_results']):
                        return False
                    total_pages = min(total_pages, 20)
            
                for r in t['results']:
                    self.cursor.execute('SELECT * FROM media WHERE db_type = ? AND tmdb_id = ?', (db_type, r['id']))
                    if self.cursor.fetchone():
                        continue
                    results.append({
                        'media_type': media_type,
                        'id': r['id'],
                        'title': r.get('title') or r.get('name'),
                        'year': (r.get('release_date') or r.get('first_air_date') or '9999-01-01').split('-')[0],
                        'sort_title': get_sort_title(r.get('title') or r.get('name'))
                    })
                prog.update(int(100 * page / total_pages),
                            'Page %d of %d[CR]Total Results: %d' % (page, total_pages, len(results)))
                page += 1
                sleep(3)
        
            prog.close()
        
            if not results:
                notification('No results')
                return False
        
            results.sort(key=lambda k: k['sort_title'])
        
            sel = dlg.multiselect('Select Titles to Add', ['%s (%s)' % (r['title'], r['year']) for r in results])
            if not sel:
                return False
        
            prog = DialogProgress()
            prog.create('Adding New Entries')
            i = 0
            for index in sel:
                prog.update(int(100 * (i / len(sel))),
                            '%d of %d[CR]%s (%s)' % (i + 1, len(sel), results[index]['title'],
                                                     results[index]['year']))
                i += 1
                t = _get_tmdb('%s/%d/external_ids' % (results[index]['media_type'], results[index]['id']))
                if not t.get('imdb_id'):
                    logger('Failed to add', str(results[index]))
                    notification('Something went wrong')
                    continue
                added = self.__insert_or_update(t['imdb_id'])
                if prog.iscanceled():
                    break
        
            prog.close()
            return True
    
        dlg = Dialog()
        main_menu = [
            {'label': 'Media Type', 'value': 'movie', 'str_val': 'Movies'},
            {'label': 'Vote Average', 'value': '', 'str_val': '0.0 - 10.0'},
            {'label': 'Vote Count', 'value': '', 'str_val': '0 - INF'},
            {'label': 'Years', 'value': '', 'str_val': '1800 - 2100'},
            {'label': 'Cast', 'value': '', 'str_val': ''},
            {'label': 'Crew', 'value': '', 'str_val': ''},
        ]
    
        added = False
        with requests.Session() as session:
            while 1:
                list_items = [ListItem(m['label'], m['str_val'] or 'N/A') for m in main_menu]
                list_items.append(ListItem('[COLOR yellow]VIEW RESULTS[/COLOR]',
                                           'Apply all filters before proceeding'))
                menu_index = dlg.select('Add Movies / TV Shows', list_items, useDetails=True)
                if menu_index < 0:
                    break
                if menu_index == 0:
                    ret = dlg.yesno('Media Type', 'Are you searching for movies or TV shows?', 'Movies', 'TV Shows')
                    if ret:
                        main_menu[menu_index]['value'] = 'tv'
                        main_menu[menu_index]['str_val'] = 'TV Shows'
                    else:
                        main_menu[menu_index]['value'] = 'movie'
                        main_menu[menu_index]['str_val'] = 'Movies'
                elif menu_index == 1:
                    ratings = [10.0, 9.5, 9.0, 8.5, 8.0, 7.5, 7.0, 6.5, 6.0, 5.5, 5.0,
                               4.5, 4.0, 3.5, 3.0, 2.5, 2.0, 1.5, 1.0, 0.5, 0.0]
                    index = dialog_menu('Minimum Rating', ['%.1f' % r for r in ratings])
                    min_rating = 0.0 if index < 0 else ratings[index]
                    max_rating = 10.0
                    ratings = [r for r in ratings if r > min_rating]
                    if len(ratings) > 1:
                        index = dialog_menu('Maximum Rating', [str(r) for r in ratings])
                        max_rating = 10.0 if index < 0 else ratings[index]
                    vals = []
                    if min_rating > 0.0:
                        vals.append('vote_average.gte=%.1f' % min_rating)
                    if max_rating < 10.0:
                        vals.append('vote_average.lte=%.1f' % max_rating)
                    main_menu[menu_index]['value'] = '&'.join(vals)
                    main_menu[menu_index]['str_val'] = '%.1f - %.1f' % (min_rating, max_rating)
                elif menu_index == 2:
                    min_votes = int(dialog_numeric('Minimum Vote Count', 'Enter min. votes') or '0')
                    max_votes = int(dialog_numeric('Maximum Vote Count', 'Enter max. votes') or '0')
                    if max_votes < min_votes:
                        max_votes = 0
                    vals = []
                    if min_votes > 0:
                        vals.append('vote_count.gte=%d' % min_votes)
                    if max_votes > 0:
                        vals.append('vote_count.lte=%d' % max_votes)
                    main_menu[menu_index]['value'] = '&'.join(vals)
                    main_menu[menu_index]['str_val'] = '%d - %s' % (
                    min_votes, str(max_votes) if max_votes > 0 else "INF")
                elif menu_index == 3:
                    min_year = int(dialog_numeric('Minimum Year', 'Enter starting year') or '0')
                    max_year = int(dialog_numeric('Maximum Year', 'Enter ending year') or '0')
                    if min_year < 1800:
                        min_year = 1800
                    if max_year <= 1800 or max_year > 2100:
                        max_year = 2100
                    vals = {'movie': [], 'tv': []}
                    if min_year > 1800:
                        vals['movie'].append('primary_release_date.gte=%d-01-01' % min_year)
                        vals['tv'].append('first_air_date.gte=%d-01-01' % min_year)
                    if max_year < 2100:
                        vals['movie'].append('primary_release_date.lte=%d-01-01' % max_year)
                        vals['tv'].append('first_air_date.lte=%d-01-01' % max_year)
                    main_menu[menu_index]['value'] = {'movie': '&'.join(vals['movie']), 'tv': '&'.join(vals['tv'])}
                    main_menu[menu_index]['str_val'] = '%d - %d' % (min_year, max_year)
                elif menu_index in (4, 5):
                    m = main_menu[menu_index]
                    if m['value'] and dlg.yesno('Clear %s' % m['label'],
                                                'Would you like to remove the current values?'):
                        m['value'] = ''
                        m['str_val'] = ''
                    person_ids = [] if not m['value'] else m['value'].split('|')
                    person_names = [] if not m['value'] else m['str_val'].split(', ')
                
                    query = dlg.input('Find an actor, director, or writer').strip()
                    if not query:
                        continue
                    t = _get_tmdb('search/person?query=%s' % query, session)
                    results = [r for r in t.get('results', []) if r['id'] not in person_ids]
                    if not results:
                        notification('No matches')
                        continue
                    i = 0
                    if len(results) > 1:
                        new_results = []
                        for r in results:
                            if not r.get('known_for'):
                                continue
                            known_for = r['known_for'][0]
                            title = known_for.get('title') if known_for['media_type'] == 'movie' else known_for.get(
                                'name')
                            new_results.append({'id': r['id'], 'name': r['name'],
                                                'label': '%s - %s' % (r['name'], title)})
                        results = new_results
                        i = dialog_menu('Select Person', [r['label'] for r in results])
                        if i < 0:
                            continue
                    person_ids.append(str(results[i]['id']))
                    person_names.append(results[i]['name'])
                    m['value'] = '|'.join(person_ids)
                    m['str_val'] = ', '.join(person_names)
                else:
                    added = _add_entries() or added
        return added

    def __insert_or_update(self, imdb_id: str, session=None, title: str = None, sort_title: str = None, genre_ids=None):
        from modules.kodi_utils import notification
        from modules.armani_utils import get_sort_title, current_date
        from time import sleep
    
        def _error(msg):
            prog.close()
            notification('Error: %s' % imdb_id)
            logger('ArmaniFlix / add_entry[%s]' % imdb_id, str(msg))
        
        if not session:
            session = requests.Session()
            
        prog = DialogProgressBG()
        prog.create(imdb_id)
        
        self.cursor.execute('SELECT date_added FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        date_added = result[0] if result else current_date()

        prog.update(25)
    
        # Get IMDb data
        response = session.get('https://www.imdb.com/title/%s' % imdb_id, headers=IMDB_HEADERS)
        if response.status_code != 200:
            _error('Unable to retrieve IMDb details')
            return False
        
        try:
            json_text = response.text.split('{"props":{"pageProps"')[1].split('"aboveTheFoldData":')[1]
            json_text = json_text.split(',"mainColumnData":{')[0]
        except IndexError:
            _error('Unable to parse IMDb page')
            return False
            
        imdb_data = json.loads(json_text)
    
        try:
            # Details from IMDb data
            if not title:
                title = imdb_data['titleText']['text']
            if not sort_title:
                sort_title = get_sort_title(title)
            alpha = sort_title[0] if sort_title[0].isalpha() else '#'
            if not genre_ids:
                imdb_genres = {
                    'Action': 'act', 'Adult': 'adu', 'Adventure': 'adv', 'Animation': 'ani', 'Biography': 'bio',
                    'Comedy': 'com', 'Crime': 'cri', 'Documentary': 'doc', 'Drama': 'dra', 'Family': 'fam',
                    'Fantasy': 'fan', 'Film-Noir': 'fil', 'Game Show': 'gam', 'History': 'his', 'Horror': 'hor',
                    'Music': 'muc', 'Musical': 'mus', 'Mystery': 'mys', 'News': 'new', 'Reality-TV': 'rea',
                    'Romance': 'rom', 'Sci-Fi': 'sci', 'Short': 'sho', 'Sport': 'spo', 'Talk-Show': 'tal',
                    'Thriller': 'thr', 'War': 'war', 'Western': 'wes'
                }
                genre_ids = [imdb_genres[g['text']] for g in imdb_data['genres']['genres']]
                genre_ids = self.__get_fixed_genres(genre_ids)
        
            db_type = 'movie' if imdb_data['titleType']['id'] in ('movie', 'tvMovie', 'short') else 'tvshow'
            media_type = 'movie' if db_type == 'movie' else 'tv'
            imdb_rating = imdb_data['ratingsSummary']['aggregateRating']
            imdb_votes = imdb_data['ratingsSummary']['voteCount']
            plot = truncate_complete_sentences(imdb_data['plot']['plotText']['plainText'])
        except Exception as e:
            _error(str(e))
            return False

        prog.update(50)
        # Get tmdb data
        tmdb_details, tmdb_release_dates, tmdb_credits, tmdb_ratings = None, None, None, None
        try:
            
            tmdb_find = _get_tmdb('find/%s?external_source=imdb_id' % imdb_id)
            found = tmdb_find.get('movie_results') if db_type == 'movie' else tmdb_find.get('tv_results')
            if not found:
                _error('TMDB ID not found')
                return False
            tmdb_id = found[0]['id']

            tmdb_details = _get_tmdb('%s/%d?language=en-US' % (media_type, tmdb_id))
            if db_type == 'movie':
                tmdb_credits = _get_tmdb('movie/%d/credits' % tmdb_id)
                tmdb_release_dates = _get_tmdb('movie/%s/release_dates' % tmdb_id)['results']
            else:
                tmdb_credits = _get_tmdb('tv/%d/aggregate_credits' % tmdb_id)
                tmdb_ratings = _get_tmdb('tv/%s/content_ratings' % tmdb_id)['results']

            # Details from TMDb data
            original_language = self.languages[tmdb_details['original_language']]
            status = tmdb_details['status']
            extra_info = {
                'genres': [self.genres[g] for g in genre_ids],
                'countries': ''
            }

            # Movie details from TMDb data
            director_jobs = ('director', 'directed by')
            writer_jobs = ('author', 'book', 'comic book', 'graphic novel', 'novel', 'original story', 'screenplay',
                           'screenplay by', 'short story', 'story', 'story by', 'writer', 'written by')

            prog.update(75)
            
            if db_type == 'movie':
                # Movie credits
                cast = tmdb_credits['cast']
                crew = sorted(tmdb_credits['crew'], key=lambda d: d['popularity'], reverse=True)
                directors = [p for p in crew if p['job'].lower() in director_jobs]
                creators = []
                writers = [p for p in crew if p['job'].lower() in writer_jobs]

                release_dates = []
                for d in tmdb_release_dates:
                    release_dates.extend([rd['release_date'][:10] for rd in d['release_dates']])
                release_date = min(release_dates)
                runtime = tmdb_details['runtime']

                release_dates = {r['iso_3166_1']: r['release_dates'] for r in tmdb_release_dates}
                if 'US' not in release_dates:
                    mpaa = 'NR'
                else:
                    mpaa_list = [r['certification'] for r in release_dates['US'] if r['certification']]
                    mpaa = 'NR' if not mpaa_list else mpaa_list[0]

                extra_info['countries'] = [c['name'] for c in tmdb_details['production_countries']]

            # TV details from TMDb data
            else:
                # TV credits
                cast = sorted(tmdb_credits['cast'], key=lambda d: d['total_episode_count'], reverse=True)
                cast = [c for c in cast if c['order'] < 8]
                for c in cast:
                    c['character'] = sorted(c['roles'], key=lambda d: d['episode_count'], reverse=True)[0][
                        'character']
                creators = [{'id': c['id'], 'name': c['name']} for c in tmdb_details.get('created_by', [])]
                directors = []
                writers = []
                for c in tmdb_credits['crew']:
                    for j in c['jobs']:
                        if j['job'].lower() in director_jobs:
                            directors.append(
                                {'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
                        elif j['job'].lower() in writer_jobs:
                            writers.append({'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
                directors = [{'id': p['id'], 'name': p['name']}
                             for p in sorted(directors, key=lambda d: d['episode_count'], reverse=True)][0:2]
                writers = [{'id': p['id'], 'name': p['name']}
                           for p in sorted(writers, key=lambda d: d['episode_count'], reverse=True)][0:2]

                release_date = tmdb_details['first_air_date']
                if tmdb_details['episode_run_time']:
                    runtime = tmdb_details['episode_run_time'][0]
                else:
                    episode_details = _get_tmdb('tv/%s/season/1/episode/1?language=en-US' % tmdb_id)
                    runtime = episode_details['runtime'] or 0

                certs = {r['iso_3166_1']: r['rating'] for r in tmdb_ratings if r['rating']}
                mpaa = 'NR' if 'US' not in certs else certs['US']
                extra_info['countries'] = [self.countries[c] for c in tmdb_details['origin_country']]
                extra_info['num_seasons'] = tmdb_details['number_of_seasons']
                extra_info['num_episodes'] = tmdb_details['number_of_episodes']
                extra_info['episodes'] = {}
                for season in range(1, tmdb_details['number_of_seasons'] + 1):
                    season_data = _get_tmdb('tv/%d/season/%d?language=en-US"' % (tmdb_id, season))
                    extra_info['episodes'][str(season)] = {
                        str(e['episode_number']): {
                            'release_date': e['air_date'],
                            'title': e['name'],
                            'plot': truncate_complete_sentences(e['overview']),
                            'runtime': e['runtime']
                        } for e in season_data['episodes']
                    }

            # Finalize credits
            cast = [{'id': p['id'], 'name': p['name'], 'role': p['character'], 'order': p['order']} for p in cast]
            director = [{'id': p['id'], 'name': p['name']} for p in directors]
            writer = [{'id': p['id'], 'name': p['name']} for p in writers]
            cast = list({p['id']: p for p in cast}.values())
            cast = sorted(cast, key=lambda d: d['order'])
            director = list({p['id']: p for p in director}.values())
            writer = list({p['id']: p for p in writer}.values())
            all_credits = {
                'director': director[0:2],
                'creator': creators[0:2],
                'writer': writer[0:2],
                'cast': cast[0:8]
            }

            creator = [p['name'] for p in all_credits.get('creator', [])]
            director = [p['name'] for p in all_credits.get('director', [])]
            writer = [p['name'] for p in all_credits.get('writer', [])]
            cast = [p['name'] for p in all_credits.get('cast', [])]

            credit_lines = []
            credit_string = '[B]%s:[/B] %s'
            if creator:
                credit_lines.append(credit_string % ('Creator', ', '.join(creator)))
            elif director:
                credit_lines.append(credit_string % ('Director', ', '.join(director)))
            if cast:
                credit_lines.append(credit_string % ('Stars', ', '.join(cast[0:3])))
            main_credits = '[CR]'.join(credit_lines)

            search_words = [title, sort_title] + creator + director + writer + cast
            search_words = '|'.join(list(dict.fromkeys([_search_string(w) for w in search_words])))

            release_year = int(release_date[:4])
            release_decade = 10 * int(release_year / 10)

            self.cursor.execute("""
                   INSERT OR REPLACE INTO media (
                       imdb_id, db_type, tmdb_id, title, sort_title, starting_letter, plot, main_credits, genre_ids,
                       mpaa, original_language, release_date, year, decade, runtime, rating, votes,
                       search_string, extra_info, status, date_added, date_updated
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               """, (imdb_id, db_type, tmdb_id, title, sort_title, alpha, plot, main_credits, ','.join(genre_ids),
                     mpaa, original_language, release_date, release_year, release_decade, runtime, imdb_rating,
                     imdb_votes, search_words, json.dumps(extra_info), status, date_added, current_date())
            )
            self.conn.commit()
            prog.update(100)
            sleep(1)
            prog.close()
    
        except Exception as e:
            _error(str(e))
            return False
    
        return True

    def __post_update(self):
        def _menu_create(menu_id, menu_name):
            results = [{'imdb_id': r[0], 'title': r[1], 'sort_title': r[2], 'release_date': r[3]}
                       for r in self.cursor.fetchall()]
            if not results:
                return None
        
            samples = results[0:10]
            samples.sort(key=lambda x: x['release_date'])
            samples.sort(key=lambda x: x['sort_title'])
            return {
                'id': menu_id,
                'name': menu_name,
                'where': 'WHERE db_type = "%s" AND (%s)' % (db_type, filter_string),
                'count': len(results),
                'summary': '[CR]'.join([s['title'] for s in samples])
            }
    
        menu = {'movies': {'genres': {}, 'decades': {}, 'alpha': {}},
                'tvshows': {'genres': {}, 'decades': {}, 'alpha': {}}}
    
        self.cursor.execute('SELECT original_language, decade, genre_ids FROM media')
        results = self.cursor.fetchall()
        if not results:
            self.menu = menu
            self.settings.save_json('main_menu', self.menu)
            return
    
        languages = list(dict.fromkeys([r[0] for r in results]))
        languages.sort()
        decades = list(dict.fromkeys([r[1] for r in results]))
        decades.sort(reverse=True)
        genre_ids = list(dict.fromkeys([g.strip() for g in ','.join([r[2] for r in results]).split(',')]))
        genre_ids.sort()
        self.in_use = {
            'genres': genre_ids,
            'decades': decades,
            'languages': [k for k, v in self.languages.items() if v in languages]
        }
        self.playlist_values = {
            'genres': [{'label': self.genres[v], 'value': v} for v in genre_ids],
            'languages': [{'label': v, 'value': v} for v in languages],
            'decades': [{'label': '%d - %d' % (d, d + 9), 'value': d} for d in decades]
        }
        self.settings.save_json('in_use', self.in_use)
        self.settings.save_json('playlist_values', self.playlist_values)
    
        sql_select = 'SELECT imdb_id, title || " (" || year || ")", sort_title, release_date ' \
                     'FROM media WHERE db_type = ? AND %s ORDER BY RANDOM()'
    
        for db_type in ('movie', 'tvshow'):
            menu_type = 'movies' if db_type == 'movie' else 'tvshows'

            self.cursor.execute('SELECT title || " (" || year || ")" FROM media WHERE db_type = ? '
                                'ORDER BY sort_title, release_date', (db_type,))
            all_results = self.cursor.fetchall()
            if len(all_results) < 9:
                all_samples = '[CR]'.join(r[0] for r in all_results)
            else:
                s = '%s[CR]%s[CR]%s[CR].....[CR]%s[CR]%s[CR]%s'
                n = len(all_results) - 1
                all_samples = s % (all_results[0][0], all_results[1][0], all_results[2][0],
                                   all_results[n-2][0], all_results[n-1][0], all_results[n][0])
            media_name = 'movies' if db_type == 'movie' else 'TV shows'
            
            menu[menu_type]['alpha']['all'] = {
                'id': 'all',
                'name': 'ALL',
                'where': 'WHERE db_type = "%s"' % db_type,
                'count': len(all_results),
                'summary': 'View all %d %s in the database (use the menu to add more).'
                           '[CR][CR]%s' % (len(all_results), media_name, all_samples)
            }
            
            for g in self.genres:
                filter_string = 'genre_ids LIKE ' + '"%' + g + '%"'
                self.cursor.execute(sql_select % 'genre_ids LIKE ?', (db_type, '%' + g + '%'))
                menu_entry = _menu_create(g, self.genres[g])
                if menu_entry:
                    menu[menu_type]['genres'][g] = menu_entry
        
            for a in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
                filter_string = 'starting_letter = "%s"' % a
                self.cursor.execute(sql_select % 'starting_letter = ?', (db_type, a))
                menu_entry = _menu_create(a, a)
                if menu_entry:
                    menu[menu_type]['alpha'][a] = menu_entry
        
            for d in (1900, 1910, 1920, 1930, 1940, 1950, 1960, 1970, 1980, 1990, 2000, 2010, 2020, 2030):
                filter_string = 'decade = %d' % d
                self.cursor.execute(sql_select % 'decade = ?', (db_type, d))
                menu_entry = _menu_create(str(d), '%d - %d' % (d, d + 9))
                if menu_entry:
                    menu[menu_type]['decades'][str(d)] = menu_entry
        self.menu = menu
        self.settings.save_json('main_menu', self.menu)
        self.last_update = dt.now().strftime("%Y-%m-%d %H:%M:%S")
        self.settings.save('last_update', self.last_update)

    
    
    def delete_entry(self, imdb_id):
        self.cursor.execute('SELECT title || " (" || year || ")" FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return False
        dlg = Dialog()
        if not dlg.yesno(
                'Confirm Deletion',
                'Are you certain you want to remove [COLOR yellow]%s[/COLOR] from the media database?' % result[0]):
            return False
        
        self.cursor.execute('DELETE FROM media WHERE imdb_id = ?', (imdb_id,))
        self.conn.commit()
        self.conn.execute('VACUUM')
        self.__post_update()
        notification('Deleted %s' % imdb_id)
        return True

    def edit_entry(self, imdb_id):
        """ Modify metadata (optional) and updates rating and status of the specified entry. """
        from modules.armani_utils import current_date

        self.cursor.execute('SELECT title, sort_title, genre_ids, extra_info FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return
        
        title = result[0]
        sort_title = result[1]
        genre_ids = [g.strip() for g in result[2].split(',')]
        
        if Dialog().yesno(title, 'Edit the metadata or update the status, episode counts (if applicable), '
                                 'and IMDb rating.', 'Update', 'Edit Metadata'):
            new_values = self.__get_new_values(title, sort_title, genre_ids)
            if new_values:
                title, sort_title, alpha, genre_ids = new_values
                extra_info = json.loads(result[3])
                extra_info['genres'] = [self.genres[g] for g in genre_ids]
                self.cursor.execute(
                    'UPDATE media SET title = ?, sort_title = ?, starting_letter = ?, genre_ids = ?, '
                    'extra_info = ?, date_updated = ? WHERE imdb_id = ?',
                    (title, sort_title, alpha, ','.join(genre_ids), json.dumps(extra_info), current_date(), imdb_id))
                self.conn.commit()
                self.__post_update()
                notification('Success!')
        else:
            self.update_metadata(imdb_id)
            
    def update_metadata(self, imdb_id, silent=False):
        self.cursor.execute('SELECT title, sort_title, genre_ids FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return
        title, sort_title, genre_ids = result
        genre_ids = [g.strip() for g in genre_ids.split(',')]
        if not self.__insert_or_update(imdb_id, title=title, sort_title=sort_title, genre_ids=genre_ids):
            return
        self.__post_update()
        if not silent:
            notification('Updated metadata')
        
    def update_tvshows(self):
        from modules.armani_utils import current_date
        from time import sleep

        self.cursor.execute('SELECT imdb_id, title, year FROM media '
                            'WHERE db_type = ? AND status = ? AND date_updated < ? '
                            'ORDER BY sort_title, release_date',
                            ('tvshow', 'Returning Series', current_date()))
        results = self.cursor.fetchall()
        if not results:
            notification('TV shows already up to date')
            return
        
        sel = Dialog().multiselect('Update Returning Shows', ['%s (%d)' % (r[1], r[2]) for r in results])
        if sel is None:
            return
        
        if sel:
            results = [results[i] for i in sel]
        
        prog = DialogProgressBG()
        prog.create('Updating TV shows')
        i = 0
        for imdb_id, title, year in results:
            prog.update(int(i * 100 / len(results)), '[COLOR yellow]%s (%d)[/COLOR]' % (title, year))
            i += 1
            self.update_metadata(imdb_id, True)
            sleep(3)
        prog.close()
        
    def __get_fixed_genres(self, genre_ids: list):
        fixed_ids = list(dict.fromkeys([g for g in genre_ids if g in self.genres]))
        if 'ani' in genre_ids:
            fixed_ids = ['ani'] + [g for g in fixed_ids if g in ANIMATION_SUBGENRES]
        if len(fixed_ids) > 1 and 'fam' in fixed_ids:
            fixed_ids.remove('fam')
        if not fixed_ids:
            return genre_ids
        return fixed_ids
    
    def __get_new_values(self, title, sort_title, genre_ids):
        from xbmc import executebuiltin
        dlg = Dialog()
        title = dlg.input('Title', title)
        if not title:
            return None
        sort_title = dlg.input('Sort Title', sort_title).upper()
        if not sort_title:
            return None
        alpha = sort_title[0] if sort_title[0].isalpha() else '#'
        all_genre_ids = list(self.genres.keys())
        all_genre_values = list(self.genres.values())
        genre_pre = [all_genre_ids.index(g) for g in genre_ids]
        sel = dlg.multiselect('Genres', all_genre_values, preselect=genre_pre)
        
        if not sel:
            return None
        genre_ids = [all_genre_ids[i] for i in sel]
        return title, sort_title, alpha, genre_ids
    
    def get_meta_list(self, where="", where_values=None, sort_order='sort_title, release_date', limit:int = 0):
        if limit > 0:
            sort_order += ' LIMIT %d' % limit
        if where_values is None:
            where_values = ()
        
        try:
            self.cursor.execute(f"""
                SELECT
                    imdb_id, db_type, tmdb_id, title, sort_title, starting_letter, plot, main_credits, genre_ids, mpaa,
                    original_language, release_date, year, decade, runtime, rating, votes,
                    search_string, extra_info, status, date_added, date_updated
                FROM
                    media
                {where}
                ORDER BY
                    {sort_order}
            """, where_values)
        except sqlite3.Error:
            return []
        
        meta = []
        for row in self.cursor.fetchall():
            extra_info = json.loads(row[18])
            
            meta.append({
                'imdb_id': row[0],
                'db_type': row[1],
                'media_type': row[1],
                'tmdb_id': row[2],
                'original_title': row[3],
                'title': row[3] if row[10] == 'English' else '%s [COLOR grey][%s][/COLOR]' % (row[3], row[10]),
                'rootname': '%s (%d)' % (row[3], row[12]),
                'sort_title': row[4],
                'starting_letter': row[5],
                'plot': row[6] + '[CR][CR]' + row[7],
                'genre_ids': row[8],
                'mpaa': row[9],
                'original_language': row[10],
                'premiered': row[11],
                'year': str(row[12]),
                'decade': row[13],
                'duration': row[14],
                'rating': row[15],
                'votes': row[16],
                'search_string': row[17],
                'genre': ', '.join(extra_info['genres']),
                'country': extra_info['countries'],
                'total_seasons': extra_info.get('num_seasons', 0),
                'total_aired_eps': extra_info.get('num_episodes', 0),
                'episodes': extra_info.get('episodes'),
                'status': row[19],
                'date_added': row[20],
                'date_modified': row[21],
                'cast': '',
                'director': '',
                'writer': '',
                'keywords': '',
            })
        return meta

    def fetch(self, params, limit=None):
        db_types = params.get('db_types', 'movie, movie_set, tvshow')
        values = [t.strip().lower() for t in db_types.split(',')]
        where = '(%s)' % ' OR '.join(['db_type = ?'] * len(values))
    
        if 'years' in params:
            years = params['years'].split('-', maxsplit=1)
            if len(years) == 1:
                year_where = '(year = ?)'
                year_values = [int(years)]
            else:
                year_where = "(year >= ? AND year <= ?)"
                year_values = [int(years[0]), int(years[1])]
        
            values += year_values
            where += ' AND %s' % year_where
    
        if 'alpha' in params:
            values += [params['alpha'].upper()]
            where += ' AND starting_letter = ?'
    
        if 'genres' in params:
            genre_ids = params['genres'].split(',')
            values += ['%' + g.strip() + '%' for g in genre_ids]
            where += ' AND %s' % ' AND '.join(['genre_ids LIKE ?']*len(genre_ids))
    
        if 'query' in params:
            queries = params['query'].split(',')
            values += ['%' + _search_string(q.strip()) + '%' for q in queries]
            where += ' AND (%s)' % ' OR '.join(['search_string LIKE ?']*len(queries))
    
        sort_order = params.get('sort_order', 'sort_title, release_date')
        if 'limit' not in sort_order.lower():
            sort_order += ' LIMIT %d' % (limit or FETCH_LIMIT)
        return self.get_meta_list('WHERE %s' % where, values, sort_order)

    def can_fetch(self, params):
        return len(self.fetch(params, 1)) > 0
    
    def get_meta_tmdb(self, db_type, tmdb_id):
        results = self.get_meta_list('WHERE db_type = ? AND tmdb_id = ?', (db_type, tmdb_id))
        return {} if not results else results[0]
    
    def get_meta_imdb(self, imdb_id):
        results = self.get_meta_list('WHERE imdb_id = ?', (imdb_id,))
        return {} if not results else results[0]
    
    def get_meta_action(self, action):
        from caches.armani_users import ArmaniUsers
        from caches.favorites import Favorites
        from modules.watched_status import armani_get_watch_history
        from modules.kodi_utils import get_armani_user
        armani_users = ArmaniUsers()
        
        results = []
        if action == 'favorites':
            imdb_ids = armani_users.get_favorites()
            where = 'WHERE imdb_id IN (%s)' % ', '.join(['?'] * len(imdb_ids))
            results = self.get_meta_list(where, imdb_ids)
        elif action == 'watched':
            results = [self.get_meta_tmdb(r[1], r[0]) for r in armani_get_watch_history()]
        elif action == 'playlist':
            results = self.get_meta_playlist()
        
        return [r for r in results if r]
    
    def get_meta_playlist(self):
        from modules.watched_status import armani_remove_watched, armani_remove_unwatched
        from caches.armani_users import ArmaniPlaylist
        playlist = ArmaniPlaylist().get_playlist()
        media_types = playlist.get('media_types') or ['movie']
        watched_status = playlist.get('watched_status') or ['unwatched', 'watched']

        filters = []
        values = []
        filters.append('db_type IN (%s)' % ', '.join(['?'] * len(media_types)))
        values.extend(media_types)
        
        if playlist.get('genres_all'):
            filters.append(' AND '.join(['genre_ids LIKE ?'] * len(playlist['genres_all'])))
            values.extend(['%' + g + '%' for g in playlist['genres_all']])
        if playlist.get('genres_any'):
            filters.append(' OR '.join(['genre_ids LIKE ?'] * len(playlist['genres_any'])))
            values.extend(['%' + g + '%' for g in playlist['genres_any']])
        if playlist.get('genres_none'):
            filters.append(' AND '.join(['genre_ids NOT LIKE ?'] * len(playlist['genres_none'])))
            values.extend(['%' + g + '%' for g in playlist['genres_none']])
        if playlist.get('decades'):
            filters.append(' OR '.join(['(year >= ? AND year <= ?)'] * len(playlist['decades'])))
            for d in playlist['decades']:
                values.extend([int(d), int(d) + 9])
        if playlist.get('languages'):
            filters.append(' OR '.join(['original_language = ?'] * len(playlist['languages'])))
            values.extend(playlist['languages'])
        if playlist.get('search_any'):
            filters.append(' OR '.join(['search_string LIKE ?'] * len(playlist['search_any'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_any']])
        if playlist.get('search_all'):
            filters.append(' AND '.join(['search_string LIKE ?'] * len(playlist['search_all'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_all']])
        if playlist.get('search_none'):
            filters.append(' AND '.join(['search_string NOT LIKE ?'] * len(playlist['search_none'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_none']])

        s_filter = '' if not filters else 'WHERE %s' % ' AND '.join('(%s)' % f for f in filters)
        order = SIZE_FILTERS[playlist.get('size_filter', 'votes_desc')]['order']
        
        results = self.get_meta_list(s_filter, values, order)
        
        if 'unwatched' not in watched_status:
            results = armani_remove_unwatched(results)
        elif 'watched' not in watched_status:
            results = armani_remove_watched(results)
        else:
            results = armani_remove_watched(results, playlist['created'])

        results = results[0:PLAYLIST_LIMIT]
        results.sort(key=lambda x: x['premiered'])
        results.sort(key=lambda x: x['sort_title'])
        return results
    
    def get_header(self, main_key, category_key=None, sort_type=""):
        content_type, category = main_key.split('_')
        h = [MEDIA_TYPES[content_type], CATEGORIES[category]]
        header = '%s / %s' % (h[0], h[1])
        if category_key is not None:
            try:
                header += ' / %s' % self.menu[content_type][category][category_key]['name']
                if sort_type in SORTS:
                    header += ' [%s]' % SORTS[sort_type].lower()
            except KeyError:
                header = '%s / %s / Empty' % (h[0], h[1])
        return header
    
    def get_list(self, main_key):
        content_type, category = main_key.split('_')
        m = self.menu[content_type][category]
        
        return {k: {'key': k, 'title': v['name'], 'summary': v['summary'],
                    'count': v['count'], 'where': v['where']} for k, v in m.items()}
    
    def get_content(self, params):
        content_type, category = params['action'].split('_')
        m = self.menu[content_type][category].get(str(params['value'])) or {}
        if not m:
            return []
        
        order_str = 'sort_title, release_date'
        if 'order' in params:
            order_str = params['order']
            if 'limit' in params:
                order_str += ' LIMIT ' + params['limit']
        return self.get_meta_list(m['where'], sort_order=order_str)
    
    
armani = ArmaniCache()
