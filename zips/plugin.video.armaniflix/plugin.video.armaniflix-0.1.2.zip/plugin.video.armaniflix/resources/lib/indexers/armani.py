# -*- coding: utf-8 -*-
import json
from xbmc import Actor
from xbmcvfs import translatePath
from apis.armani_api import armani_list
from caches.armani_cache import armani
from modules import kodi_utils, settings
from modules.kodi_utils import build_content, make_placeholder_listitem, get_infolabel, external_browse,\
    get_armani_user, local_string as ls, logger
from modules.utils import make_thread_list_enumerate
from modules.watched_status import get_watched_info_tv, get_watched_info_movie, get_watched_status_movie, \
    get_watched_status_tvshow, get_progress_percent, get_bookmarks

sys, build_url, make_listitem, set_view_mode = kodi_utils.sys, kodi_utils.build_url, kodi_utils.make_listitem, kodi_utils.set_view_mode
add_items, set_content, external_browse, end_directory = kodi_utils.add_items, kodi_utils.set_content, kodi_utils.external_browse, kodi_utils.end_directory
kodi_version = kodi_utils.kodi_version
watched_str, unwatched_str = ls(32642), ls(32643)


def armani_build_list(action):
    def _builder():
        for item in user_lists:
            try:
                cm = []
                title = item['title']
                url = build_url({'mode': mode, 'action': action, 'value': item['key']})
                listitem = make_listitem()
                listitem.setLabel(title)
                
                if kodi_version >= 20:
                    info_tag = listitem.getVideoInfoTag()
                    info_tag.setMediaType('video')
                    info_tag.setPlot(item['summary'])
                else:
                    listitem.setInfo('video', {'plot': item['summary']})
                listitem.setProperty('fen.context_main_menu_params', build_url(
                    {'mode': 'menu_editor.edit_menu_external', 'name': title, 'iconImage': 'imdb'}))
                listitem.setProperty('armani_count', str(item['count']))
                
                options_params = build_url({'mode': 'options_menu_choice', 'content': 'armani_menu',
                                            'where': item['where'], 'key': action, 'sub_key': item['key'],
                                            'title': item['title'], 'summary': item['summary'], 'count': item['count'],
                                            'is_widget': 'true'})
                listitem.setProperty('fen.options_params', options_params)
                
                yield url, listitem, True
            except:
                pass
    
    handle = int(sys.argv[1])
    user_lists = armani_list(action)
    
    mode = 'build_armani_list'
    add_items(handle, list(_builder()))
    set_content(handle, 'files')
    end_directory(handle)
    if not external_browse(): set_view_mode('view.main')
    
    
def armani_playlist_generator():
    url = build_url({'mode': 'playlist_editor'})
    listitem = make_listitem()
    listitem.setLabel(ls(33221))
    listitem.setProperty('armani_overlay', 'icons/menu.png')
    info_tag = listitem.getVideoInfoTag()
    info_tag.setMediaType('program')
    info_tag.setPlot(ls(33222))
    return url, listitem, False


def next_episode(tvshow_meta):
    from modules.watched_status import get_next_episode_meta
    from modules.armani_utils import plot_from_meta
    episode_meta = get_next_episode_meta(tvshow_meta)
    if not episode_meta:
        return None
    
    runtime_minutes = episode_meta['runtime'] or 0
    air_date = episode_meta['air_date'] or '2100-01-01'
    try:
        listitem = make_listitem()
        listitem.setProperty('armani_overlay', 'icons/infodialogs/play.png')
        info_tag = listitem.getVideoInfoTag()
        info_tag.setMediaType('episode')
        info_tag.setTitle('[COLOR lightyellow][NEXT EPISODE][/COLOR]')
        info_tag.setTvShowTitle(tvshow_meta['title'])
        info_tag.setTvShowStatus(tvshow_meta['extra_info']['status'])
        info_tag.setSeason(episode_meta['season_number'])
        info_tag.setEpisode(episode_meta['episode_number'])
        info_tag.setPlot(plot_from_meta(episode_meta))
        info_tag.setYear(int(air_date[:4]))
        info_tag.setDuration(runtime_minutes * 60)
        info_tag.setFirstAired(air_date)
        info_tag.setUniqueIDs({'imdb': tvshow_meta['imdb_id'], 'tmdb': str(tvshow_meta['tmdb_id'])})
        info_tag.setIMDBNumber(tvshow_meta['imdb_id'])
        listitem.setLabel('NEXT EPISODE')
        
        tmdb_id = tvshow_meta['tmdb_id']
        season = episode_meta['season_number']
        episode = episode_meta['episode_number']
        
        url_params = build_url({
            'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode
        })
        rescrape_params = build_url({
            'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tvshow_meta['tmdb_id'],
            'season': season, 'episode': episode, 'autoplay': 'false'
        })
        rescrape_no_filter_params = build_url({
            'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode,
            'ignore_scrape_filters': 'true', 'prescrape': 'false', 'autoplay': 'false'
        })
        options_params = build_url(
            {'mode': 'options_menu_choice', 'content': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode,
             'poster': '', 'playcount': 0, 'progress': 0, 'is_widget': external_browse()})
        
        listitem.setProperties({
            'fen.rescrape_params': rescrape_params, 'fen.rescrape_no_filter_params': rescrape_no_filter_params,
            'fen.options_params': options_params
        })
    except:
        return None
    
    return url_params, listitem, False
    
    
class ArmaniMedia:
    def __init__(self, params):
        self.params = params
        self.action = params.get('action', '')
        self.title = params['armani_title']
        self.max_threads = settings.max_threads()
        self.exit_list_params = params.get('exit_list_params', None) or get_infolabel('Container.FolderPath')
        self.is_widget = external_browse()
        self.movie_bookmarks = []
        
        self.list = []
        self.meta = {}
        self.items = []
        
    def fetch_list(self):
        handle = int(sys.argv[1])
        
        if build_content():
            meta_list = armani.get_meta_action(self.action)
            
            self.list = [m['imdb_id'] for m in meta_list]
            self.meta = {m['imdb_id']: m for m in meta_list}
            add_items(handle, self.worker())
        else:
            add_items(handle, make_placeholder_listitem())

        set_content(handle, 'movies')
        end_directory(handle, False)
        
    def worker(self):
        self.movie_bookmarks = get_bookmarks(0, 'movie')
        self.movie_watch_info = get_watched_info_movie(0)
        self.tv_watch_info = get_watched_info_tv(0)
        threads = list(make_thread_list_enumerate(self.build_media_content, self.list, self.max_threads))
        [i.join() for i in threads]
        return self.items
    
    def build_media_content(self, item_position, _id):
        if self.meta[_id]['db_type'] == 'movie':
            self.__build_movie_content(item_position, _id)
        elif self.meta[_id]['db_type'] == 'tvshow':
            self.__build_tvshow_content(item_position, _id)
        
    def __build_movie_content(self, item_position, _id):
        try:
            meta = self.meta[_id]
            meta_get = meta.get
            rootname, title, year = meta_get('rootname'), meta_get('title'), meta_get('year') or '2050'
            tmdb_id, imdb_id, extra_info = meta_get('tmdb_id'), meta_get('imdb_id'), meta_get('extra_info')
        
            playcount, overlay = get_watched_status_movie(self.movie_watch_info, str(meta_get('tmdb_id')))
            listitem = make_listitem()
            set_properties = listitem.setProperties
            clearprog_params, watched_status_params = '', ''
        
            progress = get_progress_percent(self.movie_bookmarks, meta['tmdb_id'])
            if playcount:
                watched_action, watchedstr = 'mark_as_unwatched', unwatched_str
            else:
                watched_action, watchedstr = 'mark_as_watched', watched_str
        
            watched_status_params = build_url(
                {'mode': 'watched_status.mark_movie', 'action': watched_action, 'tmdb_id': tmdb_id, 'title': title,
                 'year': year})
            play_params = build_url({'mode': 'playback.media', 'media_type': 'movie', 'tmdb_id': tmdb_id})
            extras_params = build_url(
                {'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'movie', 'is_widget': self.is_widget})
            options_params = build_url(
                {'mode': 'options_menu_choice', 'content': 'movie', 'tmdb_id': tmdb_id, 'poster': '',
                 'playcount': playcount,
                 'progress': progress, 'exit_menu': self.exit_list_params, 'is_widget': self.is_widget})
            url_params = play_params
        
            if progress:
                clearprog_params = build_url(
                    {'mode': 'watched_status.erase_bookmark', 'media_type': 'movie', 'tmdb_id': tmdb_id,
                     'refresh': 'true'})
                
            display = title
        
            info_tag = listitem.getVideoInfoTag()
            info_tag.setMediaType('movie')
            info_tag.setTitle(display)
            info_tag.setOriginalTitle(meta_get('original_title'))
            info_tag.setPlot(meta_get('plot'))
            info_tag.setYear(int(year))
            info_tag.setRating(meta_get('rating'))
            info_tag.setVotes(meta_get('votes'))
            info_tag.setMpaa(meta_get('mpaa'))
            info_tag.setDuration(meta_get('duration'))
            info_tag.setCountries(meta_get('country'))
            info_tag.setPremiered(meta_get('premiered'))
            info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id)})
            info_tag.setIMDBNumber(imdb_id)
            info_tag.setGenres(meta_get('genre').split(', '))
            info_tag.setWriters(meta_get('writer').split(', '))
            info_tag.setDirectors(meta_get('director').split(', '))
            info_tag.setCast([Actor(name=item['name'], role=item['role'], order=item.get('order', 0))
                              for item in meta_get('cast', [])])
            info_tag.setPlaycount(playcount)
            if progress:
                info_tag.setResumePoint(float(progress))
                set_properties({'WatchedProgress': progress, 'fen.in_progress': 'true'})
        
            listitem.setLabel(display)
        
            # Scraping options
            rescrape_params = build_url(
                {'mode': 'playback.media', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'autoplay': 'false'})
            rescrape_no_filter_params = build_url(
                {'mode': 'playback.media', 'media_type': 'movie', 'tmdb_id': tmdb_id, 'ignore_scrape_filters': 'true',
                 'prescrape': 'false', 'autoplay': 'false'})
        
            armani_info_text = f'Movie • {year} • {meta_get("rating")} ({meta_get("votes"):,})'
            armani_info_text += ' • ' + str(progress) + '%'
        
            set_properties({
                'fen.sort_order': str(item_position), 'fen.playcount': str(playcount),
                'fen.extras_params': extras_params, 'fen.clearprog_params': clearprog_params,
                'fen.options_params': options_params, 'fen.unwatched_params': watched_status_params,
                'fen.watched_params': watched_status_params,
                'fen.rescrape_params': rescrape_params,
                'fen.rescrape_no_filter_params': rescrape_no_filter_params,
                'armani.info_text': armani_info_text
            })
            if self.is_widget: set_properties({'fen.widget': 'true'})
            self.items.append((url_params, listitem, False))
        except:
            pass
        
    def __build_tvshow_content(self, item_position, _id):
        try:
            meta = self.meta[_id]
            meta_get = meta.get
            
            tmdb_id = meta_get('tmdb_id')
            total_seasons, total_aired_eps = meta_get('total_seasons'), meta_get('total_aired_eps')
            playcount, overlay, total_watched, total_unwatched = get_watched_status_tvshow(self.tv_watch_info,
                                                                                           str(tmdb_id),
                                                                                           total_aired_eps)

            try:
                progress = int((float(total_watched) / total_aired_eps) * 100)
            except:
                progress = 0

            listitem = make_listitem()
            set_properties = listitem.setProperties
            rootname, trailer, title, year = meta_get('rootname'), meta_get('trailer'), meta_get('title'), meta_get(
                'year') or '2050'
            tvdb_id, imdb_id = meta_get('tvdb_id'), meta_get('imdb_id')

            options_params = build_url(
                {'mode': 'options_menu_choice', 'content': 'tvshow', 'tmdb_id': tmdb_id, 'poster': '',
                 'playcount': playcount,
                 'progress': progress, 'exit_menu': self.exit_list_params, 'is_widget': self.is_widget})
            extras_params = build_url(
                {'mode': 'extras_menu_choice', 'tmdb_id': tmdb_id, 'media_type': 'tvshow', 'is_widget': self.is_widget})

            url_params = build_url({'mode': 'build_season_list', 'tmdb_id': tmdb_id})

            if progress:
                set_properties({'watchedepisodes': str(total_watched), 'unwatchedepisodes': str(total_unwatched)})
            set_properties({'watchedprogress': str(progress), 'totalepisodes': str(total_aired_eps),
                            'totalseasons': str(total_seasons)})

            # Watched status
            watched_params, unwatched_params = '', ''
            if playcount or progress:
                unwatched_params = build_url(
                    {'mode': 'watched_status.mark_tvshow', 'action': 'mark_as_unwatched', 'title': title, 'year': year,
                     'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id})
            else:
                watched_params = build_url(
                    {'mode': 'watched_status.mark_tvshow', 'action': 'mark_as_watched', 'title': title, 'year': year,
                     'tmdb_id': tmdb_id, 'tvdb_id': tvdb_id})
            set_properties({'fen.unwatched_params': unwatched_params, 'fen.watched_params': watched_params})

            display = title
            listitem.setLabel(display)
            info_tag = listitem.getVideoInfoTag()
            info_tag.setMediaType('tvshow')
            info_tag.setTitle(display)
            info_tag.setTvShowTitle(title)
            info_tag.setOriginalTitle(meta_get('original_title'))
            info_tag.setTvShowStatus(meta_get('status'))
            info_tag.setPlot(meta_get('plot'))
            info_tag.setYear(int(year))
            info_tag.setRating(meta_get('rating'))
            info_tag.setVotes(meta_get('votes'))
            info_tag.setMpaa(meta_get('mpaa'))
            info_tag.setDuration(meta_get('duration'))
            info_tag.setCountries(meta_get('country'))
            info_tag.setPremiered(meta_get('premiered'))
            info_tag.setTagLine(meta_get('tagline') or '')
            info_tag.setStudios((meta_get('studio') or '',))
            info_tag.setUniqueIDs({'imdb': imdb_id, 'tmdb': str(tmdb_id)})
            info_tag.setIMDBNumber(imdb_id)
            info_tag.setGenres(meta_get('genre').split(', '))
            info_tag.setWriters(meta_get('writer').split(', '))
            info_tag.setDirectors(meta_get('director').split(', '))
            info_tag.setCast(
                [Actor(name=item['name'], role=item['role'], order=item.get('order', 0)) for item in
                 meta_get('cast', [])])
            info_tag.setPlaycount(playcount)

            armani_info_text = f'TV Show • {year} • {meta_get("rating")} ({meta_get("votes"):,})'
            set_properties({'fen.sort_order': str(item_position), 'fen.playcount': str(playcount),
                            'fen.extras_params': extras_params, 'fen.options_params': options_params,
                            'armani.info_text': armani_info_text})
            if self.is_widget: set_properties({'fen.widget': 'true'})
            self.items.append((url_params, listitem, True))
        except:
            pass
        