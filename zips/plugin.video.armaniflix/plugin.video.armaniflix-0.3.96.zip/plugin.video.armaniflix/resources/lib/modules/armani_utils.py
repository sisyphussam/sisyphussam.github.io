import re
import unicodedata
from modules.kodi_utils import exists, mkdir, delete, translatePath, notification, logger
from xbmc import executebuiltin
from xbmcgui import Dialog
from xbmcvfs import translatePath, listdir


def str_to_int(str_number: str, default=0):
    str_number = str_number.replace(',', '')
    try:
        i = int(str_number)
    except ValueError:
        i = default
    return i


def current_date() -> str:
    from datetime import date
    return date.today().strftime('%Y-%m-%d')


def dialog_yesnocancel(heading, message, no_label='No', yes_label='Yes') -> int:
    """ Show a yes no dialog with a cancel button

    Args:
        heading: string - the dialog heading
        message: string - message text
        no_label: string - the label to put on the no button
        yes_label: string - the label to put on the cancel button

    Returns:
        -1: cancel, 0: no, 1: yes

    """
    index = Dialog().yesnocustom(heading, message, 'Cancel', no_label, yes_label)
    return -1 if index == 2 else index


def dialog_detail_menu(heading, list_items, use_details=True, preselect=-1, menu_type='detail_menu') -> int:
    executebuiltin('SetProperty(select_type,%s,home)' % menu_type)
    index = Dialog().select(heading, list_items, preselect=preselect, useDetails=use_details)
    executebuiltin('ClearProperty(select_type,home)')
    return index


def dialog_menu(heading, labels, preselect=-1) -> int:
    """ Open the skin's "menu" select dialog

    Args:
        heading: string - dialog heading
        labels: list of strings - items shown in the dialog
        preselect: [opt] integer - index of preselected item

    Returns:
        Returns the integer position of the highlighted item. Returns -1 if the dialog was canceled.

    """
    executebuiltin('SetProperty(select_type,menu,home)')
    index = Dialog().select(heading, labels, preselect=preselect)
    executebuiltin('ClearProperty(select_type,home)')
    return index


def dialog_numeric(heading: str, message: str, default="", hidden=False) -> str:
    """ Open a numeric dialog with a custom heading

    Args:
        heading: string - dialog heading
        message: string - dialog message (a typical numeric dialog's heading)
        default: [opt] string - default value
        hidden: [opt] bool - masked input

    Returns:
        Returns the entered data as a string. Returns the default value if the dialog was canceled.

    """
    executebuiltin('SetProperty(numeric_header,%s,home)' % heading)
    value = Dialog().numeric(0, message, default, hidden)
    executebuiltin('ClearProperty(numeric_header,home)')
    return value


def kodi_log():
    """ View Kodi's log sorted by descending timestamp """
    log_file = translatePath('special://logpath/kodi.log')
    if not exists(log_file):
        return
    with open(log_file, 'r', errors="ignore") as fp:
        Dialog().textviewer('Kodi Log', '\n'.join(reversed(fp.readlines())))


def clear_caches():
    """ Clear Fen's caches (Kodi caches will be cleared in a future update). """
    import sqlite3
    from modules.kodi_utils import favorites_db, metacache_db, maincache_db, debridcache_db, notification
    dbcon = sqlite3.connect(favorites_db)
    dbcon.execute('DELETE FROM favourites')  # ArmaniFlix doesn't use them anyway
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(metacache_db)
    dbcon.execute('DELETE FROM metadata')
    dbcon.execute('DELETE FROM season_metadata')
    dbcon.execute('DELETE FROM function_cache')
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(maincache_db)
    dbcon.execute('DELETE FROM maincache')
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(debridcache_db)
    dbcon.execute('DELETE FROM debrid_data')
    dbcon.commit()
    dbcon.close()
    notification('Cleared all caches')


def keymap_manager():
    """ Download recommended keymaps (keyboard, touch, and remote) from GitHub """
    import requests
    
    url = 'https://sisyphussam.github.io/defaults/armani_maps.xml'
    dir = translatePath('special://profile/keymaps/')
    if not exists(dir):
        mkdir(dir)
        
    files = [f for f in listdir(dir)[1] if f.lower().endswith('.xml')]
    
    if not Dialog().yesno('Download Keymaps', 'Download the latest keymaps from GitHub?[CR](All current map files will be deleted!)'):
        return
        
    for f in files:
        delete(translatePath('special://profile/keymaps/' + f))
        
    response = requests.get(url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"})
    if response.status_code != 200:
        notification('Failed to download keymaps')
        return
    with open(translatePath('special://profile/keymaps/armani_maps.xml'), 'w') as fp:
        fp.write(response.text)
    notification('Success!')
    

def armani_meta_convert(meta, armani_meta_all):
    armani_meta = armani_meta_all.get(meta.get('imdb_id'), {})
    if not armani_meta:
        meta['plot'] = plot_from_meta(meta)
        return meta
    
    meta['title'] = armani_meta['title']
    meta['plot'] = armani_meta['overview']
    meta['rating'] = armani_meta['imdb_rating']
    meta['votes'] = armani_meta['imdb_votes']
    meta['mpaa'] = armani_meta['mpaa']
    meta['premiered'] = armani_meta['release_date']
    meta['genre'] = armani_meta['genres']
    
    return meta
    

def truncate_complete_sentences(string_to_truncate, max_len=400):
    if len(string_to_truncate) > max_len:
        # Truncate
        string_to_truncate = string_to_truncate[0:max_len]
        # Remove the last incomplete sentence
        period_index = str(string_to_truncate).rfind('.')
        if period_index > -1:
            string_to_truncate = string_to_truncate[0:period_index + 1]
        string_to_truncate += '...'
    return string_to_truncate


def plot_from_meta(meta, default_plot=""):
    plot = meta.get('plot', '') or meta.get('overview', '') or default_plot
    plot_string = truncate_complete_sentences(plot)

    # Add director and stars
    director = meta.get('director', '')
    stars = ', '.join([c['name'] for c in meta.get('cast', [])][0:3])
    if director or stars:
        plot_string += '[CR][CR]'
        if director:
            plot_string += '[B]Director:[/B] %s' % director
        if stars:
            if director:
                plot_string += '[CR]'
            plot_string += '[B]Stars:[/B] %s' % stars
    return plot_string


def get_sort_title(title):
    title = title.upper()
    # Sort title initially is the normalized title (accents replaced)
    s_title = unicodedata.normalize('NFD', title)
    s_title = s_title.encode('ascii', 'ignore')
    s_title = s_title.decode("utf-8")
    s_title = re.sub(r'^[^A-Z\d]*', '', s_title)
    s_title = re.sub(r'^(A |AN |THE )', '', s_title, flags=re.IGNORECASE)
    s_title = re.sub(r'^[^A-Z\d]*', '', s_title)
    
    return title if not s_title else s_title


def get_search_string(s: str):
    s = s.lower()
    s = unicodedata.normalize('NFD', s)
    s = s.encode('ascii', 'ignore')
    s = s.decode("utf-8")
    s = re.sub(r'[^A-Za-z\d]+', '', s)
    return s
