# -*- coding: utf-8 -*-
from apis.armani_api import armani_list
from caches.armani_users import ArmaniUsers
from modules import kodi_utils, settings
from modules.kodi_utils import external_browse, local_string as ls, logger
from xbmc import executebuiltin
from xbmcgui import Dialog

sys, build_url, make_listitem, set_view_mode = kodi_utils.sys, kodi_utils.build_url, kodi_utils.make_listitem, kodi_utils.set_view_mode
add_items, set_content, external_browse, end_directory = kodi_utils.add_items, kodi_utils.set_content, kodi_utils.external_browse, kodi_utils.end_directory
kodi_version = kodi_utils.kodi_version
watched_str, unwatched_str = ls(32642), ls(32643)


def armani_settings_users():
    from caches.armani_users import ArmaniUsers
    
    def _builder():
        for user in users:
            url = ''
            list_item = make_listitem()
            if user['id'] == 1:
                list_item.setLabel('%s (admin)' % user['user_name'])
                list_item.setLabel2('Edit the username or PIN of the admin account.')
            else:
                list_item.setLabel(user['user_name'])
                list_item.setLabel2('Edit the username or PIN of the selected user, or delete the account')
            list_item.setProperty('user_id', str(user['id']))
            list_item.setProperty('user_name', str(user['user_name']))
            yield url, list_item, False
    
    users = ArmaniUsers().get_users()
    handle = int(sys.argv[1])
    add_items(handle, list(_builder()))
    set_content(handle, 'files')
    end_directory(handle)


def armani_build_list(action):
    def _builder():
        for item in user_lists:
            try:
                cm = []
                title = item['title']
                url = build_url({'mode': mode, 'action': action, 'value': item['key']})
                listitem = make_listitem()
                listitem.setLabel(title)
                
                if kodi_version >= 20:
                    info_tag = listitem.getVideoInfoTag()
                    info_tag.setMediaType('video')
                    info_tag.setPlot(item['summary'])
                else:
                    listitem.setInfo('video', {'plot': item['summary']})
                listitem.setProperty('fen.context_main_menu_params', build_url(
                    {'mode': 'menu_editor.edit_menu_external', 'name': title, 'iconImage': 'imdb'}))
                listitem.setProperty('armani_count', str(item['count']))
                
                sorts = [
                    ('sort_rating_desc', 'rating DESC, votes DESC'),
                    ('sort_rating_asc', 'rating ASC, votes ASC'),
                    ('sort_votes_desc', 'votes DESC, sort_title, release_date'),
                    ('sort_votes_asc', 'votes ASC, sort_title, release_date'),
                    ('sort_year_desc', 'release_date DESC, sort_title'),
                    ('sort_year_asc', 'release_date ASC, sort_title'),
                ]
                for sort_name, sort_value in sorts:
                    sort_url = build_url({'mode': 'build_armani_list', 'action': action, 'value': item['key'],
                                          'limit': 1000, 'order': sort_value})
                    listitem.setProperty(sort_name, sort_url)
                
                options_params = build_url({'mode': 'options_menu_choice', 'content': 'armani_menu',
                                            'where': item['where'], 'key': action, 'sub_key': item['key'],
                                            'title': item['title'], 'summary': item['summary'], 'count': item['count'],
                                            'is_widget': 'true'})
                
                listitem.setProperty('fen.options_params', options_params)
                listitem.setProperty('armani_add_params', insert_params)
                
                yield url, listitem, True
            except:
                pass
    
    handle = int(sys.argv[1])
    insert_params = build_url({
        'mode': 'armani_admin', 'action': 'imdb_search',
        'db_type': 'movie' if action.startswith('movies_') else 'tvshow'
    })
    
    user_lists = armani_list(action)
    
    mode = 'build_armani_list'
    add_items(handle, list(_builder()))
    set_content(handle, 'files')
    end_directory(handle)
    if not external_browse(): set_view_mode('view.main')
    
    

def next_episode(tvshow_meta):
    from modules.watched_status import get_next_episode_meta
    episode_meta = get_next_episode_meta(tvshow_meta)
    if not episode_meta:
        return None
    
    runtime_minutes = episode_meta['runtime'] or 0
    air_date = episode_meta['release_date'] or '2100-01-01'
    try:
        listitem = make_listitem()
        listitem.setProperty('armani_overlay', 'icons/infodialogs/play.png')
        info_tag = listitem.getVideoInfoTag()
        info_tag.setMediaType('episode')
        info_tag.setTitle(episode_meta['title'])
        info_tag.setTvShowTitle(tvshow_meta['title'])
        info_tag.setTvShowStatus(tvshow_meta['status'])
        info_tag.setSeason(episode_meta['season_number'])
        info_tag.setEpisode(episode_meta['episode_number'])
        info_tag.setPlot(episode_meta['plot'])
        info_tag.setYear(int(air_date[:4]))
        info_tag.setDuration(runtime_minutes * 60)
        info_tag.setFirstAired(air_date)
        info_tag.setUniqueIDs({'imdb': tvshow_meta['imdb_id'], 'tmdb': str(tvshow_meta['tmdb_id'])})
        info_tag.setIMDBNumber(tvshow_meta['imdb_id'])
        listitem.setLabel(episode_meta['title'])
        
        tmdb_id = tvshow_meta['tmdb_id']
        season = episode_meta['season_number']
        episode = episode_meta['episode_number']
        
        url_params = build_url({
            'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode
        })
        rescrape_params = build_url({
            'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tvshow_meta['tmdb_id'],
            'season': season, 'episode': episode, 'autoplay': 'false'
        })
        rescrape_no_filter_params = build_url({
            'mode': 'playback.media', 'media_type': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode,
            'ignore_scrape_filters': 'true', 'prescrape': 'false', 'autoplay': 'false'
        })
        options_params = build_url(
            {'mode': 'options_menu_choice', 'content': 'episode', 'tmdb_id': tmdb_id, 'season': season, 'episode': episode,
             'poster': '', 'playcount': 0, 'progress': 0, 'is_widget': external_browse()})

        armani_insert_params = {'mode': 'armani_admin', 'action': 'imdb_search', 'db_type': 'tvshow'}
        if tvshow_meta.get('status') == 'Returning Series':
            listitem.setProperty('armani_episode_refresh', build_url({'mode': 'armani_admin',
                                                                      'imdb_id': tvshow_meta['imdb_id'],
                                                                      'action': 'update_episodes'}))
        
        listitem.setProperties({
            'fen.rescrape_params': rescrape_params, 'fen.rescrape_no_filter_params': rescrape_no_filter_params,
            'fen.options_params': options_params, 'armani_add_params': build_url(armani_insert_params)
        })
    except:
        return None
    
    return url_params, listitem, False
    
    