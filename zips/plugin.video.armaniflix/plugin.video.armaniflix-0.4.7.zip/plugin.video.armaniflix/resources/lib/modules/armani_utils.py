import re
import unicodedata
from modules.kodi_utils import exists, mkdir, delete, notification, local_string as ls, logger
from xbmc import executebuiltin
from xbmcgui import Dialog, ListItem
from xbmcvfs import translatePath, listdir
from caches.armani_users import UserSettings

ARMANI_DATA_PATH = 'special://profile/addon_data/plugin.video.armaniflix/%s'


def get_file_path(file):
    return translatePath(ARMANI_DATA_PATH % file)


def str_to_int(str_number: str, default=0):
    str_number = str_number.replace(',', '')
    try:
        i = int(str_number)
    except ValueError:
        i = default
    return i


def current_date() -> str:
    from datetime import date
    return date.today().strftime('%Y-%m-%d')


def int_to_bounds(value: int, min_value: int, max_value: int) -> int:
    return max(min(value, max_value), min_value)


def get_language_items(multi=True):
    from caches.armani_media import armani
    languages = {v['id']: v for v in armani.get_existing_languages() if v['count'] > 1 and v['id'] != 'en'}
    items = []
    if any(i in languages for i in ('cn', 'zh')):
        items.append({'name': 'Chinese', 'where': 'original_language IN ("Cantonese","Mandarin")'})
    if any(i in languages for i in ('no', 'nw')):
        items.append({'name': 'Norwegian', 'where': 'original_language LIKE "Norwegian%"'})
    
    languages = [v for v in languages.values() if v['id'] not in ('en', 'cn', 'zh', 'no', 'nw')]
    [items.append({'name': v['name'], 'where': 'original_language == "%s"' % v['name']}) for v in languages]
    items.sort(key=lambda k: k['name'])
    items = [(i['name'], i['where']) for i in items]
    if multi:
        items.insert(0, ('English', 'original_language == "English"'))
    else:
        items.insert(0, ('Foreign', 'original_language != "English"'))
        items.insert(0, ('English', 'original_language == "English"'))
        items.insert(0, ('All', ''))
    return {i[0]: i[1] for i in items}


def get_advanced_search_data():
    with UserSettings() as user_settings:
        data = user_settings.get_json('advanced_search')
    return data or clear_advanced_search_data()


def clear_advanced_search_data():
    data = {
        'filters': {},
        'sort': {'string': 'Title', 'sort': 'sort_title, release_date'}
    }
    with UserSettings() as user_settings:
        user_settings.save_json('advanced_search', data)
    return data


class ArmaniDialog:
    def __init__(self):
        from caches.armani_settings import ArmaniSettings
        self.dialog = Dialog()
        self.settings = ArmaniSettings()
        self.advanced_search_data = get_advanced_search_data()

    def multi_simple(self, heading, list_items, preselect=None):
        menu_name = 'multi_simple'
        if len(list_items) < 7:
            menu_name += str(len(list_items))
        
        if preselect is None:
            preselect = []
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        index = self.dialog.multiselect(heading, list_items, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return index

    def menu(self, heading, labels, preselect=-1):
        menu_name = 'menu%d' % min(11, len(labels))
        logger('MENU', menu_name)
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        ret = self.dialog.select(heading.upper(), labels, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return ret

    def detail_menu(self, heading, list_items, use_details=True, preselect=-1, menu_type='detail_menu') -> int:
        executebuiltin('SetProperty(select_type,%s,home)' % menu_type)
        index = self.dialog.select(heading, list_items, preselect=preselect, useDetails=use_details)
        executebuiltin('ClearProperty(select_type,home)')
        return index

    def column_menu(self, menu_type, num_cols, max_rows, heading: str, labels, multi=False, preselect=None):
        import math
        num_rows = min(max_rows, math.ceil(1.0 * len(labels) / num_cols))
        menu_name = '%s%d' % (menu_type, num_rows)
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        if multi:
            if preselect is None:
                preselect = []
            sel = self.dialog.multiselect(heading.upper(), labels, preselect=preselect)
        else:
            if preselect is None:
                preselect = -1
            sel = self.dialog.select(heading.upper(), labels, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return sel
        
    def yesnocancel(self, heading: str, message: str, no_label=ls(32828), yes_label=ls(32824)):
        """ The YesNoCancel dialog can be used to inform the user about questions and get the answer.

        Args:
            heading: string - dialog heading.
            message: string - message text.
            no_label: [opt] label to put on the no button.
            yes_label: [opt] label to put on the yes button.

        Returns:
            Returns the integer value for the selected button (-1:cancelled, 0:no, 1:yes)

        """
        index = self.dialog.yesnocustom(heading, message, ls(32840), no_label, yes_label)
        return -1 if index == 2 else index

    def numeric(self, heading: str, message: str, default="", hidden=False) -> str:
        """ Open a numeric dialog with a custom heading

        Args:
            heading: string - dialog heading
            message: string - dialog message (a typical numeric dialog's heading)
            default: [opt] string - default value
            hidden: [opt] bool - masked input

        Returns:
            Returns the entered data as a string. Returns the default value if the dialog was canceled.

        """
        executebuiltin('SetProperty(numeric_header,%s,home)' % heading)
        value = self.dialog.numeric(0, message, default, hidden)
        executebuiltin('ClearProperty(numeric_header,home)')
        return value

    def min_max(self, heading, valid_range: tuple, min_value=None, max_value=None):
        def _main_dialog():
            _items = [
                ListItem('Minimum %s' % heading, 'NONE' if min_value is None else str(min_value)),
                ListItem('Maximum %s' % heading, 'NONE' if max_value is None else str(max_value)),
                ListItem('[COLOR yellow]RESET[/COLOR]', 'Clear all values')
            ]
            executebuiltin('SetProperty(select_type,single3,home)')
            _i = self.dialog.select('%s Range' % heading, _items)
            executebuiltin('ClearProperty(select_type,home)')
            return _i
    
        if valid_range[1] > 9999:
            s_range = f'{valid_range[0]:,} - {valid_range[1]:,}'
        else:
            s_range = f'{valid_range[0]} - {valid_range[1]}'
    
        if min_value is None:
            min_value = valid_range[0]
        if max_value is None:
            max_value = valid_range[1]
    
        while 1:
            i = _main_dialog()
            if i < 0:
                if max_value < min_value:
                    max_value = valid_range[1]
                return min_value, max_value
            if i == 0:
                n = self.numeric('%s - Minimum' % heading, s_range)
                if not n:
                    continue
                min_value = max(valid_range[0], min(valid_range[1], int(n)))
            elif i == 1:
                n = self.numeric('%s - Maximum' % heading, s_range)
                if not n:
                    continue
                max_value = max(valid_range[0], min(valid_range[1], int(n)))
            else:
                min_value, max_value = valid_range

    def alpha_menu(self, heading, labels, preselect=-1) -> int:
        import math
        num_rows = min(5, math.ceil(len(labels) / 6.0))
        menu_name = 'alpha%d' % num_rows
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        index = self.dialog.select(heading.upper(), labels, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return index

    def decade_menu(self, heading, labels, preselect, multi=False):
        import math
        num_rows = min(4, math.ceil(len(labels) / 4.0))
        menu_name = 'decades%d' % num_rows
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        if multi:
            sel = self.dialog.multiselect(heading.upper(), labels, preselect=preselect)
        else:
            sel = self.dialog.select(heading.upper(), labels, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return sel
        
    def genre_menu(self, heading, labels, preselect, multi=False):
        import math
        num_rows = min(8, math.ceil(len(labels) / 4.0))
        menu_name = 'genres%d' % num_rows
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        if multi:
            sel = self.dialog.multiselect(heading.upper(), labels, preselect=preselect)
        else:
            sel = self.dialog.select(heading.upper(), labels, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return sel
    
    def person_alpha(self, current_people=None):
        from caches.armani_media import armani
        people = armani.get_people()
        if current_people is None:
            current_people = []
        if current_people:
            people = [p for p in people if p['id'] not in (c['id'] for c in current_people)]
        alpha_list = list(dict.fromkeys(p['name'][0].upper() for p in people))
        
        i = -1
        while 1:
            i = self.alpha_menu('People', alpha_list, i)
            if i < 0:
                return None
            alpha = alpha_list[i]
            alpha_people = [p for p in people if p['name'].upper().startswith(alpha)]
            j = self.menu(f'People / {alpha}', [p['name'] for p in alpha_people])
            if j > -1:
                return alpha_people[j]
    
    def year_range(self, default_range=None, valid_years=None):
        from datetime import date
        
        if not valid_years:
            valid_years = range(1900, 1 + date.today().year)
            
        if not default_range:
            min_year, max_year = valid_years[0], valid_years[-1]
        else:
            min_year = int_to_bounds(default_range[0], valid_years[0], valid_years[-1])
            max_year = int_to_bounds(default_range[1], valid_years[0], valid_years[-1])
        
        pre = -1 if min_year not in valid_years else valid_years.index(min_year)
        j = self.menu('Select First Year', [str(y) for y in valid_years], pre)
        if j < 0:
            return min_year, max_year
        min_year, max_year = valid_years[j], valid_years[-1]
        years = [y for y in valid_years if y >= min_year]
        if len(years) > 1:
            j = self.menu('Select Last Year', [str(y) for y in years])
            if j > -1:
                max_year = years[j]
            
        return min_year, max_year
    
    def rating_range(self):
        ratings = [0.0] + [i / 10.0 for i in range(50, 91)]
        min_rating, max_rating = 0.0, 10.0
    
        i = self.menu('Minimum Rating', [str(r) for r in ratings], 0)
        min_rating = 0.0 if i < 0 else ratings[i]
        if min_rating < 9.0:
            start_max = 50 if min_rating == 0.0 else int(min_rating * 10)
            max_ratings = [i / 10.0 for i in range(start_max, 91)] + [10]
            max_ratings.reverse()
            i = self.menu('Maximum Rating', [str(r) for r in max_ratings], 0)
            max_rating = 10.0 if i < 0 else max_ratings[i]
        
        if min_rating == 0.0:
            min_rating = None
        if max_rating == 10.0:
            max_rating = None
        
        return min_rating, max_rating

    def vote_range(self):
        v = self.numeric('Minimum Vote Count', 'Blank for none')
        min_votes = None if not v else int(v)
        v = self.numeric('Maximum Vote Count', 'Blank for none')
        max_votes = None if not v else int(v)
        return min_votes, max_votes
        
    def reset_advanced(self):
        
        self.settings.delete_starts_with('dialog_advanced_')
        
    def __save_advanced_search(self):
        with UserSettings() as user_settings:
            user_settings.save_json('advanced_search', self.advanced_search_data)
        
    def __get_advanced_media_types(self):
        return self.advanced_search_data['filters'].get('media_type') or {
            'string': 'All', 'where': ''
        }
    
    def __get_advanced_language(self):
        return self.advanced_search_data['filters'].get('language') or {
            'string': 'All', 'where': ''
        }
    
    def __get_advanced_years(self):
        from datetime import date
        y = date.today().year
        
        return self.advanced_search_data['filters'].get('years') or {
            'string': '1900 - %d' % y, 'where': '', 'min_year': 1900, 'max_year': y
        }
        
    def __get_advanced_rating(self):
        return self.advanced_search_data['filters'].get('rating') or {
            'string': '0 - 10 (0 - Max)', 'where': '',
            'min_rating': None, 'max_rating': None, 'min_votes': None, 'max_votes': None
        }
        
    def __get_advanced_genres(self):
        return self.advanced_search_data['filters'].get('genres') or {
            'string': 'Any', 'where': '', 'any': [], 'all': [], 'none': []
        }
    
    def __get_advanced_people(self):
        return self.advanced_search_data['filters'].get('people') or {
            'string': 'None', 'where': '', 'people': [], 'collaboration': False
        }
    
    def __get_advanced_sort(self):
        return self.advanced_search_data['sort'] or {
            'string': 'Title', 'sort': 'sort_title, release_date'
        }

    def advanced_search(self):
        from caches.armani_media import armani
        
        get_language_items()
        
        fmt1 = '[COLOR white]%s[/COLOR]'
        fmt2 = '[COLOR lightyellow]%s[/COLOR]'
        
        adv_values = {
            'media_type': self.__get_advanced_media_types(),
            'language': self.__get_advanced_language(),
            'years': self.__get_advanced_years(),
            'rating': self.__get_advanced_rating(),
            'genres': self.__get_advanced_genres(),
            'people': self.__get_advanced_people()
        }

        sort_order = self.__get_advanced_sort()
        executebuiltin('SetFocus(30000)')
        i = -1
        while 1:
            where_list = ['(%s)' % v['where'] for v in adv_values.values() if v['where']]
            if not where_list:
                num_results = 0
            else:
                armani.cursor.execute(f'SELECT COUNT(*) FROM media WHERE {" AND ".join(where_list)}')
                num_results = armani.cursor.fetchone()[0]
            
            items = [
                ListItem('[COLOR yellow]SEARCH[/COLOR]', f'[COLOR lightyellow]{num_results} titles[/COLOR]'),
                ListItem(fmt1 % 'Type', fmt2 % adv_values['media_type']['string']),
                ListItem(fmt1 % 'Language', fmt2 % adv_values['language']['string']),
                ListItem(fmt1 % 'Release Date', fmt2 % adv_values['years']['string']),
                ListItem(fmt1 % 'IMDb Rating', fmt2 % adv_values['rating']['string']),
                ListItem(fmt1 % 'Genres', fmt2 % adv_values['genres']['string']),
                ListItem(fmt1 % 'People', fmt2 % adv_values['people']['string']),
                ListItem(fmt1 % 'Sort By', fmt2 % sort_order['string']),
                ListItem('[COLOR tomato]RESET[/COLOR]'),
            ]
            
            i = self.detail_menu('Advanced Search', items, True, i, 'advanced')
            if i < 0:
                executebuiltin('SetFocus(8001)')
                return None, None
            if i == 0:
                if num_results == 0:
                    notification('No Results')
                    continue
                break
            elif i == 1:
                adv_values['media_type'] = self.advanced_media_type()
            elif i == 2:
                adv_values['language'] = self.advanced_language()
            elif i == 3:
                adv_values['years'] = self.advanced_years()
            elif i == 4:
                adv_values['rating'] = self.advanced_rating()
            elif i == 5:
                adv_values['genres'] = self.advanced_genres()
            elif i == 6:
                adv_values['people'] = self.advanced_people()
            elif i == 7:
                sort_order = self.advanced_sort()
            else:
                self.advanced_search_data = clear_advanced_search_data()
                return self.advanced_search()

        executebuiltin('SetFocus(8001)')
        return 'WHERE ' + ' AND '.join(where_list), sort_order['sort']

    def advanced_sort(self):
        sorts = {
            'Title': 'sort_title, release_date',
            'Newest': 'release_date DESC, sort_title',
            'Oldest': 'release_date, sort_title',
            'Highest Rated': 'rating DESC, votes DESC',
            'Lowest Rated': 'rating, votes',
            'Most Votes': 'votes DESC, sort_title',
            'Fewest Votes': 'votes, sort_title'
        }
        sort_keys = list(sorts.keys())
        saved = self.__get_advanced_sort()
        saved_sort = saved['string']
        if saved_sort not in sorts:
            saved_sort = 'Title'
    
        i = self.menu('Sort By', sort_keys, sort_keys.index(saved_sort))
        if i > -1:
            saved_sort = sort_keys[i]
        saved.update({'string': saved_sort, 'sort': sorts[saved_sort]})
        self.advanced_search_data['sort'] = saved
        self.__save_advanced_search()
        return saved
    
    def advanced_media_type(self):
        media_types = {
            'All': '',
            'Movies': 'db_type == "movie"',
            'TV Shows': 'db_type == "tvshow"',
            'Returning Series': 'db_type == "tvshow" AND status == "Returning Series"',
            'Completed Series': 'db_type == "tvshow" AND status != "Returning Series"'
        }
        media_type_keys = list(media_types.keys())
        saved = self.__get_advanced_media_types()
        media_type = saved['string']
        if media_type not in media_types:
            media_type = 'All'
            
        i = self.menu('Media Type', media_type_keys, media_type_keys.index(media_type))
        if i > -1:
            media_type = media_type_keys[i]
        saved.update({'string': media_type, 'where': media_types[media_type]})
        self.advanced_search_data['filters']['media_type'] = saved
        self.__save_advanced_search()
        return saved

    def advanced_language(self):
        languages = get_language_items(False)
        language_keys = list(languages.keys())
        saved = self.__get_advanced_language()
        language = saved['string']
        if language not in languages:
            language = 'All'
    
        i = self.menu('Language', [v for v in language_keys], language_keys.index(language))
        if i > -1:
            language = language_keys[i]
        saved.update({'string': language, 'where': languages[language]})
        self.advanced_search_data['filters']['language'] = saved
        self.__save_advanced_search()
        return saved
        
    def advanced_years(self):
        from caches.armani_media import armani
        saved = self.__get_advanced_years()
        try:
            min_year = int(saved.get('min_year') or '0')
            max_year = int(saved.get('max_year') or '0')
        except ValueError:
            min_year, max_year = 0, 0
        
        armani.cursor.execute('SELECT DISTINCT year FROM media ORDER BY year')
        valid_years = [r[0] for r in armani.cursor.fetchall()]
        
        min_year, max_year = self.year_range((min_year, max_year), valid_years)
        where = []
        if min_year:
            where.append(f'year >= {min_year}')
        if max_year:
            where.append(f'year <= {max_year}')
        saved.update({'string': f'{min_year or "1900"} - {max_year or "Now"}',
                      'where': '' if not where else ' AND '.join(where),
                      'min_year': min_year, 'max_year': max_year})
        self.advanced_search_data['filters']['years'] = saved
        self.__save_advanced_search()
        return saved
    
    def advanced_rating(self):
        saved = self.__get_advanced_rating()
        min_rating = saved.get('min_rating')
        max_rating = saved.get('max_rating')
        min_votes = saved.get('min_votes')
        max_votes = saved.get('max_votes')
        i = -1
        while 1:
            rating_string = f'{min_rating or 0.0} - {max_rating or 10.0}'
            vote_string = f'{min_votes or 0} - {max_votes or "MAX"}'
            items = [
                ['Rating', rating_string],
                ['Vote Count', vote_string]
            ]
            i = self.__advanced_menu('IMDb Rating', items, i)
            if i < 0:
                break
            if i == 0:
                min_rating = max_rating = min_votes = max_votes = None
            elif i == 1:
                min_rating, max_rating = self.rating_range()
            else:
                min_votes, max_votes = self.vote_range()
        
        where = []
        if min_rating:
            where.append(f'rating >= {min_rating}')
        if max_rating:
            where.append(f'rating <= {max_rating}')
        if min_votes:
            where.append(f'votes >= {min_votes}')
        if max_votes:
            where.append(f'votes <= {max_votes}')

        saved.update({
            'string': f'{rating_string} ({vote_string})',
            'where': '' if not where else ' AND '.join(where),
            'min_rating': min_rating, 'max_rating': max_rating,
            'min_votes': min_votes, 'max_votes': max_votes
        })
        self.advanced_search_data['filters']['rating'] = saved
        self.__save_advanced_search()
        return saved
    
    def advanced_genres(self):
        from caches.armani_media import armani
        saved = self.__get_advanced_genres()
        
        genres = armani.get_existing_genres()
        genre_ids = [g['id'] for g in genres]
        genre_names = [g['name'] for g in genres]
        genre_keys = ['any', 'all', 'none']
        genre_headings = ['Include ANY Genre', 'Include ALL Genres', 'Exclude Genres']
        for k in ('any', 'all', 'none'):
            saved[k] = [g for g in saved[k] if g in genre_ids]
    
        i = -1
        while 1:
            genre_indices = {'any': [genre_ids.index(g) for g in saved['any']],
                             'all': [genre_ids.index(g) for g in saved['all']],
                             'none': [genre_ids.index(g) for g in saved['none']]}
        
            items = [
                ['Any', ', '.join(genre_names[j] for j in genre_indices['any']) or 'None'],
                ['All', ', '.join(genre_names[j] for j in genre_indices['all']) or 'None'],
                ['Exclude', ', '.join(genre_names[j] for j in genre_indices['none']) or 'None']
            ]
            i = self.__advanced_menu('Genres', items, i)
        
            if i < 0:
                break
            if i == 0:
                saved.update({'any': [], 'all': [], 'none': []})
            else:
                genre_key, genre_heading = genre_keys[i - 1], genre_headings[i - 1]
                pre = [genre_ids.index(g) for g in saved[genre_key]]
                sel = self.genre_menu(genre_heading, genre_names, pre, True)
                if sel is None:
                    continue
                saved[genre_key] = [genre_ids[i] for i in sel]

        strings = []
        where = []
        if genre_indices['any']:
            strings.append('ANY(%s)' % ','.join(genre_names[i] for i in genre_indices['any']))
            where.append('(%s)' % (' OR '.join('genre_ids LIKE "%s"' % ('%' + g + '%') for g in saved['any'])))
        if genre_indices['all']:
            strings.append('ALL(%s)' % ','.join(genre_names[i] for i in genre_indices['all']))
            where.append(' AND '.join('genre_ids LIKE "%s"' % ('%' + g + '%') for g in saved['all']))
        if genre_indices['none']:
            strings.append('EXCLUDE(%s)' % ','.join(genre_names[i] for i in genre_indices['none']))
            where.append(' AND '.join('genre_ids NOT LIKE "%s"' % ('%' + g + '%') for g in saved['none']))
            
        saved.update({'string': ' | '.join(strings) or 'None', 'where': ' AND '.join(where) or ''})
        self.advanced_search_data['filters']['genres'] = saved
        self.__save_advanced_search()
        return saved

    def advanced_people(self):
        from caches.armani_media import armani
        saved = self.__get_advanced_people()
        
        saved_people = saved.get('people', [])
        collaboration = saved.get('collaboration', False)
        i = -1
        while 1:
            items = [
                ['Add Person', ', '.join(p['name'] for p in saved_people) or 'None'],
                ['Remove People', f'{len(saved_people)} people added'],
                ['Collaboration', str(collaboration)]
            ]
            i = self.__advanced_menu('People', items, i)
            if i < 0:
                break
            if i == 0:
                saved_people = []
            elif i == 1:
                person = self.person_alpha(saved_people)
                if person:
                    saved_people.append(person)
                    saved_people.sort(key=lambda k: k['name'])
            elif i == 2:
                if not saved_people:
                    continue
                if len(saved_people) == 1:
                    saved_people = []
                else:
                    sel = self.dialog.multiselect('Remove People', [p['name'] for p in saved_people])
                    if sel:
                        delete_ids = [saved_people[i]['id'] for i in sel]
                        saved_people = [p for p in saved_people if p['id'] not in delete_ids]
            else:
                collaboration = not collaboration

        strings = []
        where = []
        joiner = ' AND ' if collaboration else ' OR '
        for p in saved_people:
            s_id = '%<' + p['id'] + '>%'
            where.append(f'(cast_ids LIKE "{s_id}" OR crew_ids LIKE "{s_id}")')
            strings.append(p['name'])
        
        saved = {
            'string': joiner.join(strings) or 'None',
            'where': joiner.join(where),
            'people': saved_people,
            'collaboration': collaboration
        }
        self.advanced_search_data['filters']['people'] = saved
        self.__save_advanced_search()
        return saved

    def __advanced_menu(self, heading, items, preselect=-1):
        fmt1 = '[COLOR white]%s[/COLOR]'
        fmt2 = '[COLOR lightyellow]%s[/COLOR]'
        list_items = [ListItem('[COLOR yellow]RESET[/COLOR]', '[COLOR grey]Restore defaults[/COLOR]')]
        list_items.extend([ListItem(fmt1 % i[0], fmt2 % str(i[1])) for i in items])
    
        executebuiltin('SetProperty(select_type,multi%d,home)' % len(list_items))
        i = self.dialog.select(heading, list_items, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return i


def kodi_log():
    """ View Kodi's log sorted by descending timestamp """
    log_file = translatePath('special://logpath/kodi.log')
    if not exists(log_file):
        return
    with open(log_file, 'r', errors="ignore") as fp:
        Dialog().textviewer('Kodi Log', '\n'.join(reversed(fp.readlines())))


def clear_caches():
    """ Clear Fen's caches (Kodi caches will be cleared in a future update). """
    import sqlite3
    from modules.kodi_utils import favorites_db, metacache_db, maincache_db, debridcache_db, notification
    dbcon = sqlite3.connect(favorites_db)
    dbcon.execute('DELETE FROM favourites')  # ArmaniFlix doesn't use them anyway
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(metacache_db)
    dbcon.execute('DELETE FROM metadata')
    dbcon.execute('DELETE FROM season_metadata')
    dbcon.execute('DELETE FROM function_cache')
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(maincache_db)
    dbcon.execute('DELETE FROM maincache')
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(debridcache_db)
    dbcon.execute('DELETE FROM debrid_data')
    dbcon.commit()
    dbcon.close()
    notification('Cleared all caches')


def keymap_manager():
    """ Download recommended keymaps (keyboard, touch, and remote) from GitHub """
    import requests
    
    url = 'https://sisyphussam.github.io/defaults/armani_maps.xml'
    dir = translatePath('special://profile/keymaps/')
    if not exists(dir):
        mkdir(dir)
        
    files = [f for f in listdir(dir)[1] if f.lower().endswith('.xml')]
    
    if not Dialog().yesno('Download Keymaps', 'Download the latest keymaps from GitHub?[CR](All current map files will be deleted!)'):
        return
        
    for f in files:
        delete(translatePath('special://profile/keymaps/' + f))
        
    response = requests.get(url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"})
    if response.status_code != 200:
        notification('Failed to download keymaps')
        return
    with open(translatePath('special://profile/keymaps/armani_maps.xml'), 'w') as fp:
        fp.write(response.text)
    notification('Success!')
    

def armani_meta_convert(meta, armani_meta_all):
    armani_meta = armani_meta_all.get(meta.get('imdb_id'), {})
    if not armani_meta:
        meta['plot'] = plot_from_meta(meta)
        return meta
    
    meta['title'] = armani_meta['title']
    meta['plot'] = armani_meta['overview']
    meta['rating'] = armani_meta['imdb_rating']
    meta['votes'] = armani_meta['imdb_votes']
    meta['mpaa'] = armani_meta['mpaa']
    meta['premiered'] = armani_meta['release_date']
    meta['genre'] = armani_meta['genres']
    
    return meta
    

def truncate_complete_sentences(string_to_truncate, max_len=300):
    if len(string_to_truncate) > max_len:
        # Truncate
        string_to_truncate = string_to_truncate[0:max_len]
        # Remove the last incomplete sentence
        period_index = str(string_to_truncate).rfind('.')
        if period_index > -1:
            string_to_truncate = string_to_truncate[0:period_index + 1]
        string_to_truncate += '...'
    return string_to_truncate


def plot_from_meta(meta, default_plot=""):
    plot = meta.get('plot', '') or meta.get('overview', '') or default_plot
    plot_string = truncate_complete_sentences(plot)

    # Add director and stars
    director = meta.get('director', '')
    stars = ', '.join([c['name'] for c in meta.get('cast', [])][0:3])
    if director or stars:
        plot_string += '[CR][CR]'
        if director:
            plot_string += '[B]Director:[/B] %s' % director
        if stars:
            if director:
                plot_string += '[CR]'
            plot_string += '[B]Stars:[/B] %s' % stars
    return plot_string


def get_sort_title(title):
    title = title.upper()
    # Sort title initially is the normalized title (accents replaced)
    s_title = unicodedata.normalize('NFD', title)
    s_title = s_title.encode('ascii', 'ignore')
    s_title = s_title.decode("utf-8")
    s_title = re.sub(r'^[^A-Z\d]*', '', s_title)
    s_title = re.sub(r'^(A |AN |THE )', '', s_title, flags=re.IGNORECASE)
    s_title = re.sub(r'^[^A-Z\d]*', '', s_title)
    
    return title if not s_title else s_title


def get_search_string(s: str):
    s = s.lower()
    s = unicodedata.normalize('NFD', s)
    s = s.encode('ascii', 'ignore')
    s = s.decode("utf-8")
    s = re.sub(r'[^A-Za-z\d]+', '', s)
    return s
