import json
import time
import requests
from xbmcgui import Dialog, DialogProgressBG
import sqlite3
import re
import unicodedata
from modules.kodi_utils import kodi_refresh, notification, local_string as ls, logger
from caches.armani_settings import ArmaniSettings
from caches.armani_users import UserSettings
from modules.armani_utils import truncate_complete_sentences, get_file_path, ArmaniDialog
from modules.settings import tmdb_api_key
from apis.armani_imdb_api import IMDB_HEADERS

ARMANI_STR = ls(32036).upper()
ADDON_DATA = 'special://profile/addon_data/plugin.video.armaniflix/%s'
MEDIA_DB = get_file_path('armani_media.db')
SEARCH_FILTERS = get_file_path('search_filters.json')

GIT = {
    'search_filters': 'https://sisyphussam.github.io/defaults/search_filters.json',
    'database': 'https://sisyphussam.github.io/defaults/armani_media.db'
}


MEDIA_TYPES = {'movies': ls(32028), 'tvshows': ls(32029)}
CATEGORIES = {'alpha': ls(33621), 'genres': ls(33622), 'decades': ls(33623)}
SORTS = {'rating': ls(33515), 'votes': ls(33516), 'year': ls(33517), 'random': ls(33218)}

NUM_EXAMPLES = 6
FETCH_LIMIT = 250
PLAYLIST_LIMIT = 250

GIT_HEADERS = {"Cache-Control": "no-cache", "Pragma": "no-cache"}

SIZE_FILTERS = {
    'votes_desc': {'label': 'Highest Vote Count (IMDb)', 'order': 'votes DESC, rating DESC'},
    'votes_asc': {'label': 'Lowest Vote Count (IMDb)', 'order': 'votes ASC, rating DESC'},
    'rating_desc': {'label': 'Highest Rating (IMDb)', 'order': 'rating DESC, votes DESC'},
    'rating_asc': {'label': 'Lowest Rating (IMDb)', 'order': 'rating ASC, votes DESC'},
    'year_asc': {'label': 'Oldest Releases', 'order': 'release_date ASC, votes DESC'},
    'year_desc': {'label': 'Latest Releases', 'order': 'release_date DESC, votes DESC'}
}


def _search_string(s):
    s = unicodedata.normalize('NFD', s.lower())
    s = s.encode('ascii', 'ignore')
    s = s.decode("utf-8")
    s = re.sub(r'[^A-Za-z\d]+', '', s)
    return s


def _db_types_to_where(db_types: str):
    db_types = [t.strip().lower() for t in db_types.split(',')]
    where = ' OR '.join(['db_type = ?'] * len(db_types))
    return where, db_types


def _get_tmdb(url_tail, session=None):
    api_str = '&api_key=%s' if '?' in url_tail else '?api_key=%s'
    url = 'https://api.themoviedb.org/3/' + url_tail + api_str % tmdb_api_key()
    
    try:
        if not session:
            tmdb_response = requests.get(url, timeout=5)
        else:
            tmdb_response = session.get(url, timeout=5)
    except requests.exceptions.Timeout:
        return {}
    
    if tmdb_response.status_code != 200:
        return {}
    return tmdb_response.json()


class ArmaniCache:
    """ A database containing all movies and TV shows listed in IMDb CSV files. """
    
    def __init__(self):
        self.settings = ArmaniSettings()
        self.language = 'en-US'
        self.conn = sqlite3.connect(MEDIA_DB)
        self.cursor = self.conn.cursor()
        self.insert_label = ''
        self.list_import_count = 0
        
    def __launch_menu_item(self, title, where):
        from modules.kodi_utils import build_url, close_all_dialog
        from xbmc import executebuiltin
        self.cursor.execute('SELECT * FROM media %s LIMIT 1' % where)
        if not self.cursor.fetchall():
            notification('No titles found')
            return
    
        url = {'mode': 'armani_fetch', 'where': where, 'armani_title': title}
        close_all_dialog()
        executebuiltin('RunPlugin(%s)' % build_url(url))
        
    def __open_menu(self, heading, options, menu_func, index_key) -> int:
        if not options:
            return -1
        with UserSettings() as user_settings:
            home_menu = user_settings.get_json('home_menu')
        pre = home_menu.get(index_key) or -1
        
        #menu_pre = self.settings.get_json('menu_indices') or {}
        #pre = int(menu_pre.get(index_key, -1))
        i = menu_func(heading, options, pre)
        if i < 0:
            return -1
        home_menu[index_key] = i
        with UserSettings() as user_settings:
            user_settings.save_json('home_menu', home_menu)
        
        #menu_pre[index_key] = i
        #self.settings.save_json('menu_indices', menu_pre)
        return i
    
    def open_alpha(self, db_type):
        if db_type == 'movie':
            title = 'Movie / A - Z'
        else:
            title = 'TV / A - Z'
        alpha = self.get_existing_alpha(db_type)
        if not alpha:
            return
        
        options = alpha + ['All']
        
        i = self.__open_menu(title, options, ArmaniDialog().alpha_menu, 'alpha_%s' % db_type)
        if i < 0:
            return
        
        where = 'WHERE db_type = "%s"' % db_type
        if i < len(alpha):
            a = alpha[i]
            where += ' AND starting_letter = "%s"' % a
        else:
            a = 'All Titles'
            
        title += ' / ' + a
        self.__launch_menu_item(title, where)

    def open_genre(self, db_type):
        if db_type == 'movie':
            title = 'Movies / Genres'
        else:
            title = 'TV / Genres'
        genres = self.get_existing_genres(db_type)

        i = self.__open_menu(title, [g['name'] for g in genres], ArmaniDialog().genre_menu, 'genres_%s' % db_type)
        if i < 0:
            return
        g = genres[i]
        where = 'WHERE db_type = "%s"' % db_type
        where += ' AND genre_ids LIKE "%' + g['id'] + '%"'
        title += ' / ' + g['name']
        self.__launch_menu_item(title, where)
        
    def open_decade(self, db_type):
        if db_type == 'movie':
            title = 'Movies / Decades'
        else:
            title = 'TV / Decades'
        decades = self.get_existing_decades(db_type)
    
        i = self.__open_menu(title, ['%ds' % d for d in decades], ArmaniDialog().decade_menu, 'decades_%s' % db_type)
        if i < 0:
            return
        d = decades[i]
        where = 'WHERE db_type = "%s"' % db_type
        where += ' AND decade = %d' % d
        title += ' / %d - %d' % (d, d + 9)
        self.__launch_menu_item(title, where)
        
    def get_genres(self):
        self.cursor.execute('SELECT id, name FROM genres ORDER BY name')
        return {r[0]: r[1] for r in self.cursor.fetchall()}
    
    def get_languages(self):
        self.cursor.execute('SELECT id, name FROM languages ORDER BY name')
        return {r[0]: r[1] for r in self.cursor.fetchall()}
    
    def get_countries(self):
        self.cursor.execute('SELECT id, name FROM countries ORDER BY name')
        return {r[0]: r[1] for r in self.cursor.fetchall()}
    
    def get_existing_genres(self, db_type=None):
        all_genres = self.get_genres()
        existing_genres = []
        db_where = '' if not db_type else ' AND db_type = "%s"' % db_type
        
        for genre_id, genre_name in all_genres.items():
            where = 'genre_ids LIKE "%' + genre_id + '%"' + db_where
            self.cursor.execute('SELECT COUNT(*) FROM media WHERE %s' % where)
            result = self.cursor.fetchone()
            if result[0] > 0:
                existing_genres.append({'id': genre_id, 'name': genre_name, 'count': result[0]})
                
        return existing_genres
    
    def get_existing_languages(self, db_type=None):
        all_languages = self.get_languages()
        existing_languages = []
        db_where = '' if not db_type else ' AND db_type = "%s"' % db_type
        
        for lang_id, lang_name in all_languages.items():
            where = ('original_language = "%s"' % lang_name) + db_where
            self.cursor.execute('SELECT COUNT(*) FROM media WHERE %s' % where)
            result = self.cursor.fetchone()
            if result[0] > 0:
                existing_languages.append({'id': lang_id, 'name': lang_name, 'count': result[0]})
        return existing_languages
    
    def get_existing_decades(self, db_type=None):
        where = '' if not db_type else 'WHERE db_type = "%s"' % db_type
        self.cursor.execute('SELECT DISTINCT(decade) FROM media %s' % where)
        return sorted([r[0] for r in self.cursor.fetchall()])
    
    def get_existing_alpha(self, db_type=None):
        where = '' if not db_type else 'WHERE db_type = "%s"' % db_type
        self.cursor.execute('SELECT DISTINCT(starting_letter) FROM media %s' % where)
        return sorted([r[0] for r in self.cursor.fetchall()])
        
    def check(self):
        from xbmcvfs import exists
        
        # Check if the media table exists in the database
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        results = [r[0] for r in self.cursor.fetchall()]
        
        if results:
            if 'media' not in results:
                self.__reset_media_table()
                logger(ARMANI_STR, 'Created media table')
            if 'languages' not in results:
                self.__reset_languages_table()
                logger(ARMANI_STR, 'Created languages table')
            if 'countries' not in results:
                self.__reset_countries_table()
                logger(ARMANI_STR, 'Created countries table')
            if 'genres' not in results:
                self.__reset_genres_table()
                logger(ARMANI_STR, 'Created genres table')
            if 'people' not in results:
                self.__reset_people_table()
                logger(ARMANI_STR, 'Created people table')
        else:
            self.__reset_media_table()
            self.__reset_languages_table()
            self.__reset_countries_table()
            self.__reset_genres_table()
            self.__reset_people_table()
            logger(ARMANI_STR, 'Created all tables')
            
        # Check if the database is empty
        self.cursor.execute('SELECT * FROM media LIMIT 1')
        results = self.cursor.fetchall()
        if not results and Dialog().yesno('Empty Database', 'There are no titles in the database. Download defaults?'):
            self.__download_default_database()
            
    def __reset_media_table(self):
        self.cursor.executescript("""
            DROP TABLE IF EXISTS media;
            CREATE TABLE media (
                imdb_id TEXT NOT NULL UNIQUE,
                tmdb_id INTEGER NOT NULL,
                db_type TEXT NOT NULL,
                title TEXT,
                sort_title TEXT,
                starting_letter TEXT,
                plot TEXT,
                main_credits TEXT,
                genre_ids TEXT,
                mpaa TEXT,
                original_language TEXT,
                release_date TEXT,
                year INTEGER,
                decade INTEGER,
                runtime INTEGER,
                rating REAL,
                votes INTEGER,
                search_string TEXT,
                cast_ids TEXT,
                crew_ids TEXT,
                extra_info TEXT,
                status TEXT,
                date_added TEXT,
                date_updated TEXT,
                UNIQUE(tmdb_id, db_type)
            );
        """)
        self.conn.commit()
        
    def __reset_genres_table(self):
        from apis.armani_imdb_api import IMDB_GENRES

        self.cursor.executescript("""
            DROP TABLE IF EXISTS genres;
            CREATE TABLE genres (
                id TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL UNIQUE
            );
        """)
        genres = [(v, k) for k, v in IMDB_GENRES.items()]
        genres += [('sil', 'Silent Film'),
                   ('sup', 'Superhero'),
                   ('sur', 'Surrealism')]
        self.cursor.executemany('INSERT INTO genres VALUES (?, ?)', genres)
        self.conn.commit()
        
        # Ensure that media table does not contain invalid genres
        self.cursor.execute('SELECT imdb_id, genre_ids FROM media ORDER BY sort_title, release_date')
        results = self.cursor.fetchall()
        if not results:
            return

        for imdb_id, genre_text in results:
            genre_ids = [g.strip() for g in genre_text.split(',')]
            new_genre_ids = [g.strip() for g in genre_text.split(',')]
            if len(genre_ids) != len(new_genre_ids):
                genre_text = ','.join(new_genre_ids)
                logger(ARMANI_STR, 'Updated genres for %s: %s' % (imdb_id, genre_text))
                self.cursor.execute('UPDATE media SET genres = ? WHERE imdb_id = ?', (genre_text, imdb_id))

        self.conn.commit()
        
    def __reset_languages_table(self):
        languages = _get_tmdb('configuration/languages')
        if not languages:
            logger(ARMANI_STR, 'TMDB - could not get languages')
            return
        languages = [(v['iso_639_1'], v['english_name']) for v in languages]

        self.cursor.executescript("""
            DROP TABLE IF EXISTS languages;
            CREATE TABLE languages (
                id TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL
            );
        """)
        self.cursor.executemany('INSERT OR IGNORE INTO languages VALUES(?, ?)', languages)
        self.conn.commit()
        
    def __reset_countries_table(self):
        countries = _get_tmdb('configuration/countries?language=en-US')
        if not countries:
            logger(ARMANI_STR, 'TMDB - could not get countries')
            return
        countries = [(v['iso_3166_1'], v['english_name']) for v in countries]
        
        self.cursor.executescript("""
            DROP TABLE IF EXISTS countries;
            CREATE TABLE countries (
                id TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL
            );
        """)
        self.cursor.executemany('INSERT OR IGNORE INTO countries VALUES(?, ?)', countries)
        self.conn.commit()
        
    def __reset_people_table(self):
        self.cursor.executescript("""
            DROP TABLE IF EXISTS people;
            CREATE TABLE people (
                imdb_id TEXT NOT NULL UNIQUE,
                name TEXT NOT NULL,
                known_for TEXT,
                jobs TEXT NOT NULL
            );
        """)
        self.conn.commit()
        
    def __person_select(self, selected_person=None):
        from modules.armani_utils import ArmaniDialog
        self.cursor.execute('SELECT imdb_id, name, known_for, jobs FROM people ORDER BY name')
        people = [{'id': p[0], 'name': p[1], 'known_for': p[2], 'jobs': p[3]} for p in self.cursor.fetchall()]
        preselect = -1
        if selected_person:
            for i in range(len(people)):
                if selected_person['id'] == people[i]['id']:
                    preselect = i
                    break
                if selected_person['name'] >= people[i]['name']:
                    preselect = i
        
        if not people:
            notification('No people')
            return None
        if len(people) == 1:
            person_index = 0
        else:
            person_index = ArmaniDialog().menu('People', [p['name'] for p in people], preselect)
            if person_index < 0:
                return None
        person = people[person_index]
        person['index'] = person_index
        return person
    
    def __modify_search_results(self, heading, search_results):
        from xbmcgui import ListItem
        from modules.armani_utils import ArmaniDialog, get_sort_title
        from caches.armani_users import ArmaniUsers
        
        if search_results is None:
            return
        
        genres = self.get_genres()
        if ArmaniUsers().user_id != 1:
            existing_ids = self.get_imdb_ids()
            search_results = [r for r in search_results if r['id'] not in existing_ids]
        if not search_results:
            notification('No Results')
            return
        
        dlg = ArmaniDialog()

        with requests.Session() as session:
            prev_id = None
            
            while 1:
                self.cursor.execute(
                    'SELECT imdb_id, title, sort_title, year, genre_ids, rating, votes, plot '
                    'FROM media ORDER BY sort_title, release_date')
                existing = {r[0]: {
                    'id': r[0], 'label': '%s (%d)' % (r[1], r[3]), 'sort_title': '%s (%d)' % (r[2], r[3]),
                    'info': '[COLOR tomato]%s (%d)[/COLOR][CR]%s[CR][COLOR lightyellow]%.1f (%d)[/COLOR][CR][CR]%s'
                            % (r[1].upper(), r[3], ', '.join([genres[g] for g in r[4].split(',')]), r[5], r[6], r[7])
                } for r in self.cursor.fetchall()}
        
                results = []
                for c in search_results:
                    data = {'id': c['id'], 'label': c['label'], 'sort_title': get_sort_title(c['label']),
                            'info': c['info'], 'exists': False}
                    if c['id'] in existing:
                        data['label'] = existing[c['id']]['label']
                        data['sort_title'] = existing[c['id']]['sort_title']
                        data['info'] = existing[c['id']]['info']
                        data['exists'] = True
            
                    results.append(data)
                results.sort(key=lambda k: k['sort_title'])
                
                pre = -1
                if prev_id:
                    for j in range(len(results)):
                        if results[j]['id'] == prev_id:
                            pre = j
                            break
        
                list_items = []
                for r in results:
                    if r['exists']:
                        list_item = ListItem('[COLOR tomato](Edit)[/COLOR] %s' % r['label'])
                    else:
                        list_item = ListItem(r['label'])
                    list_item.setProperty('info', r['info'])
                    list_items.append(list_item)
        
                i = dlg.detail_menu(heading, list_items, False, pre, 'info_select')
                if i < 0:
                    kodi_refresh()
                    break
                if results[i]['exists']:
                    self.edit_entry(results[i]['id'])
                else:
                    self.__insert_or_update(results[i]['id'], session)
                prev_id = results[i]['id']
        
    def imdb_add_person_credits(self, person):
        from apis.armani_imdb_api import imdb_get_person_credits
        person_credits = imdb_get_person_credits(person)
        self.__modify_search_results('%s: Add Credits' % person['name'].upper(), person_credits)
        
    def imdb_find(self, params):
        action = params.get('action')
        value = params.get('value')
        if action == 'title':
            self.imdb_find_title(value or '')
        elif action == 'person':
            return self.imdb_add_person_credits(self.get_person(value))
        else:
            self.imdb_find_advanced()
                
    def imdb_find_advanced(self):
        from apis.armani_imdb_api import imdb_find_advanced
        while 1:
            results = imdb_find_advanced({})
            if results is None:
                return
            self.__modify_search_results('Search Results', results)
        
    def imdb_find_title(self, default=""):
        from apis.armani_imdb_api import imdb_title_search
        results = imdb_title_search(default)
        if results is None:
            return
        self.__modify_search_results('Search Results', results)
                
    def get_person(self, person_id):
        self.cursor.execute('SELECT imdb_id, name, known_for, jobs FROM people WHERE imdb_id = ?', (person_id,))
        p = self.cursor.fetchone()
        return None if not p else {'id': p[0], 'name': p[1], 'known_for': p[2], 'jobs': p[3]}
        
    def get_people(self):
        self.cursor.execute('SELECT imdb_id, name, known_for, jobs FROM people ORDER BY name')
        return [{'id': p[0], 'name': p[1], 'known_for': p[2], 'jobs': p[3]} for p in self.cursor.fetchall()]
                
    def __download_default_database(self):
        from xbmcvfs import delete
        
        response = requests.get(GIT['database'], headers=GIT_HEADERS)
        if response.status_code != 200:
            logger(ARMANI_STR, 'Failed to download database from GitHub')
            notification('Failed to download database')
            return False
        
        self.conn.close()
        delete(MEDIA_DB)
        
        with open(MEDIA_DB, 'wb') as out_file:
            out_file.write(response.content)
            
        self.conn = sqlite3.connect(MEDIA_DB)
        self.cursor = self.conn.cursor()
        logger(ARMANI_STR, 'Downloaded database')
        notification('Download successful')
        return True
    
    def get_imdb_ids(self):
        self.cursor.execute('SELECT imdb_id FROM media ORDER BY sort_title, release_date')
        return [r[0] for r in self.cursor.fetchall()]
        
    def update_episodes(self, imdb_id):
        self.cursor.execute('SELECT tmdb_id, status, extra_info FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return
        tmdb_id = result[0]
        status = result[1]
        extra_info = json.loads(result[2])
        starting_season = extra_info['num_seasons']
        
        tmdb_details = _get_tmdb('tv/%d?language=en-US' % tmdb_id)
        if not tmdb_details:
            return
    
        # Details from TMDb data
        status = tmdb_details['status']
    
        extra_info['num_seasons'] = tmdb_details['number_of_seasons']
        extra_info['num_episodes'] = tmdb_details['number_of_episodes']
        extra_info['episodes'] = extra_info['episodes']
        for season in range(starting_season, tmdb_details['number_of_seasons'] + 1):
            season_data = _get_tmdb('tv/%d/season/%d?language=en-US"' % (tmdb_id, season))
            extra_info['episodes'][str(season)] = {
                str(e['episode_number']): {
                    'release_date': e['air_date'],
                    'title': e['name'],
                    'plot': truncate_complete_sentences(e['overview']),
                    'runtime': e['runtime']
                } for e in season_data['episodes']
            }
        self.cursor.execute('UPDATE media SET status = ?, extra_info = ? '
                            'WHERE db_type = ? AND tmdb_id = ?', (status, json.dumps(extra_info),
                                                                  'tvshow', tmdb_id))
        self.conn.commit()
        kodi_refresh()
        notification('Success!')
    
    def __insert_or_update(self, imdb_id: str, session=None, title: str = None, sort_title: str = None, genre_ids=None):
        from modules.kodi_utils import notification
        from modules.armani_utils import get_sort_title, current_date
        from apis.armani_imdb_api import IMDB_GENRES
        countries = self.get_countries()
        languages = self.get_languages()
    
        def _error(msg):
            prog.close()
            notification('Error: %s' % imdb_id)
            logger('ArmaniFlix / add_entry[%s]' % imdb_id, str(msg))
        
        if not session:
            session = requests.Session()
            
        prog = DialogProgressBG()
        prog.create('Downloading metadata')
        
        self.cursor.execute('SELECT date_added FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        date_added = result[0] if result else current_date()
        self.insert_label = 'Updated [COLOR yellow]%s (%d)[/COLOR]' if result else 'Added [COLOR yellow]%s (%d)[/COLOR]'

        prog.update(25)
    
        # Get IMDb data
        try:
            response = session.get('https://www.imdb.com/title/%s' % imdb_id, headers=IMDB_HEADERS, timeout=5)
        except requests.exceptions.Timeout:
            _error('Unable to retrieve IMDb details')
            return False
        if response.status_code != 200:
            _error('Unable to retrieve IMDb details')
            return False
        
        try:
            json_text = response.text.split('{"props":{"pageProps":')[1].split(',"__N_SSP"')[0]
        except IndexError:
            _error('Unable to parse IMDb page')
            return False
            
        imdb_data = json.loads(json_text)
        basic_data = imdb_data['aboveTheFoldData']
        main_data = imdb_data['mainColumnData']
        
        try:
            cast_ids = [c['node']['name']['id'] for c in main_data['cast']['edges']][0:10]
            crew_ids = []
            if main_data['directors']:
                crew_ids = [c['name']['id'] for c in main_data['directors'][0]['credits']]
            if main_data['writers']:
                crew_ids += [c['name']['id'] for c in main_data['writers'][0]['credits']]
            
            # Details from IMDb data
            if not title:
                title = basic_data['titleText']['text']
            if not sort_title:
                sort_title = get_sort_title(title)
            alpha = sort_title[0] if sort_title[0].isalpha() else '#'
            if not genre_ids:
                genre_ids = [IMDB_GENRES[g['text']] for g in basic_data['genres']['genres']]
        
            db_type = 'movie' if basic_data['titleType']['id'] in ('movie', 'tvMovie', 'short') else 'tvshow'
            media_type = 'movie' if db_type == 'movie' else 'tv'
            imdb_rating = basic_data['ratingsSummary']['aggregateRating']
            imdb_votes = basic_data['ratingsSummary']['voteCount']
            plot = truncate_complete_sentences(basic_data['plot']['plotText']['plainText'])
        except Exception as e:
            _error(str(e))
            return False

        prog.update(50)
        # Get tmdb data
        tmdb_details, tmdb_release_dates, tmdb_credits, tmdb_ratings = None, None, None, None
        try:
            
            tmdb_find = _get_tmdb('find/%s?external_source=imdb_id' % imdb_id)
            found = tmdb_find.get('movie_results') if db_type == 'movie' else tmdb_find.get('tv_results')
            if not found:
                _error('TMDB ID not found')
                return False
            tmdb_id = found[0]['id']

            tmdb_details = _get_tmdb('%s/%d?language=en-US' % (media_type, tmdb_id))
            if db_type == 'movie':
                tmdb_credits = _get_tmdb('movie/%d/credits' % tmdb_id)
                tmdb_release_dates = _get_tmdb('movie/%s/release_dates' % tmdb_id)['results']
            else:
                tmdb_credits = _get_tmdb('tv/%d/aggregate_credits' % tmdb_id)
                tmdb_ratings = _get_tmdb('tv/%s/content_ratings' % tmdb_id)['results']

            # Details from TMDb data
            original_language = languages[tmdb_details['original_language']]
            status = tmdb_details['status']
            extra_info = {
                'countries': ''
            }

            # Movie details from TMDb data
            director_jobs = ('director', 'directed by')
            writer_jobs = ('author', 'book', 'comic book', 'graphic novel', 'novel', 'original story', 'screenplay',
                           'screenplay by', 'short story', 'story', 'story by', 'writer', 'written by')

            prog.update(75)
            
            if db_type == 'movie':
                # Movie credits
                cast = tmdb_credits['cast']
                crew = sorted(tmdb_credits['crew'], key=lambda d: d['popularity'], reverse=True)
                directors = [p for p in crew if p['job'].lower() in director_jobs]
                creators = []
                writers = [p for p in crew if p['job'].lower() in writer_jobs]

                release_dates = []
                for d in tmdb_release_dates:
                    release_dates.extend([rd['release_date'][:10] for rd in d['release_dates']])
                release_date = min(release_dates)
                runtime = tmdb_details['runtime']

                release_dates = {r['iso_3166_1']: r['release_dates'] for r in tmdb_release_dates}
                if 'US' not in release_dates:
                    mpaa = 'NR'
                else:
                    mpaa_list = [r['certification'] for r in release_dates['US'] if r['certification']]
                    mpaa = 'NR' if not mpaa_list else mpaa_list[0]

                extra_info['countries'] = [c['name'] for c in tmdb_details['production_countries']]

            # TV details from TMDb data
            else:
                # TV credits
                cast = sorted(tmdb_credits['cast'], key=lambda d: d['total_episode_count'], reverse=True)
                cast = [c for c in cast if c['order'] < 8]
                for c in cast:
                    c['character'] = sorted(c['roles'], key=lambda d: d['episode_count'], reverse=True)[0][
                        'character']
                creators = [{'id': c['id'], 'name': c['name']} for c in tmdb_details.get('created_by', [])]
                directors = []
                writers = []
                for c in tmdb_credits['crew']:
                    for j in c['jobs']:
                        if j['job'].lower() in director_jobs:
                            directors.append(
                                {'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
                        elif j['job'].lower() in writer_jobs:
                            writers.append({'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
                directors = [{'id': p['id'], 'name': p['name']}
                             for p in sorted(directors, key=lambda d: d['episode_count'], reverse=True)][0:2]
                writers = [{'id': p['id'], 'name': p['name']}
                           for p in sorted(writers, key=lambda d: d['episode_count'], reverse=True)][0:2]

                release_date = tmdb_details['first_air_date']
                if tmdb_details['episode_run_time']:
                    runtime = tmdb_details['episode_run_time'][0]
                else:
                    episode_details = _get_tmdb('tv/%s/season/1/episode/1?language=en-US' % tmdb_id)
                    runtime = episode_details['runtime'] or 0

                certs = {r['iso_3166_1']: r['rating'] for r in tmdb_ratings if r['rating']}
                mpaa = 'NR' if 'US' not in certs else certs['US']
                extra_info['countries'] = [countries[c] for c in tmdb_details['origin_country']]
                extra_info['num_seasons'] = tmdb_details['number_of_seasons']
                extra_info['num_episodes'] = tmdb_details['number_of_episodes']
                extra_info['episodes'] = {}
                for season in range(1, tmdb_details['number_of_seasons'] + 1):
                    season_data = _get_tmdb('tv/%d/season/%d?language=en-US"' % (tmdb_id, season))
                    extra_info['episodes'][str(season)] = {
                        str(e['episode_number']): {
                            'release_date': e['air_date'],
                            'title': e['name'],
                            'plot': truncate_complete_sentences(e['overview']),
                            'runtime': e['runtime']
                        } for e in season_data['episodes']
                    }

            # Finalize credits
            cast = [{'id': p['id'], 'name': p['name'], 'role': p['character'], 'order': p['order']} for p in cast]
            director = [{'id': p['id'], 'name': p['name']} for p in directors]
            writer = [{'id': p['id'], 'name': p['name']} for p in writers]
            cast = list({p['id']: p for p in cast}.values())
            cast = sorted(cast, key=lambda d: d['order'])
            director = list({p['id']: p for p in director}.values())
            writer = list({p['id']: p for p in writer}.values())
            all_credits = {
                'director': director[0:2],
                'creator': creators[0:2],
                'writer': writer[0:2],
                'cast': cast[0:8]
            }

            creator = [p['name'] for p in all_credits.get('creator', [])]
            director = [p['name'] for p in all_credits.get('director', [])]
            writer = [p['name'] for p in all_credits.get('writer', [])]
            cast = [p['name'] for p in all_credits.get('cast', [])]

            credit_lines = []
            credit_string = '[B]%s:[/B] %s'
            if creator:
                credit_lines.append(credit_string % ('Creator', ', '.join(creator)))
            elif director:
                credit_lines.append(credit_string % ('Director', ', '.join(director)))
            if cast:
                credit_lines.append(credit_string % ('Stars', ', '.join(cast[0:3])))
            main_credits = '[CR]'.join(credit_lines)
            
            search_title = _search_string(title)
            release_year = int(release_date[:4])
            release_decade = 10 * int(release_year / 10)

            prog.update(100)
            self.cursor.execute("""
                   INSERT OR REPLACE INTO media (
                       imdb_id, db_type, tmdb_id, title, sort_title, starting_letter, plot, main_credits, genre_ids,
                       mpaa, original_language, release_date, year, decade, runtime, rating, votes,
                       search_string, extra_info, status, date_added, date_updated, cast_ids, crew_ids
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               """, (imdb_id, db_type, tmdb_id, title, sort_title, alpha, plot, main_credits, ','.join(genre_ids),
                     mpaa, original_language, release_date, release_year, release_decade, runtime, imdb_rating,
                     imdb_votes, search_title, json.dumps(extra_info), status, date_added, current_date(),
                     ','.join('<%s>' % i for i in cast_ids), ','.join('<%s>' % i for i in crew_ids))
            )
            self.conn.commit()
            prog.close()
    
        except Exception as e:
            _error(str(e))
            return False
    
        self.insert_label = self.insert_label % (title, release_year)
        return True
    
    def delete_entry(self, imdb_id, confirm=True):
        self.cursor.execute('SELECT title || " (" || year || ")" FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return False
        if confirm and not Dialog().yesno(
                'Confirm Deletion',
                'Are you certain you want to remove [COLOR yellow]%s[/COLOR] from the media database?' % result[0]):
            return False
        
        self.cursor.execute('DELETE FROM media WHERE imdb_id = ?', (imdb_id,))
        self.conn.commit()
        self.conn.execute('VACUUM')
        notification('Deleted %s' % imdb_id)
        return True
    
    def edit_all(self, params=None):
        from xbmcgui import ListItem
        from modules.armani_utils import ArmaniDialog
        
        def _label(_row):
            if 'db_type' in where:
                return '[COLOR white]%s [LIGHT](%d)[/LIGHT][/COLOR]' % (_row[2], _row[4])
            return '[COLOR white]%s / %s [LIGHT](%d)[/LIGHT][/COLOR]' % (_row[1], _row[2], _row[4])
            
        if params is None:
            params = {}
        where = params.get('where', '')
        header = params.get('title', 'Edit All Titles')
        
        dlg = ArmaniDialog()
        
        all_genres = self.get_genres()
        info_string = '[COLOR cyan][B][UPPERCASE]%s[/UPPERCASE][/B] (%d)[/COLOR][CR][CR]'
        info_string += '[COLOR yellow][B]Sort Title[/B][/COLOR][CR][COLOR lightyellow]%s[/COLOR][CR][CR]'
        info_string += '[COLOR yellow][B]Genres[/B][CR][/COLOR][COLOR lightyellow]%s[/COLOR]'
        title_index = -1
        while 1:
            self.cursor.execute('SELECT imdb_id, db_type, title, sort_title, year, genre_ids '
                                'FROM media %s ORDER BY sort_title, release_date' % where)
            results = self.cursor.fetchall()
            if not results:
                break
            
            results = [{
                'imdb_id': r[0], 'label': _label(r),
                'info': info_string % (r[2], r[4], r[3], ' | '.join([all_genres[g.strip()] for g in r[5].split(',')]))}
                for r in results]
    
            list_items = []
            for r in results:
                item = ListItem(r['label'])
                item.setProperty('info', r['info'])
                list_items.append(item)

            title_index = dlg.detail_menu(header, list_items, False, title_index, 'info_select')
            if title_index < 0:
                break
            self.edit_entry(results[title_index]['imdb_id'])

    def edit_entry(self, imdb_id):
        """ Modify metadata (optional) and updates rating and status of the specified entry. """
        from modules.armani_utils import current_date, ArmaniDialog
        from xbmc import executebuiltin
        from xbmcgui import ListItem
        
        dlg = ArmaniDialog()

        self.cursor.execute('SELECT title, sort_title, genre_ids, year FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return
        
        all_genres = self.get_genres()
        title = result[0]
        sort_title = result[1]
        year = result[3]
        genre_ids = [g.strip() for g in result[2].split(',')]
        
        genre_list = [{'id': k, 'name': v} for k, v in all_genres.items()]
        
        all_genre_ids = list(all_genres.keys())
        all_genre_names = list(all_genres.values())
        
        while 1:
            title_year = '%s (%d)' % (title, year)
            options = [ListItem('Title', title),
                       ListItem('Sort Title', sort_title),
                       ListItem('Genres', ', '.join([all_genres[g] for g in genre_ids])),
                       ListItem('[COLOR springgreen]SAVE[/COLOR]', '[I]Save title, sort title, and genres[/I]'),
                       ListItem('[COLOR yellow]UPDATE[/COLOR]', '[I]Refresh metadata (e.g., IMDb rating)[/I]'),
                       ListItem('[COLOR red]DELETE[/COLOR]', '[I]Remove entry from the database[/I]')]
            sel = dlg.detail_menu(title_year, options, True, menu_type='meta_edit')
            if sel < 0:
                return
            if sel == 0:
                t = dlg.dialog.input('New Title', title).strip()
                if t:
                    title = t
            elif sel == 1:
                t = dlg.dialog.input('New Sort Title', sort_title).strip().upper()
                if t:
                    sort_title = t
            elif sel == 2:
                pre = [all_genre_ids.index(g) for g in genre_ids]
                sel = dlg.genre_menu('Genres', all_genre_names, pre, True)
                if sel:
                    genre_ids = [genre_list[i]['id'] for i in sel]
                    if 'sho' in genre_ids:
                        genre_ids.remove('sho')
                        genre_ids.insert(0, 'sho')
                    if 'sil' in genre_ids:
                        genre_ids.remove('sil')
                        genre_ids.insert(0, 'sil')
            elif sel == 3:
                break
            elif sel == 4:
                self.update_metadata(imdb_id)
            elif sel == 5:
                if self.delete_entry(imdb_id):
                    executebuiltin('Control.Move(50,1)')
                    kodi_refresh()
                    return
        
        alpha = sort_title[0] if sort_title[0].isalpha() else '#'
        
        self.cursor.execute(
            'UPDATE media SET title = ?, sort_title = ?, starting_letter = ?, genre_ids = ?, '
            'search_string = ?, date_updated = ? WHERE imdb_id = ?',
            (title, sort_title, alpha, ','.join(genre_ids), _search_string(title), current_date(), imdb_id))
        self.conn.commit()
        kodi_refresh()
        notification('Success!')
            
    def update_metadata(self, imdb_id, silent=False):
        self.cursor.execute('SELECT title, sort_title, genre_ids FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return
        title, sort_title, genre_ids = result
        genre_ids = [g.strip() for g in genre_ids.split(',')]
        if not self.__insert_or_update(imdb_id, title=title, sort_title=sort_title, genre_ids=genre_ids):
            return
        if not silent:
            notification('Updated metadata')
    
    def get_meta_list(self, where="", where_values=None, sort_order='sort_title, release_date', limit:int = 0):
        if limit > 0:
            sort_order += ' LIMIT %d' % limit
        if where_values is None:
            where_values = ()

        all_genres = self.get_genres()
        
        try:
            self.cursor.execute(f"""
                SELECT
                    imdb_id, db_type, tmdb_id, title, sort_title, starting_letter, plot, main_credits, genre_ids, mpaa,
                    original_language, release_date, year, decade, runtime, rating, votes,
                    search_string, extra_info, status, date_added, date_updated
                FROM
                    media
                {where}
                ORDER BY
                    {sort_order}
            """, where_values)
        except sqlite3.Error:
            return []
        
        meta = []
        for row in self.cursor.fetchall():
            
            extra_info = json.loads(row[18])
            
            meta.append({
                'imdb_id': row[0],
                'db_type': row[1],
                'media_type': row[1],
                'tmdb_id': row[2],
                'original_title': row[3],
                'title': row[3] if row[10] == 'English' else '%s [COLOR grey][%s][/COLOR]' % (row[3], row[10]),
                'rootname': '%s (%d)' % (row[3], row[12]),
                'sort_title': row[4],
                'starting_letter': row[5],
                'plot': row[6] + '[CR][CR]' + row[7],
                'genre_ids': row[8],
                'mpaa': row[9],
                'original_language': row[10],
                'premiered': row[11],
                'year': str(row[12]),
                'decade': row[13],
                'duration': row[14],
                'rating': row[15],
                'votes': row[16],
                'search_string': row[17],
                'genre': ', '.join(all_genres[g.strip()] for g in row[8].split(',') if g.strip() in all_genres),
                'country': extra_info['countries'],
                'total_seasons': extra_info.get('num_seasons', 0),
                'total_aired_eps': extra_info.get('num_episodes', 0),
                'episodes': extra_info.get('episodes'),
                'status': row[19],
                'date_added': row[20],
                'date_modified': row[21],
                'cast': '',
                'director': '',
                'writer': '',
                'keywords': '',
            })
        return meta

    def fetch(self, params, limit=None):
        db_types = params.get('db_types', 'movie, tvshow')
        values = [t.strip().lower() for t in db_types.split(',')]
        where = '(%s)' % ' OR '.join(['db_type = ?'] * len(values))
        
        if 'names' in params:
            # Title must include all names
            names = [_search_string(n.strip()) for n in params['names'].split(',')]
            logger('NAMES', str(names))
            people_ids = ['"%<' + p['id'] + '>%"' for p in self.get_people()
                          if any(n in _search_string(p['name']) for n in names)]
            logger('IDS', str(people_ids))
            people_where = ' OR '.join('cast_ids LIKE %s OR crew_ids LIKE %s' % (i, i)
                                       for i in people_ids)
            logger('WHERE', people_where)
            where += ' AND (%s)' % people_where
        
        if 'years' in params:
            years = params['years'].split('-', maxsplit=1)
            if len(years) == 1:
                year_where = '(year = ?)'
                year_values = [int(years)]
            else:
                year_where = "(year >= ? AND year <= ?)"
                year_values = [int(years[0]), int(years[1])]
        
            values += year_values
            where += ' AND %s' % year_where
    
        if 'alpha' in params:
            values += [params['alpha'].upper()]
            where += ' AND starting_letter = ?'
    
        if 'genres' in params:
            genre_ids = params['genres'].split(',')
            values += ['%' + g.strip() + '%' for g in genre_ids]
            where += ' AND %s' % ' AND '.join(['genre_ids LIKE ?']*len(genre_ids))
    
        if 'query' in params:
            queries = params['query'].split(',')
            values += ['%' + _search_string(q.strip()) + '%' for q in queries]
            where += ' AND (%s)' % ' OR '.join(['search_string LIKE ?']*len(queries))
    
        sort_order = params.get('sort_order', 'sort_title, release_date')
        if 'limit' not in sort_order.lower():
            sort_order += ' LIMIT %d' % (limit or FETCH_LIMIT)
        return self.get_meta_list('WHERE %s' % where, values, sort_order)

    def can_fetch(self, params):
        return len(self.fetch(params, 1)) > 0
    
    def get_meta_tmdb(self, db_type, tmdb_id):
        results = self.get_meta_list('WHERE db_type = ? AND tmdb_id = ?', (db_type, tmdb_id))
        return {} if not results else results[0]
    
    def get_meta_imdb(self, imdb_id):
        results = self.get_meta_list('WHERE imdb_id = ?', (imdb_id,))
        return {} if not results else results[0]
    
    def get_meta_action(self, action):
        from caches.armani_users import ArmaniUsers
        from modules.watched_status import armani_get_watch_history
        armani_users = ArmaniUsers()
        
        results = []
        if action == 'favorites':
            imdb_ids = armani_users.get_favorites()
            where = 'WHERE imdb_id IN (%s)' % ', '.join(['?'] * len(imdb_ids))
            results = self.get_meta_list(where, imdb_ids)
        elif action == 'watched':
            results = [self.get_meta_tmdb(r[1], r[0]) for r in armani_get_watch_history()]
        elif action == 'playlist':
            results = self.get_meta_playlist()
        elif action == 'advanced':
            results = self.get_meta_list(self.settings.get_json('advanced_search')['where'])
        
        return [r for r in results if r]
    
    def get_meta_playlist(self):
        from modules.watched_status import armani_remove_watched, armani_remove_unwatched
        from caches.armani_users import ArmaniPlaylist
        playlist = ArmaniPlaylist().get_playlist()
        media_types = playlist.get('media_types') or ['movie']
        watched_status = playlist.get('watched_status') or ['unwatched', 'watched']

        filters = []
        values = []
        filters.append('db_type IN (%s)' % ', '.join(['?'] * len(media_types)))
        values.extend(media_types)
        
        if playlist.get('genres_all'):
            filters.append(' AND '.join(['genre_ids LIKE ?'] * len(playlist['genres_all'])))
            values.extend(['%' + g + '%' for g in playlist['genres_all']])
        if playlist.get('genres_any'):
            filters.append(' OR '.join(['genre_ids LIKE ?'] * len(playlist['genres_any'])))
            values.extend(['%' + g + '%' for g in playlist['genres_any']])
        if playlist.get('genres_none'):
            filters.append(' AND '.join(['genre_ids NOT LIKE ?'] * len(playlist['genres_none'])))
            values.extend(['%' + g + '%' for g in playlist['genres_none']])
        if playlist.get('decades'):
            filters.append(' OR '.join(['(year >= ? AND year <= ?)'] * len(playlist['decades'])))
            for d in playlist['decades']:
                values.extend([int(d), int(d) + 9])
        if playlist.get('languages'):
            filters.append(' OR '.join(['original_language = ?'] * len(playlist['languages'])))
            values.extend(playlist['languages'])
        if playlist.get('search_any'):
            filters.append(' OR '.join(['search_string LIKE ?'] * len(playlist['search_any'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_any']])
        if playlist.get('search_all'):
            filters.append(' AND '.join(['search_string LIKE ?'] * len(playlist['search_all'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_all']])
        if playlist.get('search_none'):
            filters.append(' AND '.join(['search_string NOT LIKE ?'] * len(playlist['search_none'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_none']])

        s_filter = '' if not filters else 'WHERE %s' % ' AND '.join('(%s)' % f for f in filters)
        order = SIZE_FILTERS[playlist.get('size_filter', 'votes_desc')]['order']
        
        results = self.get_meta_list(s_filter, values, order)
        
        if 'unwatched' not in watched_status:
            results = armani_remove_unwatched(results)
        elif 'watched' not in watched_status:
            results = armani_remove_watched(results)
        else:
            results = armani_remove_watched(results, playlist['created'])

        results = results[0:PLAYLIST_LIMIT]
        results.sort(key=lambda x: x['premiered'])
        results.sort(key=lambda x: x['sort_title'])
        return results
    
    
armani = ArmaniCache()
