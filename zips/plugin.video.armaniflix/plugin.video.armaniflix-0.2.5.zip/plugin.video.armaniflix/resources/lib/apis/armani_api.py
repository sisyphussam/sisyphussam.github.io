from caches.main_cache import cache_object
from modules.kodi_utils import json, current_window_id, local_string as ls, logger
from caches.armani_cache import armani
from caches.armani_users import ArmaniUsers as A

EXPIRY_ONE_DAY = 24
EXPIRY_ONE_YEAR = 8760

ARMANI_TITLES = {
    'build_season_list': ls(33501) % ls(32636),
    'build_episode_list': ls(33501) % ls(32506)
}


def armani_set_window_title(params):
    action = params.get('action', '')
    mode = params.get('mode', '')
    
    if 'armani_title' in params:
        current_window_id().setProperty('armani_title', params.get('armani_title'))
        return
    
    if mode == 'armani_admin':
        return
    
    if action == 'playlist':
        current_window_id().setProperty('armani_title', ls(33624) % A().get_current_user()['user_name'])
        return
    
    if mode in ('empty_click', 'armani_users'):
        return
    
    if mode.startswith('playlist_') or mode.startswith('navigator.playlist_'):
        return
        
    if mode == 'armani_list':
        current_window_id().setProperty('armani_title', armani.get_header(action))
        return
    
    if mode == 'build_armani_list':
        current_window_id().setProperty('armani_title', armani.get_header(action, params.get('value')))
        return
    
    if mode == 'build_armani_contents':
        title = ls(33500) if params.get('category', '') == 'movies' else ls(33501)
        if params.get('key', '') == 'top_rated':
            title = title % ls(33514)
        current_window_id().setProperty('armani_title', title)
        return

    if mode == 'build_armani_results':
        current_window_id().setProperty('armani_title', ls(33503) % params.get("title"))
        return
    
    if mode == 'build_movie_list' and action == 'tmdb_movies_sets':
        from modules.metadata import movieset_meta
        from modules.settings import metadata_user_info
        meta = movieset_meta(params.get('tmdb_id'), metadata_user_info())
        current_window_id().setProperty('armani_title', meta['title'])
        return
    
    if mode in ARMANI_TITLES:
        current_window_id().setProperty('armani_title', ARMANI_TITLES[mode])
        return
    
    if mode in ('options_menu_choice', 'playback.media'):
        return
    
    current_window_id().clearProperty('armani_title')


def armani_list(action):
    return list(armani.get_list(action).values())


def armani_list_contents(params):
    return armani.get_content(params)


def armani_person_credits(person_id):
    from apis.tmdb_api import tmdb_people_full_info
    info = ""
    try:
        person_info = tmdb_people_full_info(person_id)
        known_for = person_info.get('known_for_department', '')

        combined_credits = person_info.get('combined_credits', {})

        relevant_credits = []
        if known_for == 'Writing':
            relevant_credits = [c for c in combined_credits['crew'] if c.get('department') == 'Writing']
        elif known_for == 'Directing':
            relevant_credits = [c for c in combined_credits['crew'] if
                                c.get('department') in ('Writing', 'Directing', 'Creator')]
        elif known_for == 'Acting':
            relevant_credits = [c for c in combined_credits['crew'] if c.get('department') == 'Directing']
            relevant_credits += [c for c in combined_credits['cast'] if
                                 c.get('media_type') != 'tv' or c.get('episode_count', 0) > 5]

        unsorted_credits = {}
        for c in relevant_credits:
            if c.get('vote_count', 0) < 100 or c.get('vote_average', 0) < 6:
                continue
            if 'id' not in c or 'media_type' not in c:
                continue
            d = c.get('release_date') if 'release_date' in c else c.get('first_air_date')
            if not d:
                continue

            tmdb_id = str(c['id'])
            db_type = 'tvshow' if c['media_type'] == 'tv' else 'movie'
            sort_title = c.get('name') if c['media_type'] == 'tv' else c['title']
            articles = ('The ', 'A ', 'An ')
            for a in articles:
                if sort_title.startswith(a):
                    sort_title = sort_title[len(a):]
                    break
            sort_key = f"{sort_title}"
            unsorted_credits[sort_key] = (tmdb_id, db_type)

        credit_keys = list(unsorted_credits.keys())
        credit_keys.sort()
        credits = [unsorted_credits[i] for i in credit_keys]

    except:
        credits = []
        logger('CREDIT ERROR', str(person_id))

    return credits


def _get_sort_title(title, release_date):
    sort_title = "".join(ch for ch in title if ch.isalnum() or ch == ' ')

    articles = ['The ', 'A ', 'An ']
    for article in articles:
        if title.startswith(article):
            sort_title = title[len(article):]
            break

    if release_date: sort_title += ' (' + release_date + ')'
    return sort_title


def clear_armani_cache(silent=False):
    from modules.kodi_utils import path_exists, clear_property, database, maincache_db
    try:
        if not path_exists(maincache_db): return True
        dbcon = database.connect(maincache_db, timeout=40.0, isolation_level=None)
        dbcur = dbcon.cursor()
        dbcur.execute('''PRAGMA synchronous = OFF''')
        dbcur.execute('''PRAGMA journal_mode = OFF''')
        dbcur.execute("SELECT id FROM maincache WHERE id LIKE ?", ('armani_%',))
        imdb_results = [str(i[0]) for i in dbcur.fetchall()]
        if not imdb_results: return True
        dbcur.execute("DELETE FROM maincache WHERE id LIKE ?", ('armani_%',))
        for i in imdb_results: clear_property(i)
        return True
    except:
        return False
