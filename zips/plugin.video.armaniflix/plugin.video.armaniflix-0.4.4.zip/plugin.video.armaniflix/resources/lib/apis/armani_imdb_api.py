import requests
import json
import re
from modules.kodi_utils import notification, logger
from xbmcgui import Dialog, DialogProgress
from modules.armani_utils import get_sort_title, get_file_path, get_search_string
from time import sleep
from random import randint
from datetime import datetime


TODAY = datetime.today()

IMDB_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "DNT": "1",
                "Connection": "close",
                "Upgrade-Insecure-Requests": "1"}

IMDB_URL_ADVANCED_BASE = 'https://www.imdb.com/search/title/?sort=num_votes,desc&country_of_origin=!IN,!TR,!PK&'
IMDB_URL_PERSON_FIND = 'https://www.imdb.com/find/?s=nm&q=%s'
DEFAULT_TITLE_TYPE = 'title_type=feature,short,tv_series,tv_miniseries,tv_movie'

GENRE_MAP = {
    'act': 'Action',
    'adu': 'Adult',
    'adv': 'Adventure',
    'ani': 'Animation',
    'bio': 'Biography',
    'com': 'Comedy',
    'cri': 'Crime',
    'doc': 'Documentary',
    'dra': 'Drama',
    'fam': 'Family',
    'fan': 'Fantasy',
    'fil': 'Film-Noir',
    'gam': 'Game-Show',
    'his': 'History',
    'hor': 'Horror',
    'muc': 'Music',
    'mus': 'Musical',
    'mys': 'Mystery',
    'news': 'News',
    'rea': 'Reality-TV',
    'rom': 'Romance',
    'sci': 'Sci-Fi',
    'sho': 'Short',
    'spo': 'Sport',
    'tal': 'Talk-Show',
    'thr': 'Thriller',
    'war': 'War',
    'wes': 'Western'
}

KEYWORD_MAP = {
    'sil': 'silent-film',
    'sup': 'superhero',
    'sur': 'surrealism'
}

KEYWORDS = {
    'action-hero': 'Action Hero',
    'alien': 'Aliens',
    'anime': 'Anime',
    'child-protagonist': 'Children',
    'dark-comedy': 'Dark Comedy',
    'dystopia': 'Dystopian',
    'high-school': 'High School',
    'monster': 'Monsters',
    'official-bond-film': 'James Bond',
    'neo-noir': 'Neo Noir',
    'silent-film': 'Silent Film',
    'slasher': 'Slasher',
    'superhero': 'Superhero',
    'surrealism': 'Surrealism',
    'teenage-protagonist': 'Teenagers',
    'based-on-true-story': 'True Story',
    'vampire': 'Vampires',
    'werewolf': 'Werewolves',
    'zombie': 'Zombies'
}

IMDB_GENRES = {
    'Action': 'act', 'Adult': 'adu', 'Adventure': 'adv', 'Animation': 'ani', 'Biography': 'bio',
    'Comedy': 'com', 'Crime': 'cri', 'Documentary': 'doc', 'Drama': 'dra', 'Family': 'fam',
    'Fantasy': 'fan', 'Film-Noir': 'fil', 'Game-Show': 'gam', 'History': 'his', 'Horror': 'hor',
    'Music': 'muc', 'Musical': 'mus', 'Mystery': 'mys', 'News': 'new', 'Reality-TV': 'rea',
    'Romance': 'rom', 'Sci-Fi': 'sci', 'Short': 'sho', 'Sport': 'spo', 'Talk-Show': 'tal',
    'Thriller': 'thr', 'War': 'war', 'Western': 'wes'
}

IMDB_ADVANCED_LANGUAGES = [
    ('Any', ''),
    ('English', 'primary_language=en'),
    ('Foreign', 'primary_language=!en'),
    ('Arabic', 'primary_language=ar'),
    ('Chinese', 'primary_language=zh,yue,cmn'),
    ('Danish', 'primary_language=da'),
    ('French', 'primary_language=fr'),
    ('German', 'primary_language=de'),
    ('Italian', 'primary_language=it'),
    ('Japanese', 'primary_language=ja'),
    ('Korean', 'primary_language=ko'),
    ('Norwegian', 'primary_language=no'),
    ('Persian', 'primary_language=fa'),
    ('Portuguese', 'primary_language=pt'),
    ('Russian', 'primary_language=ru'),
    ('Spanish', 'primary_language=es'),
    ('Swedish', 'primary_language=sv')
]

IMDB_SEARCH_FILTER = get_file_path('imdb/search_filter.json')
IMDB_CUSTOM = get_file_path('imdb/custom_values.json')
IMDB_LISTS = get_file_path('imdb/lists.json')
IMDB_USER_ID = 'ur163156999'


def check():
    from xbmcvfs import mkdir, exists
    imdb_path = get_file_path('imdb/')
    if not exists(imdb_path):
        mkdir(imdb_path)
        
        
def imdb_person_info(person_id, session=None) -> dict:
    notification('Fetching info', 1000)
    url = 'https://www.imdb.com/name/%s/' % person_id
    _text = get_imdb_text(url, session)
    if not _text:
        return {}
    try:
        _text = _text.split('"aboveTheFold":')[1].split(',"mainColumnData"', maxsplit=1)[0]
    except IndexError:
        return {}
    
    data = json.loads(_text)
    name = data['nameText']['text']
    known_for = data['knownFor']['edges'][0]['node']['title']['titleText']['text']
    main_job = data['primaryProfessions'][0]['category']['text'].lower()
    
    data = {'id': person_id, 'name': name, 'known_for': known_for, 'main_job': main_job}
    if main_job in ('actor', 'actress', 'director', 'writer'):
        data['jobs'] = main_job
    return data


def imdb_person_search() -> dict:
    """ Search IMDb for a person's name

    Returns:
        A dict containing the id, name, and "known for" title of the found person

    """
    
    def _get_matches():
        _text = get_imdb_text(url, session)
        if not _text:
            return []
        try:
            _text = _text.split('"nameResults":')[1].split(',"titleResults":')[0]
        except IndexError:
            return []
        _data = json.loads(_text)
        _data = _data['results']
        if not _data:
            return []
        
        # Remove people that don't have a "known_for" field
        _results = {}
        for _d in _data:
            try:
                _r = {'id': _d['id'], 'name': _d['displayNameText'],
                      'known_for': '%s (%s)' % (_d['knownForTitleText'], _d['knownForTitleYear'])}
                _results[_d['id']] = _r
                pass
            except KeyError:
                continue
        if not _results:
            return []
        return list(_results.values())
    
    # Get query
    dlg = Dialog()
    query = dlg.input('Find a person').strip()
    if not query:
        return {}
    
    with requests.Session() as session:
        # Check for an exact match
        url = (IMDB_URL_PERSON_FIND % query) + '&exact=True'
        matches = _get_matches()
        if matches:
            s = get_search_string(query)
            for m in matches:
                if s in get_search_string(m['name']):
                    return m
            return matches[0]
        
        notification('Searching for a partial match')
        sleep(randint(2, 3))
        
        # Check for partial match
        url = (IMDB_URL_PERSON_FIND % query)
        matches = _get_matches()
        if matches:
            return matches[0]
    
    notification('No results')
    return {}


def imdb_get_person_credits(person):
    from modules.armani_utils import dialog_detail_menu, dialog_menu
    from xbmcgui import ListItem
    job_index, type_index, vote_index, rating_index = 0, 0, 4, 3
    jobs = person['jobs'].split(',')
    title_types = [
        ('All', 'movie,tvMovie,short,tvSeries,tvMiniSeries'),
        ('Movies', 'movie,tvMovie,short'),
        ('TV Shows', 'tvSeries,tvMiniSeries')
    ]
    min_votes = ['0', '1,000', '2,500', '5,000', '10,000', '25,000', '50,000', '100,000', '250,000',
                 '500,000', '1,000,000']
    min_ratings = ['0', '5', '6', '6.5', '7', '7.5', '8', '8.5', '9']
    
    while 1:
        options = [
            ListItem('Job', jobs[job_index]),
            ListItem('Media Type', title_types[type_index][0]),
            ListItem('Min. Votes', str(min_votes[vote_index])),
            ListItem('Min. Rating', str(min_ratings[rating_index])),
            ListItem('[COLOR yellow]SEARCH[/COLOR]')
        ]
        i = dialog_detail_menu(person['name'], options, menu_type='menu5')
        if i < 0:
            return None
        if i == 0:
            if len(jobs) == 1:
                continue
            elif len(jobs) == 2:
                job_index = (job_index + 1) % len(jobs)
                continue
            j = dialog_menu('Job', jobs, job_index)
            if j > -1:
                job_index = j
        elif i == 1:
            j = dialog_menu('Media Type', [t[0] for t in title_types], type_index)
            if j > -1:
                type_index = j
        elif i == 2:
            j = dialog_menu('Min. Votes', min_votes, vote_index)
            if j > -1:
                vote_index = j
        elif i == 3:
            j = dialog_menu('Min. Rating', min_ratings, rating_index)
            if j > -1:
                rating_index = j
        else:
            return imdb_person_title_search(person['id'],
                                            jobs[job_index],
                                            title_types[type_index][1],
                                            min_ratings[rating_index],
                                            min_votes[vote_index].replace(',', ''))


def imdb_person_title_search(person_id, job_type, title_type='movie,tvMovie,short,tvSeries,tvMiniSeries',
                             min_rating='5', min_votes='5000'):
    url = 'https://www.imdb.com/filmosearch/?explore=title_type&sort=user_rating,desc&mode=detail&page=1&' \
          'role=%s&job_type=%s&title_type=%s&user_rating=%s,&num_votes=%s,'
    url = url % (person_id, job_type, title_type, min_rating, min_votes)

    text = get_imdb_text(url)
    if not text:
        return None
    text = text.replace('\n', '')
    
    rows = text.split('<div class="lister-item-content">')
    rows.pop(0)
    
    items = []
    
    for html in rows:
        html = html.split('<a href="/title/', maxsplit=1)[1]  # Go to ID
        imdb_id, html = html.split('/', maxsplit=1)
        html = html.split('>', maxsplit=1)[1]  # Go to title
        title, html = html.split('</a>', maxsplit=1)
        html = html.split('<span class="lister-item-year', maxsplit=1)[1]
        html = html.split('>', maxsplit=1)[1]  # Go to year (in brackets)
        year, html = html.split('</span>', maxsplit=1)
        title += ' ' + year
        html = html.split('<span class="genre">', maxsplit=1)[1]  # Go to genres
        genres, html = html.split('</span>', maxsplit=1)
        html = html.split('<meta itemprop="ratingValue" content="', maxsplit=1)[1]  # Go to rating
        rating, html = html.split('"', maxsplit=1)
        html = html.split('<meta itemprop="ratingCount" content="', maxsplit=1)[1]  # Go to votes
        votes, html = html.split('"', maxsplit=1)
        html = html.split('<p class="">', maxsplit=1)[1]  # Go to plot
        plot = html.split('</p>', maxsplit=1)[0].strip()
        plot = re.compile(r'<[^>]+>').sub('', plot)
        items.append(_get_item(imdb_id, title, genres, rating, votes, plot))
    items.sort(key=lambda k: k['sort_title'])
    return items


def imdb_title_search(default="", min_rating=0, min_votes=2000, pages=3):
    from xbmcgui import Dialog
    title = Dialog().input('Search for the title of a movie or show', default).strip()
    if not title:
        return None
    url_tail = 'min_rating=%.1f&title=%s' % (min_rating, title)
    return imdb_advanced_search(url_tail, pages, min_votes)


def imdb_advanced_search(url_tail: str, total_pages=3, min_votes=5000) -> list:
    """ Return advanced search results with the most votes sorted by title

    Args:
        url_tail: The URL parameters (e.g, "user_rating=8,&role=nm1010101")
        total_pages: The number of pages to parse (each contains 50 titles)
        min_votes: The minimum vote count (num_votes must not be in url_tail)

    Returns:
        Returns a list of sorted search results

    """
    if not url_tail:
        return []
    
    if 'title_type' not in url_tail:
        url_tail += '&' + DEFAULT_TITLE_TYPE
    if url_tail.startswith('&'):
        url_tail = url_tail[1:]
    url = IMDB_URL_ADVANCED_BASE + url_tail
    
    results = {}
    
    page_count = 0
    max_votes = -1
    
    prog = DialogProgress()
    h = 'Fetching list of titles...'
    prog.create('Performing search', 'Please wait...')
    while page_count < total_pages:
        if -1 < max_votes <= min_votes:
            break
        if prog.iscanceled():
            break
        
        page_url = url + '&num_votes=%d,' % min_votes
        
        if max_votes > -1:
            page_url += '%d' % max_votes
        prog.update(int(100 * page_count / total_pages),
                    '%s\n  Page: %d of %d' % (h, page_count + 1, total_pages))
        
        if page_count > 0:
            sleep(randint(2, 3))
        page_count += 1
        
        json_text = get_imdb_text(page_url)
        if not json_text:
            break
        
        try:
            json_text = json_text.split('"titleListItems":')[1].split(',"total":')[0]
        except IndexError:
            notification('Error parsing URL')
            logger('PARSE FAILURE', page_url)
            break
        
        json_data = json.loads(json_text)
        last_page = len(json_data) < 50
        for d in json_data:
            if not d['genres']:
                continue
            data = {
                'id': d['titleId'],
                'title': d['titleText'],
                'sort_title': get_sort_title(d['titleText']),
                'year': d['releaseYear'],
                'genres': d['genres'],
                'type': d['titleType']['id'],
                'plot': d['plot'],
                'rating': d['ratingSummary']['aggregateRating'],
                'votes': d['ratingSummary']['voteCount']
            }
            data['release_date'] = '%s-01-01' % data['year']
            
            max_votes = data['votes']
            data['media_type'] = 'TV' if data['type'] in ('tvSeries', 'tvMiniSeries') else 'MOVIE'
            
            data['label'] = '%s / %s (%d) | %.1f (%d)' % (
                data['media_type'], data['title'], data['year'], data['rating'], data['votes'])
            results[d['titleId']] = data
        if last_page:
            break
    
    prog.close()
    
    output = sorted(list(results.values()), key=lambda k: k['release_date'])
    output.sort(key=lambda k: k['sort_title'])
    
    return [_get_item(d['id'], '%s (%d)' % (d['title'], d['year']), ', '.join(d['genres']),
                      str(d['rating']), str(d['votes']), d['plot'])
            for d in output]


def imdb_find_advanced(params):
    from xbmcgui import ListItem, Dialog
    from modules.armani_utils import dialog_numeric, dialog_detail_menu, dialog_menu, dialog_column_menu
    from caches.armani_settings import ArmaniSettings
    
    def _defaults():
        return {
            'type_index': 0,
            'title': '',
            'genre_keys': [],
            'keyword_keys': [],
            'language_index': 0,
            'years': [1900, TODAY.year],
            'vote_index': 3,
            'min_rating_index': 3,
            'max_rating_index': 0,
            'page_index': 2
        }
    
    def _reset():
        values.update(_defaults())
        settings.save_json('imdb_find_advanced', values)
        
    def _load():
        values.update(settings.get_json('imdb_find_advanced'))
        if 'db_type' in params:
            values['type_index'] = 1 if params['db_type'] == 'movie' else 2
        if 'query' in params:
            values['title'] = params['query'].strip()
        if 'genre_id' in params:
            _g = params['genre_id']
            if _g in GENRE_MAP:
                values['genre_keys'] = [_g]
            elif _g in KEYWORD_MAP:
                values['keyword_keys'] = [KEYWORD_MAP[_g]]
        if 'decade' in params:
            _d = int(params['decade'])
            values['years'] = [_d, _d + 9]
            
    def _save():
        _keys = ('type_index', 'genre_keys', 'keyword_keys', 'language_index', 'years', 'vote_index',
                 'min_rating_index', 'max_rating_index', 'page_index')
        settings.save_json('imdb_find_advanced', {k: values[k] for k in _keys})

    settings = ArmaniSettings()
    
    title_types = [
        ('All', 'movie,tvMovie,short,tvSeries,tvMiniSeries'),
        ('Movies', 'movie,tvMovie,short'),
        ('TV Shows', 'tvSeries,tvMiniSeries')
    ]
    min_votes = ['0', '1,000', '2,500', '5,000',
                 '10,000', '25,000', '50,000', '100,000',
                 '250,000', '500,000', '1,000,000', '2,500,000']
    min_ratings = ['0', '5', '5.5', '6', '6.5',
                   '7', '7.5', '8', '8.5', '9']
    max_ratings = ['10', '8.9', '8.4', '7.9', '7.4',
                   '6.9', '6.4', '5.9', '5.4', '4.9']
    page_counts = ['1', '2', '3', '4', '5',
                   '6', '7', '8', '9', '10']
    genre_keys = list(GENRE_MAP.keys())
    genre_values = list(GENRE_MAP.values())
    keyword_keys = list(KEYWORDS.keys())
    keyword_values = list(KEYWORDS.values())

    values = _defaults()
    _load()
    
    dlg = Dialog()
    
    color_filter = '[COLOR lightgrey]%s[/COLOR]'
    
    i = -1
    while 1:
        options = [
            ListItem(color_filter % 'Media Type', title_types[values['type_index']][0]),
            ListItem(color_filter % 'Title', values['title']),
            ListItem(color_filter % 'Genres', ', '.join(GENRE_MAP[k] for k in values['genre_keys'])),
            ListItem(color_filter % 'Keywords', ', '.join(KEYWORDS[k] for k in values['keyword_keys'])),
            ListItem(color_filter % 'Language',  IMDB_ADVANCED_LANGUAGES[values['language_index']][0]),
            ListItem(color_filter % 'Year Range', '%d - %d' % (values['years'][0], values['years'][1])),
            ListItem(color_filter % 'IMDb Rating', '%s - %s' % (min_ratings[values['min_rating_index']],
                                                              max_ratings[values['max_rating_index']])),
            ListItem(color_filter % 'Min. Votes', min_votes[values['vote_index']]),
            ListItem(color_filter % 'Max. Pages', page_counts[values['page_index']]),
            ListItem('[COLOR lime]SEARCH[/COLOR]'),
            ListItem('[COLOR tomato]RESET[/COLOR]'),
        ]
        i = dialog_detail_menu('Advanced Search', options, True, i, 'menu11')
        if i < 0:
            _save()
            return None
        
        elif i == 0:
            j = dialog_menu('Media Type', [t[0] for t in title_types], values['type_index'])
            if j > -1:
                values['type_index'] = j
        elif i == 1:
            values['title'] = dlg.input('Search for a title', values['title']).strip()
        elif i == 2:
            pre = [genre_keys.index(k) for k in values['genre_keys']]
            sel = dialog_column_menu('genres', 4, 8, 'Genres', genre_values, True, pre)
            if sel is None:
                continue
            values['genre_keys'] = [genre_keys[i] for i in sel]
        elif i == 3:
            pre = [keyword_keys.index(k) for k in values['keyword_keys']]
            sel = dialog_column_menu('genres', 4, 8, 'Keywords', keyword_values, True, pre)
            if sel is None:
                continue
            values['keyword_keys'] = [keyword_keys[i] for i in sel]
        elif i == 4:
            j = dialog_column_menu('genres', 4, 8, 'Language', [v[0] for v in IMDB_ADVANCED_LANGUAGES], False,
                                   values['language_index'])
            if j > -1:
                values['language_index'] = j
        elif i == 5:
            y1 = int(dialog_numeric('Minimum Year', '%d - %d' % (1900, TODAY.year)) or '0')
            if y1 < 1900 or y1 > TODAY.year:
                continue
            y2 = TODAY.year
            if y1 < TODAY.year:
                y2 = int(dialog_numeric('Maximum Year', '%d - %d' % (y1, TODAY.year)) or '0')
                if y2 < y1 or y2 > TODAY.year:
                    continue
            values['years'] = [y1, y2]
        elif i == 6:
            j = dialog_column_menu('small_num', 5, 3, 'Minimum Rating', min_ratings, False, values['min_rating_index'])
            if j < 0:
                continue
            values['min_rating_index'] = j
            values['max_rating_index'] = 0
            m = [r for r in max_ratings if float(r) > float(min_ratings[j])]
            if len(m) < 2:
                continue
            j = dialog_column_menu('small_num', 5, 3, 'Maximum Rating', m, False, 0)
            if j > -1:
                values['max_rating_index'] = j
        elif i == 7:
            j = dialog_column_menu('genres', 4, 8, 'Minimum Vote Count', min_votes, False, values['vote_index'])
            if j > -1:
                values['vote_index'] = j
        elif i == 8:
            j = dialog_column_menu('small_num', 5, 3, 'Pages to Scan', page_counts, False, values['page_index'])
            if j > -1:
                values['page_index'] = j
        elif i == 9:
            _save()
            url_params = [
                'title_type=%s' % title_types[values['type_index']][1],
                'release_date=%d-01-01,%d-12-31' % (values['years'][0], values['years'][1]),
                'user_rating=%s,%s' % (min_ratings[values['min_rating_index']],
                                       max_ratings[values['max_rating_index']])
            ]
            if values['title']:
                url_params.append('title=%s' % values['title'])
            if values['genre_keys']:
                url_params.append('genres=%s' % ','.join(GENRE_MAP[k] for k in values['genre_keys']))
            if values['keyword_keys']:
                url_params.append('keywords=%s' % ','.join(KEYWORDS[k] for k in values['keyword_keys']))
            if values['language_index'] > 0:
                url_params.append(IMDB_ADVANCED_LANGUAGES[values['language_index']][1])
            
            url_tail = '&'.join(url_params)
            votes = int(min_votes[values['vote_index']].replace(',', ''))
            pages = int(page_counts[values['page_index']])
            return imdb_advanced_search(url_tail, pages, votes)
        else:
            _reset()
        
        
def get_imdb_text(url, session=None) -> str:
    """ Returns the HTML of a web page.

    Args:
        url: IMDb URL
        session: (optional) requests session

    Returns:
        Returns the text (HTML) of a web page if it is successfully retrieved, an empty string otherwise

    """
    try:
        response = requests.get(url, headers=IMDB_HEADERS) if not session else session.get(
            url, headers=IMDB_HEADERS, timeout=5)
    except requests.exceptions.Timeout:
        notification('Timed out')
        logger('get_imdb_text: timeout', url)
        return ''
    
    if response.status_code != 200:
        notification('Error retrieving url')
        logger('get_imdb_text: failed', url)
        return ''
    return response.text


def get_imdb_json(url: str, split_a: str, split_b: str, session=None) -> dict:
    """ Return JSON found between two strings in a web page containing javascript.

    Args:
        url: IMDb URL
        split_a: JSON begins after this string
        split_b: JSON begins before this string
        session: (optional) requests session

    Returns:
        Returns the JSON if it exists, an empty dictionary otherwise

    """
    # Perform the search and extract results from javascript JSON
    json_text = get_imdb_text(url, session)
    if not json_text:
        return {}
    try:
        json_text = json_text.split(split_a)[1].split(split_b)[0]
    except IndexError:
        notification('Error retrieving data')
        logger('get_imdb_json: scrape error', url)
    
    try:
        data = json.loads(json_text)
        return data
    except json.JSONDecodeError:
        notification('Error retrieving data')
        logger('get_imdb_json: parse error', url)
        return {}

        
def _get_item(imdb_id: str, title_year: str, genres, rating: str, votes: str, plot: str):
    if type(genres) is list:
        genres = ', '.join(genres)
    title_year = title_year.strip()
    info = '[COLOR cyan]%s[/COLOR][CR]' % title_year.upper()
    info += '[COLOR lightgrey]%s[/COLOR][CR]' % genres.strip()
    info += '[COLOR lightyellow]%s (%s)[/COLOR][CR][CR]' % (rating.strip(), votes.strip())
    info += plot.strip()
    return {
        'id': imdb_id.strip().lower(),
        'label': title_year,
        'sort_title': get_sort_title(title_year),
        'info': info
    }
    



