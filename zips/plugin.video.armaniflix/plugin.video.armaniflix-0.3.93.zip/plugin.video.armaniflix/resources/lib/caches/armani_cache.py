import json
import time

import requests
from datetime import date, datetime as dt
from xbmcgui import Dialog, DialogProgressBG, DialogProgress
from xbmcvfs import translatePath
import sqlite3
import re
import unicodedata
from modules.kodi_utils import kodi_refresh, notification, local_string as ls, logger
from caches.armani_settings import ArmaniSettings

from modules.armani_utils import truncate_complete_sentences
from modules.settings import tmdb_api_key

ARMANI_STR = ls(32036).upper()
ADDON_DATA = 'special://profile/addon_data/plugin.video.armaniflix/%s'
MEDIA_DB = translatePath(ADDON_DATA % 'armani_media.db')
CONFIG = translatePath(ADDON_DATA % 'armani.json')
IMDB_LISTS = translatePath(ADDON_DATA % 'imdb_lists.json')

GIT = {
    'config': 'https://sisyphussam.github.io/defaults/armani.json',
    'database': 'https://sisyphussam.github.io/defaults/armani_media.db'
}

IMDB_GENRES = {
    'Action': 'act', 'Adult': 'adu', 'Adventure': 'adv', 'Animation': 'ani', 'Biography': 'bio',
    'Comedy': 'com', 'Crime': 'cri', 'Documentary': 'doc', 'Drama': 'dra', 'Family': 'fam',
    'Fantasy': 'fan', 'Film-Noir': 'fil', 'Game-Show': 'gam', 'History': 'his', 'Horror': 'hor',
    'Music': 'muc', 'Musical': 'mus', 'Mystery': 'mys', 'News': 'new', 'Reality-TV': 'rea',
    'Romance': 'rom', 'Sci-Fi': 'sci', 'Short': 'sho', 'Sport': 'spo', 'Talk-Show': 'tal',
    'Thriller': 'thr', 'War': 'war', 'Western': 'wes'
}

MEDIA_TYPES = {
    'movies': ls(32028),
    'tvshows': ls(32029)
}

CATEGORIES = {
    'alpha': ls(33621),
    'genres': ls(33622),
    'decades': ls(33623)
}

SORTS = {
    'rating': ls(33515),
    'votes': ls(33516),
    'year': ls(33517),
    'random': ls(33218)
}

NUM_EXAMPLES = 6
FETCH_LIMIT = 250
PLAYLIST_LIMIT = 250

IMDB_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "DNT": "1",
                "Connection": "close",
                "Upgrade-Insecure-Requests": "1"}
GIT_HEADERS = {"Cache-Control": "no-cache", "Pragma": "no-cache"}


PLAYLIST_MAIN_MENU = {
    'reset': {'exec': 'reset()', 'label': 33642, 'info': 33643},
    'media_types': {'exec': 'select_media_type()', 'label': 33628, 'info': 33629},
    'watched_content': {'exec': 'select_watched_status()', 'label': 33630, 'info': 33631},
    'decades': {'exec': 'select_decades()', 'label': 33632, 'info': 33633},
    'languages': {'exec': 'select_languages()', 'label': 33634, 'info': 33635},
    'genres_any': {'exec': 'select_genres("genres_any")', 'label': 33636, 'info': 33637},
    'genres_all': {'exec': 'select_genres("genres_all")', 'label': 33638, 'info': 33639},
    'genres_none': {'exec': 'select_genres("genres_none")', 'label': 33640, 'info': 33641},
    'search_any': {'exec': 'search_terms("search_any")', 'label': 33649, 'info': 33651},
    'search_all': {'exec': 'search_terms("search_all")', 'label': 33650, 'info': 33652},
    'search_none': {'exec': 'search_terms("search_none")', 'label': 33648, 'info': 33653},
    'size_filter': {'exec': 'set_size_filter()', 'label': 33644, 'info': 33645}
}

SIZE_FILTERS = {
    'votes_desc': {'label': 'Highest Vote Count (IMDb)', 'order': 'votes DESC, rating DESC'},
    'votes_asc': {'label': 'Lowest Vote Count (IMDb)', 'order': 'votes ASC, rating DESC'},
    'rating_desc': {'label': 'Highest Rating (IMDb)', 'order': 'rating DESC, votes DESC'},
    'rating_asc': {'label': 'Lowest Rating (IMDb)', 'order': 'rating ASC, votes DESC'},
    'year_asc': {'label': 'Oldest Releases', 'order': 'release_date ASC, votes DESC'},
    'year_desc': {'label': 'Latest Releases', 'order': 'release_date DESC, votes DESC'}
}


ANIMATION_SUBGENRES = ['com', 'dra', 'act', 'fan', 'sci', 'hor']

UPDATE_DAYS = 7


def _search_string(s):
    s = unicodedata.normalize('NFD', s)
    s = s.encode('ascii', 'ignore')
    s = s.decode("utf-8")
    s = re.sub(r'[^A-Za-z\d]+', '', s)
    return s


def _db_types_to_where(db_types: str):
    db_types = [t.strip().lower() for t in db_types.split(',')]
    where = ' OR '.join(['db_type = ?'] * len(db_types))
    return where, db_types

    
def run_playlist_command(key):
    exec('self.%s' % PLAYLIST_MAIN_MENU[key]['exec'])
    
    
def get_imdb_lists() -> list:
    try:
        with open(IMDB_LISTS, 'r') as fp:
            data = json.load(fp)
    except:
        notification('Lists could not be retrieved')
        return {}
    imdb_lists = [{'id': k, 'name': v['name'], 'count': v['count'], 'items': v['items']} for k, v in data.items()]
    imdb_lists.sort(key=lambda k: k['name'])
    return imdb_lists


def get_imdb_dict() -> dict:
    imdb_lists = get_imdb_lists()
    if not imdb_lists:
        return {}
    imdb_dict = {}
    for imdb_list in imdb_lists:
        imdb_dict.update({r['imdb_id']: r for r in imdb_list['items']})
    return imdb_dict
    

def get_imdb_rows() -> list:
    imdb_dict = get_imdb_dict()
    if not get_imdb_dict():
        return []
    
    imdb_rows = list(imdb_dict.values())
    imdb_rows.sort(key=lambda k: k['release_date'])
    imdb_rows.sort(key=lambda k: k['sort_title'])
    return imdb_rows


def _get_tmdb(url_tail, session=None):
    api_str = '&api_key=%s' if '?' in url_tail else '?api_key=%s'
    url = 'https://api.themoviedb.org/3/' + url_tail + api_str % tmdb_api_key()
    
    if not session:
        tmdb_response = requests.get(url)
    else:
        tmdb_response = session.get(url)
    if tmdb_response.status_code != 200:
        return {}
    return tmdb_response.json()


class ArmaniCache:
    """ A database containing all movies and TV shows listed in IMDb CSV files. """
    
    def __init__(self):
        self.settings = ArmaniSettings()
        self.language = 'en-US'
        self.conn = sqlite3.connect(MEDIA_DB)
        self.cursor = self.conn.cursor()
        self.insert_label = ''
        
        self.menu = self.settings.get_json('main_menu')
        self.genres, self.languages, self.countries = {}, {}, {}
        self.__load_config()
        self.in_use = self.settings.get_json('in_use')
        self.list_import_count = 0
        
    def __load_config(self):
        try:
            with open(CONFIG, 'r') as fp:
                data = json.load(fp)
        except OSError:
            pass

        try:
            self.genres = data['genres']
            self.languages = data['languages']
            self.countries = data['countries']
        except Exception as e:
            logger('EXCEPTION', str(e))
            self.download_config()
        
    def check(self):
        # Download default database from GitHub if the current one is empty
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        results = self.cursor.fetchall()
        if not results:
            self.clear_database(False)

    def download_config(self) -> bool:
        """ Download the latest config from GitHub

        Returns: True if successful, False otherwise
        """
        response = requests.get(GIT['config'], headers=GIT_HEADERS)
        if response.status_code != 200:
            logger(ARMANI_STR, 'Failed to download config from GitHub')
            notification('Failed to download config')
            return False
        data = response.json()
        with open(CONFIG, 'w') as fp:
            json.dump(data, fp)
    
        self.genres = data['genres']
        self.countries = data['countries']
        self.languages = data['languages']
        self.settings.save_config(data)
        notification('Downloaded config')
        self.__post_update()
        return True

    def clear_database(self, confirm=True):
        if confirm and not Dialog().yesno('Confirm Deletion', 'Delete all entries in the media database?'):
            return False
    
        self.cursor.executescript("""
            DROP TABLE IF EXISTS media;

            CREATE TABLE media (
                imdb_id TEXT NOT NULL UNIQUE,
                tmdb_id INTEGER NOT NULL,
                db_type TEXT NOT NULL,
                title TEXT,
                sort_title TEXT,
                starting_letter TEXT,
                plot TEXT,
                main_credits TEXT,
                genre_ids TEXT,
                mpaa TEXT,
                original_language TEXT,
                release_date TEXT,
                year INTEGER,
                decade INTEGER,
                runtime INTEGER,
                rating REAL,
                votes INTEGER,
                search_string TEXT,
                extra_info TEXT,
                status TEXT,
                date_added TEXT,
                date_updated TEXT,
                UNIQUE(tmdb_id, db_type)
            );
        """)
    
        self.conn.commit()
        self.__post_update()
        notification('Database is empty')
        return True
    
    def imdb_list_browse(self):
        from modules.armani_utils import dialog_detail_menu
        from xbmcgui import ListItem
        imdb_lists = get_imdb_lists()
        
        str_nor = '[COLOR white]%s[/COLOR]'
        str_add = '[COLOR greenyellow]%s[/COLOR]'
        str_rem = '[COLOR tomato]%s[/COLOR]'
        
        list_index = -1
        with requests.Session() as session:
            while 1:
                list_index = dialog_detail_menu(
                    'IMDb Lists',
                    [ListItem(str_nor % i['name'], str_nor % ('%d titles' % i['count'])) for i in imdb_lists],
                    preselect=list_index)
                if list_index < 0:
                    kodi_refresh()
                    return
                
                imdb_list = imdb_lists[list_index]
                item_index = -1
                
                while 1:
                    self.cursor.execute('SELECT imdb_id FROM media ORDER BY sort_title, release_date')
                    imdb_ids = [r[0] for r in self.cursor.fetchall()]
                    items = []
                    for item in imdb_list['items']:
                        item['exists'] = item['imdb_id'] in imdb_ids
                        if item['exists']:
                            item['label'] = str_rem % ('%s (%d)' % (item['title'], item['year']))
                        else:
                            item['label'] = str_add % ('%s (%d)' % (item['title'], item['year']))
                        items.append(item)
                    item_index = dialog_detail_menu(
                        '%s (%s | %s)' % (imdb_list['name'], str_add % 'Add', str_rem % 'Remove'),
                        [i['label'] for i in items], use_details=False, preselect=item_index)
                    if item_index < 0:
                        break
                        
                    item = items[item_index]
                    if item['exists']:
                        self.delete_entry(item['imdb_id'])
                    else:
                        self.__insert_or_update(item['imdb_id'], session, item['title'], item['sort_title'],
                                                item['genre_ids'])
                        self.__post_update()
                        
    def imdb_list_update(self, refresh_all=False):
        from modules.armani_utils import get_user_lists, current_date
        from random import randint
        from xbmcgui import Dialog
        
        dlg = Dialog()
        
        try:
            with open(IMDB_LISTS, 'r') as fp:
                list_data = json.load(fp)
        except:
            list_data = {}
        
        prog = DialogProgressBG()
        prog.create('Updating Lists')
        
        imdb_lists = get_user_lists()
        if not imdb_lists:
            prog.close()
            notification('Lists could not be retrieved')
            return False

        list_ids = [v['id'] for v in imdb_lists]
        delete_ids = [list_id for list_id in list_data if list_id not in list_ids]
        [list_data.pop(list_id) for list_id in delete_ids]
        
        i = 0
        for imdb_list in imdb_lists:
            list_id = imdb_list['id']
            data = {'name': imdb_list['name'], 'count': imdb_list['count'], 'modified': imdb_list['modified']}
            if list_id in list_data:
                current_modified = list_data[list_id].get('modified', '1900-01-01')
                current_count = list_data[list_id].get('count', 0)
            else:
                current_modified = '1900-01-01'
                current_count = 0
            
            if refresh_all or data['modified'] > current_modified or data['count'] != current_count:
                items = self.__download_imdb_list(list_id)
                if items:
                    prog.update(int(i * 100 / len(imdb_lists)), 'Updated [COLOR yellow]%s[/COLOR]' % data['name'])
                    data['items'] = items
                    list_data[list_id] = data
                    time.sleep(randint(2, 3))
            i += 1
            
        prog.update(100, 'Finalizing')
        
        with open(IMDB_LISTS, 'w') as fp:
            json.dump(list_data, fp)
            
        imdb_rows = get_imdb_rows()
        if not imdb_rows:
            return
        
        imdb_ids = [r['imdb_id'] for r in imdb_rows]
        
        self.cursor.execute('SELECT imdb_id, db_type, status, tmdb_id, extra_info '
                            'FROM media ORDER BY sort_title, release_date')
        existing = [{'imdb_id': r[0], 'db_type': r[1], 'status': r[2], 'tmdb_id': r[3],
                     'extra_info': json.loads(r[4])} for r in self.cursor.fetchall()]
        update_ids = [r['imdb_id'] for r in existing if r['imdb_id'] in imdb_ids]
        
        if update_ids:
            update_rows = [r for r in imdb_rows if r['imdb_id'] in update_ids]
            for row in update_rows:
                self.cursor.execute(
                    'SELECT extra_info, search_string, db_type, tmdb_id, title, sort_title, genre_ids, status, year '
                    'FROM media where imdb_id = ?', (row['imdb_id'],))
                existing = self.cursor.fetchone()
                if not existing:
                    continue
                extra_info = json.loads(existing[0])
                extra_info['genres'] = [self.genres[g] for g in row['genre_ids']]
                search_words = existing[1]
                search_title = _search_string(row['title'])
                if search_title not in search_words:
                    search_words = search_title + '||' + search_words
                
                self.cursor.execute("""
                    UPDATE media
                    SET title = ?, sort_title = ?, starting_letter = ?, genre_ids = ?, search_string = ?,
                        rating = ?, votes = ?, extra_info = ?, date_updated = ?
                    WHERE imdb_id = ?
                """, (row['title'], row['sort_title'], row['alpha'], ', '.join(row['genre_ids']), search_words,
                      row['rating'],  row['votes'],  json.dumps(extra_info), current_date(), row['imdb_id']))
            self.conn.commit()
            self.__post_update()
            
        prog.close()
        notification('Success!')
        
    def imdb_check_query(self, query):
        from xbmcgui import Dialog
        from random import randint
        q = _search_string(query.strip().lower())
        if not q:
            return False
        
        imdb_values = get_imdb_rows()
        if not imdb_values:
            return False
        
        self.cursor.execute('SELECT imdb_id FROM media ORDER BY sort_title, release_date')
        existing_ids = [r[0] for r in self.cursor.fetchall()]
        imdb_values = [i for i in imdb_values if i['imdb_id'] not in existing_ids]
        if not imdb_values:
            return False
        
        imdb_values = [i for i in imdb_values if q in i['search_string']]
        if not imdb_values:
            return False
        
        dlg = Dialog()
        if len(imdb_values) == 1:
            v = imdb_values[0]
            if not dlg.yesno('Add a New Title',
                             'Would you like to add [COLOR yellow]%s (%d)[/COLOR]?' % (v['title'], v['year'])):
                return False
        else:
            if not dlg.yesno('Add New Titles',
                             'Multiple titles matching your query can be added to the database. '
                             'Would you like to add one or more of them?'):
                return False
            
            options = ['%s (%s, %d)' % (i['title'], i['db_type'], i['year']) for i in imdb_values]
            sel = dlg.multiselect('Select Titles', options)
            if not sel:
                return False
            
            imdb_values = [imdb_values[i] for i in sel]

        prog = DialogProgressBG()
        prog.create('Adding New Titles')
        with requests.Session() as session:
            i = 0
            for item in imdb_values:
                prog.update(int(i * 100 / len(imdb_values)))
                i += 1
                self.__insert_or_update(item['imdb_id'], session, item['title'], item['sort_title'], item['genre_ids'])
                if i < len(imdb_values):
                    time.sleep(randint(2, 3))
        self.__post_update()
        prog.close()
        return True
        
    def imdb_list_menu(self, action='add', params=None):
        from xbmcgui import Dialog, ListItem
        from modules.armani_utils import dialog_detail_menu, dialog_numeric, dialog_menu
        from random import randint
        
        _w = '[COLOR white]%s[/COLOR]'
        
        action = action.lower()
        if action == 'add':
            header = 'Adding New Titles'
        else:
            header = 'Removing Existing Titles'
        
        if params is None:
            params = {}
            
        imdb_values = get_imdb_rows()
        if not imdb_values:
            return

        self.cursor.execute('SELECT imdb_id FROM media ORDER BY sort_title, release_date')
        existing_ids = [r[0] for r in self.cursor.fetchall()]

        # If adding, remove titles in database. Otherwise, remove titles not in database
        if action == 'add':
            imdb_values = [i for i in imdb_values if i['imdb_id'] not in existing_ids]
            if not imdb_values:
                notification('Nothing to add')
                return
        else:
            imdb_values = [i for i in imdb_values if i['imdb_id'] in existing_ids]
            if not imdb_values:
                notification('Nothing to delete')
                return
            
        dlg = Dialog()
        add_dates = sorted(list(dict.fromkeys([v['created'] for v in imdb_values])), reverse=True)
        alpha_list = sorted(list(dict.fromkeys([i['alpha'] for i in imdb_values])))
        genre_ids = []
        [genre_ids.extend(v['genre_ids']) for v in imdb_values]
        genre_ids = list(dict.fromkeys(genre_ids))
        genre_ids = [g for g in self.genres if g in genre_ids]
        genre_names = [self.genres[g] for g in genre_ids]
        d = int(params.get('decade', '0'))
        if d > 0:
            min_year, max_year = d, d + 9
        else:
            min_year, max_year = 0, 0

        date_added = ''
        
        alpha = params.get('alpha', '').upper()
        genre_id = params.get('genre_id', '').lower()
        min_ratings = [0, 5.0, 5.5, 6.0, 6.5, 7.0, 7.5, 8.0, 8.5, 9.0]
        max_ratings = [10, 8.9, 8.4, 7.9, 7.4, 6.9, 6.4, 5.9, 5.4]
        min_rating, max_rating = 0, 10
    
        query = params.get('query', '')
        db_type = params.get('db_type')

        i = -1
        while 1:
            filtered_values = [i for i in imdb_values]
            if db_type:
                filtered_values = [i for i in filtered_values if i['db_type'] == db_type]
            if query:
                filtered_values = [i for i in filtered_values if _search_string(query.lower()) in i['search_string']]
            if alpha:
                filtered_values = [i for i in filtered_values if i['alpha'] == alpha]
            if genre_id:
                filtered_values = [i for i in filtered_values if genre_id in i['genre_ids']]
            if min_year > 0:
                filtered_values = [i for i in filtered_values if min_year <= i['year']]
            if max_year > 0:
                filtered_values = [i for i in filtered_values if i['year'] <= max_year]
            if min_rating > 0:
                filtered_values = [i for i in filtered_values if min_rating <= i['rating']]
            if max_rating < 10:
                filtered_values = [i for i in filtered_values if i['rating'] <= max_rating]
            if date_added:
                filtered_values = [i for i in filtered_values if i['created'] == date_added]
                
            if db_type == 'movie':
                media_label = 'Movies'
            elif db_type == 'tvshow':
                media_label = 'TV shows'
            else:
                media_label = 'Movies and TV shows'
            
            items = [
                ListItem('[COLOR yellow][B]VIEW TITLES[/B][/COLOR]', _w % ('%d matches' % len(filtered_values))),
                ListItem(_w % 'Media Types', _w % media_label),
                ListItem(_w % 'Starting Letter', _w % alpha),
                ListItem(_w % 'Genre', _w % ('' if genre_id not in genre_ids else self.genres[genre_id])),
                ListItem(_w % 'Release Year: min', _w % ('' if min_year == 0 else str(min_year))),
                ListItem(_w % 'Release Year: max', _w % ('' if max_year == 0 else str(max_year))),
                ListItem(_w % 'IMDb Rating: min', _w % str(min_rating)),
                ListItem(_w % 'IMDb Rating: max', _w % str(max_rating)),
                ListItem(_w % 'Date Added', _w % date_added),
                ListItem(_w % 'Search', _w % query)
            ]
            
            i = dialog_detail_menu(header, items, preselect=i)
            if i < 0:
                break
            elif i == 0:
                if not filtered_values:
                    continue
    
                items = []
                for item in filtered_values:
                    genres = '[I]%s[/I]' % ', '.join(self.genres[g] for g in item['genre_ids'])
                    rating_votes = '%.1f (%d)' % (item['rating'], item['votes'])
                    title_year = '%s (%s, %d)' % (item['title'].upper(), item['db_type'], item['year'])
                    items.append(ListItem('%s | %s' % (title_year, genres), rating_votes))
    
                sel = dlg.multiselect(header, items)
                if not sel:
                    continue
    
                items = [filtered_values[j] for j in sel]
    
                if action == 'add':
                    prog = DialogProgress()
                    prog.create(header)
                    with requests.Session() as session:
                        i = 0
                        for item in items:
                            if prog.iscanceled():
                                break
                            prog.update(int(i * 100 / len(items)),
                                        '%d of %d. [COLOR lightyellow]%s (%d)[/COLOR]' % (i + 1, len(items),
                                                                                          item['title'], item['year']))
                            i += 1
                            self.__insert_or_update(item['imdb_id'], session, item['title'], item['sort_title'],
                                                    item['genre_ids'])
                            if i < len(items):
                                time.sleep(randint(2, 3))
                    self.__post_update()
                    prog.close()
                    kodi_refresh()
                    return
    
                elif action == 'delete':
                    success_count = 0
                    for item in items:
                        if self.delete_entry(item['imdb_id'], False):
                            success_count += 1
                    notification('Deleted %d of %d titles' % (success_count, len(items)))
                    kodi_refresh()
                    return
            elif i == 1:
                i = Dialog().yesnocustom('Media Types', 'Are you searching for movies or TV shows?',
                                         'TV Shows', 'Both', 'Movies')
                if i == 0:
                    db_type = None
                elif i == 1:
                    db_type = 'movie'
                elif i == 2:
                    db_type = 'tvshow'
            elif i == 2:
                pre = -1 if alpha not in alpha_list else alpha_list.index(alpha)
                j = dialog_menu('Starting Letter', alpha_list, pre)
                alpha = '' if j < 0 else alpha_list[j]
            elif i == 3:
                pre = -1 if genre_id not in genre_ids else genre_ids.index(genre_id)
                j = dialog_menu('Genre', genre_names, pre)
                genre_id = '' if j < 0 else genre_ids[j]
            elif i == 4:
                min_year = int(dialog_numeric('Min. Release Year', 'Enter Year') or '0')
                if min_year < 1800:
                    min_year = 0
            elif i == 5:
                max_year = int(dialog_numeric('Max. Release Year', 'Enter Year') or '0')
                if max_year < 1800:
                    max_year = 0
            elif i == 6:
                j = dialog_menu('Min. IMDb Rating', [str(r) for r in min_ratings], min_ratings.index(min_rating))
                min_rating = 0 if j < 0 else min_ratings[j]
                
            elif i == 7:
                j = dialog_menu('Max. IMDb Rating', [str(r) for r in max_ratings], max_ratings.index(max_rating))
                max_rating = 10 if j < 0 else max_ratings[j]
                
            elif i == 8:
                pre = -1 if not date_added else add_dates.index(date_added)
                j = dialog_menu('Date Added', add_dates, pre)
                date_added = '' if j < 0 else add_dates[j]
                
            elif i == 9:
                query = dlg.input('Search for a movie, TV show, or person', query)
                    
    def __download_imdb_list(self, list_id):
        import csv
        import requests
        from modules.armani_utils import get_sort_title
        from modules.kodi_utils import notification

        # Download the CSV
        csv_url = 'https://www.imdb.com/list/%s/export?ref_=ttls_exp' % list_id
        download = requests.get(csv_url, headers=IMDB_HEADERS)
        if download.status_code != 200:
            notification('CSV could not be downloaded')
            return None
        decoded_content = download.content.decode('utf-8')
        rows = list(csv.reader(decoded_content.splitlines(), delimiter=','))
        rows.pop(0)  # remove header row
        if not rows:
            notification('Empty list')
            return None
    
        results = []
    
        for row in rows:

            row_data = {
                'imdb_id': row[1],
                'db_type': 'movie' if row[7] in ('movie', 'short', 'tvMovie') else 'tvshow',
                'title': row[5],
                'sort_title': None,
                'release_date': row[13],
                'year': int(row[10]),
                'runtime': int(row[9]),
                'genre_ids': self.__get_fixed_genres([IMDB_GENRES[g] for g in row[11].split(', ')]),
                'director': '' if not row[14] else row[14].split(', ')[0],
                'rating': float(row[8]),
                'votes': int(row[12]),
                'index': int(row[0]),
                'created': row[2],
                'modified': row[3],
            }
            comment = row[4].strip()
            people = []
            if comment:
                lines = comment.split('||')
                for line in lines:
                    if '=' not in line:
                        logger('%s: Invalid comment' % list_id, str(row))
                        continue
                    if line.count('=') > 1:
                        logger('%s: Too many "="' % list_id, row)
                        continue
                    k, v = line.split('=')
                    k = k.strip().lower()
                    v = v.strip()
                    if k == 't':
                        row_data['title'] = v
                    elif k == 's':
                        row_data['sort_title'] = v.upper()
                    elif k == 'g':
                        genre_ids = [g.strip() for g in v.split(',') if g in self.genres]
                        if genre_ids:
                            row_data['genre_ids'] = genre_ids
                        else:
                            logger('%s: Invalid genres' % list_id, str(row))
                    elif k == 'p':
                        people = [p.strip() for p in v.split(',')]
                    else:
                        logger('%s: Invalid key (%s)' % (list_id, k), str(row))
                        
            if not row_data.get('sort_title'):
                row_data['sort_title'] = get_sort_title(row_data['title'])
            row_data['alpha'] = row_data['sort_title'][0] if row_data['sort_title'][0].isalpha() else '#'
            
            search_words = [row[5], row_data['title']]
            if row[14].strip():
                search_words.append(row[14].strip())
            if people:
                search_words.extend(people)
            search_words = list(dict.fromkeys(search_words))
            row_data['search_string'] = '||'.join(_search_string(w.lower()) for w in search_words)
            
            results.append(row_data)
            
        return results
    
    def update_episodes(self, imdb_id):
        self.cursor.execute('SELECT tmdb_id, status, extra_info FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return
        tmdb_id = result[0]
        status = result[1]
        extra_info = json.loads(result[2])
        starting_season = extra_info['num_seasons']
        
        tmdb_details = _get_tmdb('tv/%d?language=en-US' % tmdb_id)
        if not tmdb_details:
            return
    
        # Details from TMDb data
        status = tmdb_details['status']
    
        extra_info['num_seasons'] = tmdb_details['number_of_seasons']
        extra_info['num_episodes'] = tmdb_details['number_of_episodes']
        extra_info['episodes'] = extra_info['episodes']
        for season in range(starting_season, tmdb_details['number_of_seasons'] + 1):
            season_data = _get_tmdb('tv/%d/season/%d?language=en-US"' % (tmdb_id, season))
            extra_info['episodes'][str(season)] = {
                str(e['episode_number']): {
                    'release_date': e['air_date'],
                    'title': e['name'],
                    'plot': truncate_complete_sentences(e['overview']),
                    'runtime': e['runtime']
                } for e in season_data['episodes']
            }
        self.cursor.execute('UPDATE media SET status = ?, extra_info = ? '
                            'WHERE db_type = ? AND tmdb_id = ?', (status, json.dumps(extra_info),
                                                                  'tvshow', tmdb_id))
        self.conn.commit()
        kodi_refresh()
        notification('Success!')
    
    def __insert_or_update(self, imdb_id: str, session=None, title: str = None, sort_title: str = None, genre_ids=None):
        from modules.kodi_utils import notification
        from modules.armani_utils import get_sort_title, current_date
        from time import sleep
    
        def _error(msg):
            prog.close()
            notification('Error: %s' % imdb_id)
            logger('ArmaniFlix / add_entry[%s]' % imdb_id, str(msg))
        
        if not session:
            session = requests.Session()
            
        prog = DialogProgressBG()
        prog.create('Downloading metadata')
        
        self.cursor.execute('SELECT date_added FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        date_added = result[0] if result else current_date()
        self.insert_label = 'Updated [COLOR yellow]%s (%d)[/COLOR]' if result else 'Added [COLOR yellow]%s (%d)[/COLOR]'

        prog.update(25)
    
        # Get IMDb data
        response = session.get('https://www.imdb.com/title/%s' % imdb_id, headers=IMDB_HEADERS)
        if response.status_code != 200:
            _error('Unable to retrieve IMDb details')
            return False
        
        try:
            json_text = response.text.split('{"props":{"pageProps"')[1].split('"aboveTheFoldData":')[1]
            json_text = json_text.split(',"mainColumnData":{')[0]
        except IndexError:
            _error('Unable to parse IMDb page')
            return False
            
        imdb_data = json.loads(json_text)
    
        try:
            # Details from IMDb data
            if not title:
                title = imdb_data['titleText']['text']
            if not sort_title:
                sort_title = get_sort_title(title)
            alpha = sort_title[0] if sort_title[0].isalpha() else '#'
            if not genre_ids:
                imdb_genres = {
                    'Action': 'act', 'Adult': 'adu', 'Adventure': 'adv', 'Animation': 'ani', 'Biography': 'bio',
                    'Comedy': 'com', 'Crime': 'cri', 'Documentary': 'doc', 'Drama': 'dra', 'Family': 'fam',
                    'Fantasy': 'fan', 'Film-Noir': 'fil', 'Game Show': 'gam', 'History': 'his', 'Horror': 'hor',
                    'Music': 'muc', 'Musical': 'mus', 'Mystery': 'mys', 'News': 'new', 'Reality-TV': 'rea',
                    'Romance': 'rom', 'Sci-Fi': 'sci', 'Short': 'sho', 'Sport': 'spo', 'Talk-Show': 'tal',
                    'Thriller': 'thr', 'War': 'war', 'Western': 'wes'
                }
                genre_ids = [imdb_genres[g['text']] for g in imdb_data['genres']['genres']]
                genre_ids = self.__get_fixed_genres(genre_ids)
        
            db_type = 'movie' if imdb_data['titleType']['id'] in ('movie', 'tvMovie', 'short') else 'tvshow'
            media_type = 'movie' if db_type == 'movie' else 'tv'
            imdb_rating = imdb_data['ratingsSummary']['aggregateRating']
            imdb_votes = imdb_data['ratingsSummary']['voteCount']
            plot = truncate_complete_sentences(imdb_data['plot']['plotText']['plainText'])
        except Exception as e:
            _error(str(e))
            return False

        prog.update(50)
        # Get tmdb data
        tmdb_details, tmdb_release_dates, tmdb_credits, tmdb_ratings = None, None, None, None
        try:
            
            tmdb_find = _get_tmdb('find/%s?external_source=imdb_id' % imdb_id)
            found = tmdb_find.get('movie_results') if db_type == 'movie' else tmdb_find.get('tv_results')
            if not found:
                _error('TMDB ID not found')
                return False
            tmdb_id = found[0]['id']

            tmdb_details = _get_tmdb('%s/%d?language=en-US' % (media_type, tmdb_id))
            if db_type == 'movie':
                tmdb_credits = _get_tmdb('movie/%d/credits' % tmdb_id)
                tmdb_release_dates = _get_tmdb('movie/%s/release_dates' % tmdb_id)['results']
            else:
                tmdb_credits = _get_tmdb('tv/%d/aggregate_credits' % tmdb_id)
                tmdb_ratings = _get_tmdb('tv/%s/content_ratings' % tmdb_id)['results']

            # Details from TMDb data
            original_language = self.languages[tmdb_details['original_language']]
            status = tmdb_details['status']
            extra_info = {
                'genres': [self.genres[g] for g in genre_ids],
                'countries': ''
            }

            # Movie details from TMDb data
            director_jobs = ('director', 'directed by')
            writer_jobs = ('author', 'book', 'comic book', 'graphic novel', 'novel', 'original story', 'screenplay',
                           'screenplay by', 'short story', 'story', 'story by', 'writer', 'written by')

            prog.update(75)
            
            if db_type == 'movie':
                # Movie credits
                cast = tmdb_credits['cast']
                crew = sorted(tmdb_credits['crew'], key=lambda d: d['popularity'], reverse=True)
                directors = [p for p in crew if p['job'].lower() in director_jobs]
                creators = []
                writers = [p for p in crew if p['job'].lower() in writer_jobs]

                release_dates = []
                for d in tmdb_release_dates:
                    release_dates.extend([rd['release_date'][:10] for rd in d['release_dates']])
                release_date = min(release_dates)
                runtime = tmdb_details['runtime']

                release_dates = {r['iso_3166_1']: r['release_dates'] for r in tmdb_release_dates}
                if 'US' not in release_dates:
                    mpaa = 'NR'
                else:
                    mpaa_list = [r['certification'] for r in release_dates['US'] if r['certification']]
                    mpaa = 'NR' if not mpaa_list else mpaa_list[0]

                extra_info['countries'] = [c['name'] for c in tmdb_details['production_countries']]

            # TV details from TMDb data
            else:
                # TV credits
                cast = sorted(tmdb_credits['cast'], key=lambda d: d['total_episode_count'], reverse=True)
                cast = [c for c in cast if c['order'] < 8]
                for c in cast:
                    c['character'] = sorted(c['roles'], key=lambda d: d['episode_count'], reverse=True)[0][
                        'character']
                creators = [{'id': c['id'], 'name': c['name']} for c in tmdb_details.get('created_by', [])]
                directors = []
                writers = []
                for c in tmdb_credits['crew']:
                    for j in c['jobs']:
                        if j['job'].lower() in director_jobs:
                            directors.append(
                                {'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
                        elif j['job'].lower() in writer_jobs:
                            writers.append({'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
                directors = [{'id': p['id'], 'name': p['name']}
                             for p in sorted(directors, key=lambda d: d['episode_count'], reverse=True)][0:2]
                writers = [{'id': p['id'], 'name': p['name']}
                           for p in sorted(writers, key=lambda d: d['episode_count'], reverse=True)][0:2]

                release_date = tmdb_details['first_air_date']
                if tmdb_details['episode_run_time']:
                    runtime = tmdb_details['episode_run_time'][0]
                else:
                    episode_details = _get_tmdb('tv/%s/season/1/episode/1?language=en-US' % tmdb_id)
                    runtime = episode_details['runtime'] or 0

                certs = {r['iso_3166_1']: r['rating'] for r in tmdb_ratings if r['rating']}
                mpaa = 'NR' if 'US' not in certs else certs['US']
                extra_info['countries'] = [self.countries[c] for c in tmdb_details['origin_country']]
                extra_info['num_seasons'] = tmdb_details['number_of_seasons']
                extra_info['num_episodes'] = tmdb_details['number_of_episodes']
                extra_info['episodes'] = {}
                for season in range(1, tmdb_details['number_of_seasons'] + 1):
                    season_data = _get_tmdb('tv/%d/season/%d?language=en-US"' % (tmdb_id, season))
                    extra_info['episodes'][str(season)] = {
                        str(e['episode_number']): {
                            'release_date': e['air_date'],
                            'title': e['name'],
                            'plot': truncate_complete_sentences(e['overview']),
                            'runtime': e['runtime']
                        } for e in season_data['episodes']
                    }

            # Finalize credits
            cast = [{'id': p['id'], 'name': p['name'], 'role': p['character'], 'order': p['order']} for p in cast]
            director = [{'id': p['id'], 'name': p['name']} for p in directors]
            writer = [{'id': p['id'], 'name': p['name']} for p in writers]
            cast = list({p['id']: p for p in cast}.values())
            cast = sorted(cast, key=lambda d: d['order'])
            director = list({p['id']: p for p in director}.values())
            writer = list({p['id']: p for p in writer}.values())
            all_credits = {
                'director': director[0:2],
                'creator': creators[0:2],
                'writer': writer[0:2],
                'cast': cast[0:8]
            }

            creator = [p['name'] for p in all_credits.get('creator', [])]
            director = [p['name'] for p in all_credits.get('director', [])]
            writer = [p['name'] for p in all_credits.get('writer', [])]
            cast = [p['name'] for p in all_credits.get('cast', [])]

            credit_lines = []
            credit_string = '[B]%s:[/B] %s'
            if creator:
                credit_lines.append(credit_string % ('Creator', ', '.join(creator)))
            elif director:
                credit_lines.append(credit_string % ('Director', ', '.join(director)))
            if cast:
                credit_lines.append(credit_string % ('Stars', ', '.join(cast[0:3])))
            main_credits = '[CR]'.join(credit_lines)

            search_words = [title, sort_title] + creator + director + writer + cast
            search_words = '|'.join(list(dict.fromkeys([_search_string(w) for w in search_words])))

            release_year = int(release_date[:4])
            release_decade = 10 * int(release_year / 10)

            prog.update(100)
            self.cursor.execute("""
                   INSERT OR REPLACE INTO media (
                       imdb_id, db_type, tmdb_id, title, sort_title, starting_letter, plot, main_credits, genre_ids,
                       mpaa, original_language, release_date, year, decade, runtime, rating, votes,
                       search_string, extra_info, status, date_added, date_updated
                   ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
               """, (imdb_id, db_type, tmdb_id, title, sort_title, alpha, plot, main_credits, ','.join(genre_ids),
                     mpaa, original_language, release_date, release_year, release_decade, runtime, imdb_rating,
                     imdb_votes, search_words, json.dumps(extra_info), status, date_added, current_date())
            )
            self.conn.commit()
            prog.close()
    
        except Exception as e:
            _error(str(e))
            return False
    
        self.insert_label = self.insert_label % (title, release_year)
        return True

    def __post_update(self):
        def _menu_create(menu_id, menu_name):
            results = [{'imdb_id': r[0], 'title': r[1], 'sort_title': r[2], 'release_date': r[3]}
                       for r in self.cursor.fetchall()]
            if not results:
                return None
        
            samples = results[0:10]
            samples.sort(key=lambda x: x['release_date'])
            samples.sort(key=lambda x: x['sort_title'])
            return {
                'id': menu_id,
                'name': menu_name,
                'where': 'WHERE db_type = "%s" AND (%s)' % (db_type, filter_string),
                'count': len(results),
                'summary': '[CR]'.join([s['title'] for s in samples])
            }
    
        menu = {'movies': {'genres': {}, 'decades': {}, 'alpha': {}},
                'tvshows': {'genres': {}, 'decades': {}, 'alpha': {}}}
    
        self.cursor.execute('SELECT original_language, decade, genre_ids FROM media')
        results = self.cursor.fetchall()
        if not results:
            self.menu = menu
            self.settings.save_json('main_menu', self.menu)
            return
    
        languages = list(dict.fromkeys([r[0] for r in results]))
        languages.sort()
        decades = list(dict.fromkeys([r[1] for r in results]))
        decades.sort(reverse=True)
        genre_ids = list(dict.fromkeys([g.strip() for g in ','.join([r[2] for r in results]).split(',')]))
        genre_ids.sort()
        self.in_use = {
            'genres': genre_ids,
            'decades': decades,
            'languages': [k for k, v in self.languages.items() if v in languages]
        }
        self.playlist_values = {
            'genres': [{'label': self.genres[v], 'value': v} for v in genre_ids],
            'languages': [{'label': v, 'value': v} for v in languages],
            'decades': [{'label': '%d - %d' % (d, d + 9), 'value': d} for d in decades]
        }
        self.settings.save_json('in_use', self.in_use)
        self.settings.save_json('playlist_values', self.playlist_values)
    
        sql_select = 'SELECT imdb_id, title || " (" || year || ")", sort_title, release_date ' \
                     'FROM media WHERE db_type = ? AND %s ORDER BY RANDOM()'
    
        for db_type in ('movie', 'tvshow'):
            menu_type = 'movies' if db_type == 'movie' else 'tvshows'

            self.cursor.execute('SELECT title || " (" || year || ")" FROM media WHERE db_type = ? '
                                'ORDER BY sort_title, release_date', (db_type,))
            all_results = self.cursor.fetchall()
            if len(all_results) < 9:
                all_samples = '[CR]'.join(r[0] for r in all_results)
            else:
                s = '%s[CR]%s[CR]%s[CR].....[CR]%s[CR]%s[CR]%s'
                n = len(all_results) - 1
                all_samples = s % (all_results[0][0], all_results[1][0], all_results[2][0],
                                   all_results[n-2][0], all_results[n-1][0], all_results[n][0])
            media_name = 'movies' if db_type == 'movie' else 'TV shows'
            
            menu[menu_type]['alpha']['all'] = {
                'id': 'all',
                'name': 'ALL',
                'where': 'WHERE db_type = "%s"' % db_type,
                'count': len(all_results),
                'summary': 'View all %d %s in the database (use the menu to add more).'
                           '[CR][CR]%s' % (len(all_results), media_name, all_samples)
            }
            
            for g in self.genres:
                filter_string = 'genre_ids LIKE ' + '"%' + g + '%"'
                self.cursor.execute(sql_select % 'genre_ids LIKE ?', (db_type, '%' + g + '%'))
                menu_entry = _menu_create(g, self.genres[g])
                if menu_entry:
                    menu[menu_type]['genres'][g] = menu_entry
        
            for a in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
                filter_string = 'starting_letter = "%s"' % a
                self.cursor.execute(sql_select % 'starting_letter = ?', (db_type, a))
                menu_entry = _menu_create(a, a)
                if menu_entry:
                    menu[menu_type]['alpha'][a] = menu_entry
        
            for d in (1900, 1910, 1920, 1930, 1940, 1950, 1960, 1970, 1980, 1990, 2000, 2010, 2020, 2030):
                filter_string = 'decade = %d' % d
                self.cursor.execute(sql_select % 'decade = ?', (db_type, d))
                menu_entry = _menu_create(str(d), '%d - %d' % (d, d + 9))
                if menu_entry:
                    menu[menu_type]['decades'][str(d)] = menu_entry
        self.menu = menu
        self.settings.save_json('main_menu', self.menu)
    
    def delete_entry(self, imdb_id, confirm=True):
        self.cursor.execute('SELECT title || " (" || year || ")" FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return False
        if confirm and not Dialog().yesno(
                'Confirm Deletion',
                'Are you certain you want to remove [COLOR yellow]%s[/COLOR] from the media database?' % result[0]):
            return False
        
        self.cursor.execute('DELETE FROM media WHERE imdb_id = ?', (imdb_id,))
        self.conn.commit()
        self.conn.execute('VACUUM')
        self.__post_update()
        notification('Deleted %s' % imdb_id)
        return True

    def edit_entry(self, imdb_id):
        """ Modify metadata (optional) and updates rating and status of the specified entry. """
        from modules.armani_utils import current_date, dialog_detail_menu
        from xbmcgui import ListItem

        self.cursor.execute('SELECT title, sort_title, genre_ids, extra_info, year FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return
        
        title = result[0]
        sort_title = result[1]
        year = result[4]
        extra_info = json.loads(result[3])
        genre_ids = [g.strip() for g in result[2].split(',')]
        all_genre_ids = list(self.genres.keys())
        all_genre_values = list(self.genres.values())
        
        dlg = Dialog()
        
        while 1:
            options = [ListItem('Title', title),
                       ListItem('Sort Title', sort_title),
                       ListItem('Genres', ', '.join([self.genres[g] for g in genre_ids])),
                       ListItem('[COLOR yellow]UPDATE[/COLOR]', '[I]Refresh metadata (e.g., IMDb rating)[/I]'),
                       ListItem('[COLOR yellow]SAVE[/COLOR]', '[I]Save title, sort title, and genres[/I]')]
            sel = dialog_detail_menu('%s (%d)' % (title, year), options, True, menu_type='meta_edit')
            if sel < 0:
                return
            if sel == len(options) - 1:
                break
            if sel == 0:
                t = dlg.input('New Title', title).strip()
                if t:
                    title = t
            elif sel == 1:
                t = dlg.input('New Sort Title', sort_title).strip().upper()
                if t:
                    sort_title = t
            elif sel == 2:
                genre_pre = [all_genre_ids.index(g) for g in genre_ids]
                sel_genres = dlg.multiselect('Genres', all_genre_values, preselect=genre_pre)
                if sel_genres:
                    genre_ids = [all_genre_ids[i] for i in sel_genres]
                    extra_info['genres'] = [self.genres[g] for g in genre_ids]
            elif sel == 3:
                self.update_metadata(imdb_id)
        
        alpha = sort_title[0] if sort_title[0].isalpha() else '#'
        self.cursor.execute(
            'UPDATE media SET title = ?, sort_title = ?, starting_letter = ?, genre_ids = ?, '
            'extra_info = ?, date_updated = ? WHERE imdb_id = ?',
            (title, sort_title, alpha, ','.join(genre_ids), json.dumps(extra_info), current_date(), imdb_id))
        self.conn.commit()
        self.__post_update()
        notification('Success!')
            
    def update_metadata(self, imdb_id, silent=False):
        self.cursor.execute('SELECT title, sort_title, genre_ids FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return
        title, sort_title, genre_ids = result
        genre_ids = [g.strip() for g in genre_ids.split(',')]
        if not self.__insert_or_update(imdb_id, title=title, sort_title=sort_title, genre_ids=genre_ids):
            return
        self.__post_update()
        if not silent:
            notification('Updated metadata')
        
    def __get_fixed_genres(self, genre_ids: list):
        fixed_ids = list(dict.fromkeys([g for g in genre_ids if g in self.genres]))
        if 'ani' in genre_ids:
            fixed_ids = ['ani'] + [g for g in fixed_ids if g in ANIMATION_SUBGENRES]
        if len(fixed_ids) > 1 and 'fam' in fixed_ids:
            fixed_ids.remove('fam')
        if not fixed_ids:
            return genre_ids
        return fixed_ids
    
    def __get_new_values(self, title, sort_title, genre_ids):
        from xbmc import executebuiltin
        dlg = Dialog()
        title = dlg.input('Title', title)
        if not title:
            return None
        sort_title = dlg.input('Sort Title', sort_title).upper()
        if not sort_title:
            return None
        alpha = sort_title[0] if sort_title[0].isalpha() else '#'
        all_genre_ids = list(self.genres.keys())
        all_genre_values = list(self.genres.values())
        genre_pre = [all_genre_ids.index(g) for g in genre_ids]
        sel = dlg.multiselect('Genres', all_genre_values, preselect=genre_pre)
        
        if not sel:
            return None
        genre_ids = [all_genre_ids[i] for i in sel]
        return title, sort_title, alpha, genre_ids
    
    def get_meta_list(self, where="", where_values=None, sort_order='sort_title, release_date', limit:int = 0):
        if limit > 0:
            sort_order += ' LIMIT %d' % limit
        if where_values is None:
            where_values = ()
        
        try:
            self.cursor.execute(f"""
                SELECT
                    imdb_id, db_type, tmdb_id, title, sort_title, starting_letter, plot, main_credits, genre_ids, mpaa,
                    original_language, release_date, year, decade, runtime, rating, votes,
                    search_string, extra_info, status, date_added, date_updated
                FROM
                    media
                {where}
                ORDER BY
                    {sort_order}
            """, where_values)
        except sqlite3.Error:
            return []
        
        meta = []
        for row in self.cursor.fetchall():
            
            extra_info = json.loads(row[18])
            
            meta.append({
                'imdb_id': row[0],
                'db_type': row[1],
                'media_type': row[1],
                'tmdb_id': row[2],
                'original_title': row[3],
                'title': row[3] if row[10] == 'English' else '%s [COLOR grey][%s][/COLOR]' % (row[3], row[10]),
                'rootname': '%s (%d)' % (row[3], row[12]),
                'sort_title': row[4],
                'starting_letter': row[5],
                'plot': row[6] + '[CR][CR]' + row[7],
                'genre_ids': row[8],
                'mpaa': row[9],
                'original_language': row[10],
                'premiered': row[11],
                'year': str(row[12]),
                'decade': row[13],
                'duration': row[14],
                'rating': row[15],
                'votes': row[16],
                'search_string': row[17],
                'genre': ', '.join(self.genres[g.strip()] for g in row[8].split(',') if g.strip() in self.genres),
                'country': extra_info['countries'],
                'total_seasons': extra_info.get('num_seasons', 0),
                'total_aired_eps': extra_info.get('num_episodes', 0),
                'episodes': extra_info.get('episodes'),
                'status': row[19],
                'date_added': row[20],
                'date_modified': row[21],
                'cast': '',
                'director': '',
                'writer': '',
                'keywords': '',
            })
        return meta

    def fetch(self, params, limit=None):
        db_types = params.get('db_types', 'movie, movie_set, tvshow')
        values = [t.strip().lower() for t in db_types.split(',')]
        where = '(%s)' % ' OR '.join(['db_type = ?'] * len(values))
    
        if 'years' in params:
            years = params['years'].split('-', maxsplit=1)
            if len(years) == 1:
                year_where = '(year = ?)'
                year_values = [int(years)]
            else:
                year_where = "(year >= ? AND year <= ?)"
                year_values = [int(years[0]), int(years[1])]
        
            values += year_values
            where += ' AND %s' % year_where
    
        if 'alpha' in params:
            values += [params['alpha'].upper()]
            where += ' AND starting_letter = ?'
    
        if 'genres' in params:
            genre_ids = params['genres'].split(',')
            values += ['%' + g.strip() + '%' for g in genre_ids]
            where += ' AND %s' % ' AND '.join(['genre_ids LIKE ?']*len(genre_ids))
    
        if 'query' in params:
            queries = params['query'].split(',')
            values += ['%' + _search_string(q.strip()) + '%' for q in queries]
            where += ' AND (%s)' % ' OR '.join(['search_string LIKE ?']*len(queries))
    
        sort_order = params.get('sort_order', 'sort_title, release_date')
        if 'limit' not in sort_order.lower():
            sort_order += ' LIMIT %d' % (limit or FETCH_LIMIT)
        return self.get_meta_list('WHERE %s' % where, values, sort_order)

    def can_fetch(self, params):
        return len(self.fetch(params, 1)) > 0
    
    def get_meta_tmdb(self, db_type, tmdb_id):
        results = self.get_meta_list('WHERE db_type = ? AND tmdb_id = ?', (db_type, tmdb_id))
        return {} if not results else results[0]
    
    def get_meta_imdb(self, imdb_id):
        results = self.get_meta_list('WHERE imdb_id = ?', (imdb_id,))
        return {} if not results else results[0]
    
    def get_meta_action(self, action):
        from caches.armani_users import ArmaniUsers
        from caches.favorites import Favorites
        from modules.watched_status import armani_get_watch_history
        from modules.kodi_utils import get_armani_user
        armani_users = ArmaniUsers()
        
        results = []
        if action == 'favorites':
            imdb_ids = armani_users.get_favorites()
            where = 'WHERE imdb_id IN (%s)' % ', '.join(['?'] * len(imdb_ids))
            results = self.get_meta_list(where, imdb_ids)
        elif action == 'watched':
            results = [self.get_meta_tmdb(r[1], r[0]) for r in armani_get_watch_history()]
        elif action == 'playlist':
            results = self.get_meta_playlist()
        
        return [r for r in results if r]
    
    def get_meta_playlist(self):
        from modules.watched_status import armani_remove_watched, armani_remove_unwatched
        from caches.armani_users import ArmaniPlaylist
        playlist = ArmaniPlaylist().get_playlist()
        media_types = playlist.get('media_types') or ['movie']
        watched_status = playlist.get('watched_status') or ['unwatched', 'watched']

        filters = []
        values = []
        filters.append('db_type IN (%s)' % ', '.join(['?'] * len(media_types)))
        values.extend(media_types)
        
        if playlist.get('genres_all'):
            filters.append(' AND '.join(['genre_ids LIKE ?'] * len(playlist['genres_all'])))
            values.extend(['%' + g + '%' for g in playlist['genres_all']])
        if playlist.get('genres_any'):
            filters.append(' OR '.join(['genre_ids LIKE ?'] * len(playlist['genres_any'])))
            values.extend(['%' + g + '%' for g in playlist['genres_any']])
        if playlist.get('genres_none'):
            filters.append(' AND '.join(['genre_ids NOT LIKE ?'] * len(playlist['genres_none'])))
            values.extend(['%' + g + '%' for g in playlist['genres_none']])
        if playlist.get('decades'):
            filters.append(' OR '.join(['(year >= ? AND year <= ?)'] * len(playlist['decades'])))
            for d in playlist['decades']:
                values.extend([int(d), int(d) + 9])
        if playlist.get('languages'):
            filters.append(' OR '.join(['original_language = ?'] * len(playlist['languages'])))
            values.extend(playlist['languages'])
        if playlist.get('search_any'):
            filters.append(' OR '.join(['search_string LIKE ?'] * len(playlist['search_any'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_any']])
        if playlist.get('search_all'):
            filters.append(' AND '.join(['search_string LIKE ?'] * len(playlist['search_all'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_all']])
        if playlist.get('search_none'):
            filters.append(' AND '.join(['search_string NOT LIKE ?'] * len(playlist['search_none'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_none']])

        s_filter = '' if not filters else 'WHERE %s' % ' AND '.join('(%s)' % f for f in filters)
        order = SIZE_FILTERS[playlist.get('size_filter', 'votes_desc')]['order']
        
        results = self.get_meta_list(s_filter, values, order)
        
        if 'unwatched' not in watched_status:
            results = armani_remove_unwatched(results)
        elif 'watched' not in watched_status:
            results = armani_remove_watched(results)
        else:
            results = armani_remove_watched(results, playlist['created'])

        results = results[0:PLAYLIST_LIMIT]
        results.sort(key=lambda x: x['premiered'])
        results.sort(key=lambda x: x['sort_title'])
        return results
    
    def get_header(self, main_key, category_key=None, sort_type=""):
        content_type, category = main_key.split('_')
        h = [MEDIA_TYPES[content_type], CATEGORIES[category]]
        header = '%s / %s' % (h[0], h[1])
        if category_key is not None:
            try:
                header += ' / %s' % self.menu[content_type][category][category_key]['name']
                if sort_type in SORTS:
                    header += ' [%s]' % SORTS[sort_type].lower()
            except KeyError:
                header = '%s / %s / Empty' % (h[0], h[1])
        return header
    
    def get_list(self, main_key):
        content_type, category = main_key.split('_')
        m = self.menu[content_type][category]
        
        return {k: {'key': k, 'title': v['name'], 'summary': v['summary'],
                    'count': v['count'], 'where': v['where']} for k, v in m.items()}
    
    def get_content(self, params):
        content_type, category = params['action'].split('_')
        m = self.menu[content_type][category].get(str(params['value'])) or {}
        if not m:
            return []
        
        order_str = 'sort_title, release_date'
        if 'order' in params:
            order_str = params['order']
            if 'limit' in params:
                order_str += ' LIMIT ' + params['limit']
        return self.get_meta_list(m['where'], sort_order=order_str)
    
    
armani = ArmaniCache()
