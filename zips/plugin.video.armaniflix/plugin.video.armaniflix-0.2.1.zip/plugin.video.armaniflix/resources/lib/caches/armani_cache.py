import json
import csv
import time
import requests
from datetime import date, datetime as dt, timedelta
from random import randint
from xbmcgui import Dialog, DialogProgressBG
from xbmcvfs import translatePath, delete, exists, copy
import sqlite3
import re
import unicodedata
from modules.kodi_utils import get_armani_user, kodi_refresh, notification, local_string as ls, logger
from caches.armani_settings import ArmaniSettings
from modules.armani_utils import truncate_complete_sentences
from modules.settings import tmdb_api_key

ARMANI_STR = ls(32036).upper()
ADDON_DATA = 'special://profile/addon_data/plugin.video.armaniflix/%s'
MEDIA_DB = translatePath(ADDON_DATA % 'armani_media.db')

GIT = {
    'config': 'https://sisyphussam.github.io/defaults/armani.json',
    'database': 'https://sisyphussam.github.io/defaults/armani_media.db'
}

MEDIA_TYPES = {
    'movies': ls(32028),
    'tvshows': ls(32029)
}

CATEGORIES = {
    'alpha': ls(33621),
    'genres': ls(33622),
    'decades': ls(33623)
}

SORTS = {
    'rating': ls(33515),
    'votes': ls(33516),
    'year': ls(33517),
    'random': ls(33218)
}

NUM_EXAMPLES = 6
FETCH_LIMIT = 250
PLAYLIST_LIMIT = 250

IMDB_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "DNT": "1",
                "Connection": "close",
                "Upgrade-Insecure-Requests": "1"}
GIT_HEADERS = {"Cache-Control": "no-cache", "Pragma": "no-cache"}


PLAYLIST_MAIN_MENU = {
    'reset': {'exec': 'reset()', 'label': 33642, 'info': 33643},
    'media_types': {'exec': 'select_media_type()', 'label': 33628, 'info': 33629},
    'watched_content': {'exec': 'select_watched_status()', 'label': 33630, 'info': 33631},
    'decades': {'exec': 'select_decades()', 'label': 33632, 'info': 33633},
    'languages': {'exec': 'select_languages()', 'label': 33634, 'info': 33635},
    'genres_any': {'exec': 'select_genres("genres_any")', 'label': 33636, 'info': 33637},
    'genres_all': {'exec': 'select_genres("genres_all")', 'label': 33638, 'info': 33639},
    'genres_none': {'exec': 'select_genres("genres_none")', 'label': 33640, 'info': 33641},
    'search_any': {'exec': 'search_terms("search_any")', 'label': 33649, 'info': 33651},
    'search_all': {'exec': 'search_terms("search_all")', 'label': 33650, 'info': 33652},
    'search_none': {'exec': 'search_terms("search_none")', 'label': 33648, 'info': 33653},
    'size_filter': {'exec': 'set_size_filter()', 'label': 33644, 'info': 33645}
}

SIZE_FILTERS = {
    'votes_desc': {'label': 'Highest Vote Count (IMDb)', 'order': 'votes DESC, rating DESC'},
    'votes_asc': {'label': 'Lowest Vote Count (IMDb)', 'order': 'votes ASC, rating DESC'},
    'rating_desc': {'label': 'Highest Rating (IMDb)', 'order': 'rating DESC, votes DESC'},
    'rating_asc': {'label': 'Lowest Rating (IMDb)', 'order': 'rating ASC, votes DESC'},
    'year_asc': {'label': 'Oldest Releases', 'order': 'release_date ASC, votes DESC'},
    'year_desc': {'label': 'Latest Releases', 'order': 'release_date DESC, votes DESC'}
}


ANIMATION_SUBGENRES = ['com', 'dra', 'act', 'fan', 'sci', 'hor']

UPDATE_DAYS = 7


def _search_string(s):
    s = unicodedata.normalize('NFD', s)
    s = s.encode('ascii', 'ignore')
    s = s.decode("utf-8")
    s = re.sub(r'[^A-Za-z\d]+', '', s)
    return s


def _db_types_to_where(db_types: str):
    db_types = [t.strip().lower() for t in db_types.split(',')]
    where = ' OR '.join(['db_type = ?'] * len(db_types))
    return where, db_types

    
def run_playlist_command(key):
    exec('self.%s' % PLAYLIST_MAIN_MENU[key]['exec'])


def _get_tmdb(url_tail, session=None):
    api_str = '&api_key=%s' if '?' in url_tail else '?api_key=%s'
    url = 'https://api.themoviedb.org/3/' + url_tail + api_str % tmdb_api_key()
    if not session:
        tmdb_response = requests.get(url)
    else:
        tmdb_response = session.get(url)
    if tmdb_response.status_code != 200:
        return {}
    return tmdb_response.json()
    
    
class ArmaniCache:
    """ A database containing all movies and TV shows listed in IMDb CSV files. """
    
    def __init__(self):
        self.settings = ArmaniSettings()
        self.language = 'en-US'
        self.conn = sqlite3.connect(MEDIA_DB)
        self.cursor = self.conn.cursor()
        self.menu = self.settings.get_json('main_menu')
        self.imdb_lists = self.settings.get_json('imdb_lists')
        self.last_update = self.settings.get('last_update')
        self.genres = self.settings.get_json('genres')
        self.languages = self.settings.get_json('languages')
        self.countries = self.settings.get_json('countries')
        self.in_use = self.settings.get_json('in_use')
        
    def check(self):
        """ If necessary, download config and/or media database from GitHub """
        if any(not self.settings.get(k) for k in ('genres', 'languages', 'countries')):
            self.download_config()
        
        # Download default database from GitHub if the current one is empty
        self.cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
        if not self.cursor.fetchall():
            self.download_default_database(False)

    def download_config(self) -> bool:
        """ Download the latest config from GitHub

        Returns: True if successful, False otherwise
        """
        response = requests.get(GIT['config'], headers=GIT_HEADERS)
        if response.status_code != 200:
            logger(ARMANI_STR, 'Failed to download config from GitHub')
            notification('Failed to download config')
            return False
        data = response.json()
    
        self.imdb_lists = data['imdb_lists']
        self.settings.save_json('imdb_lists', self.imdb_lists)
        self.genres = data['genres']
        self.countries = data['countries']
        self.languages = data['languages']
        self.settings.save_json('genres', self.genres)
        self.settings.save_json('countries', self.countries)
        self.settings.save_json('languages', self.languages)
        notification('Success!')
        return True
        
    def download_default_database(self, confirm=True):
        if confirm and not Dialog().yesno(
                'Default Database', 'The media database will be replaced with the one stored on GitHub. Proceed?'):
            return False
        
        response = requests.get(GIT['database'], headers=GIT_HEADERS)
        if response.status_code != 200:
            logger(ARMANI_STR, 'Failed to download database from GitHub')
            notification('Failed to download database')
            return False
    
        self.conn.close()
        delete(MEDIA_DB)
        with open(MEDIA_DB, 'wb') as out_file:
            out_file.write(response.content)
        self.conn = sqlite3.connect(MEDIA_DB)
        self.cursor = self.conn.cursor()
        self.__post_update()
        notification('Success!')
        return True
        
    def clear_database(self):
        if not Dialog().yesno('Confirm Deletion', 'Delete all entries in the media database?'):
            return False
        
        self.cursor.execute('DELETE FROM media')
        self.conn.commit()
        self.__post_update()
        notification('Success!')
        return True
    
    def add_imdb(self, imdb_id=None):
        from xbmc import executebuiltin
        dlg = Dialog()
        if not imdb_id:
            executebuiltin('SetProperty(numeric_header,%s,home)' % 'IMDb ID')
            imdb_id = dlg.numeric(0, 'Digits after "tt"')
            executebuiltin('ClearProperty(numeric_header,home)')
            if not imdb_id:
                return False
            imdb_id = 'tt' + imdb_id
        
        self.cursor.execute('SELECT title, year FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if result:
            dlg.ok('%s (%d)' % (result[0], result[1]),
                   'The IMDb ID (%s) is already in the media database.' % imdb_id)
            return False
    
        if not self.__insert_or_update(imdb_id, confirm_insert=True):
            notification('%s not added!' % imdb_id)
            return False
    
        self.__post_update()
        notification('Success!')
        return True
        
    def add_entry(self, db_type):
        if db_type == 'movie':
            media_type = 'movie'
            media_label = 'movie'
        else:
            media_type = 'tv'
            media_label = 'TV show'
            
        dlg = Dialog()
        query = dlg.input('Find a ' + media_label).strip()
        if not query:
            return False

        session = requests.Session()
        t = _get_tmdb('search/%s?query=%s' % (media_type, query), session)
        if not t.get('results', []):
            notification('No matches')
            return False

        tmdb_id = None
        for m in t['results']:
            title = m.get('title') if media_type == 'movie' else m.get('name')
            release_date = m.get('release_date') if media_type == 'movie' else m.get('first_air_date')
            if not title or not release_date:
                continue
            msg = '[COLOR lightyellow][B]%s (%s)[/B][/COLOR][CR]%s' % (title, release_date[:4], m.get('overview') or '')
            sel = dlg.yesnocustom("Is this what you're looking for?", msg, 'Cancel', 'Yes', 'No')
            if sel in (-1, 2):
                return False
            if sel == 0:
                tmdb_id = m['id']
                break

        if not tmdb_id:
            notification('No more results')
            return False

        t = _get_tmdb('%s/%d/external_ids' % (media_type, tmdb_id))
        if not t.get('imdb_id'):
            notification('Something went wrong')
            return False
        
        return self.add_imdb(t['imdb_id'])
        
    def import_list(self) -> bool:
        from xbmc import executebuiltin
        dlg = Dialog()

        executebuiltin('SetProperty(numeric_header,%s,home)' % 'IMDb List ID')
        list_id = dlg.numeric(0, 'Digits after "ls"')
        executebuiltin('ClearProperty(numeric_header,home)')
        
        if not list_id:
            return False
        list_id = 'ls' + list_id
        
        with requests.Session() as session:
            # Check if list is valid and the intended one
            response = session.get('https://www.imdb.com/list/%s/' % list_id, headers=IMDB_HEADERS)
            if response.status_code != 200:
                notification('Invalid list ID')
                return False
            html = response.text.replace('\n', '')
            try:
                list_name = html.split('<h1 class="header list-name">')[1].split('</h1>')[0]
                list_author = html.split('/?ref_=_usr">')[1].split('</a>')[0]
            except IndexError:
                notification('List could not be parsed')
                return False
            if not dlg.yesno('List Import', 'Import list "%s" by %s' % (list_name, list_author)):
                return False
            
            # Download the CSV
            header = 'IMDB Import (%s)' % list_id
            csv_url = 'https://www.imdb.com/list/%s/export?ref_=ttls_exp' % list_id
            download = session.get(csv_url, headers=IMDB_HEADERS)
            if download.status_code != 200:
                notification('CSV could not be downloaded')
                return False
            decoded_content = download.content.decode('utf-8')
            rows = list(csv.reader(decoded_content.splitlines(), delimiter=','))
            rows.pop(0)  # remove header row
            if not rows:
                notification('Empty list')
                return False
            
            # Add (or update) each row to the media database
            prog = DialogProgressBG()
            prog.create('Downloading metadata')
            i = 0
            for row in rows:
                prog.update(int(100 * i / len(rows)))
                i += 1
                
                # Get CSV values
                imdb_id = row[1]
                imdb_rating = float(row[8]) if row[8] else 0.0
                imdb_votes = int(row[12]) if row[12] else 0
                comment = [] if not row[4].strip() else [s.strip() for s in row[4].strip().split('||')]
                title, sort_title, genre_ids = None, None, None
                if len(comment) > 0:
                    genre_ids = list(dict.fromkeys([g.lower().strip() for g in comment[0].split(',')]))
                    if any(g not in self.genres for g in genre_ids):
                        logger(header, 'Invalid genre: %s' % str(row))
                        continue
                if len(comment) > 1:
                    sort_title = comment[1].strip().upper()
                    if not sort_title:
                        logger(header, 'Invalid sort title: %s' % str(row))
                        continue
                if len(comment) > 2:
                    title = comment[2].strip()
                    if not title:
                        logger(header, 'Invalid title: %s' % str(row))
                        continue
        
                self.cursor.execute('SELECT extra_info, db_type, tmdb_id, title, sort_title, genre_ids '
                                    'FROM media where imdb_id = ?', (imdb_id,))
                existing = self.cursor.fetchone()
        
                # If the entry exists, update title, sort title, genres, status, and season / episode counts
                if existing:
                    existing_genre_ids = self.__get_fixed_genres([g.strip() for g in existing[5].split(',')])
                    title = title or existing[3]
                    sort_title = sort_title or existing[4]
                    genre_ids = genre_ids or existing_genre_ids
                    alpha = sort_title[0] if sort_title[0].isalpha() else '#'
                    db_type = existing[1]
                    tmdb_id = existing[2]
                    extra_info = json.loads(existing[0])
                    extra_info['genres'] = [self.genres[g] for g in genre_ids]
                    if db_type == 'tvshow' and extra_info['status'] == 'Returning Series':
                        url = 'https://api.themoviedb.org/3/tv/%d?api_key=%s&language=en-US' % (tmdb_id, tmdb_api_key())
                        tmdb_response = session.get(url)
                        if tmdb_response.status_code != 200:
                            logger(header, 'Unable to retrieve TMDb details: %s' % str(row))
                        else:
                            tmdb_details = tmdb_response.json()
                            extra_info['status'] = tmdb_details['status']
                            extra_info['num_seasons'] = tmdb_details['number_of_seasons']
                            extra_info['num_episodes'] = tmdb_details['number_of_episodes']
                    self.cursor.execute("""
                         UPDATE media
                         SET title = ?, sort_title = ?, starting_letter = ?, genre_ids = ?, rating = ?, votes = ?,
                             extra_info = ?
                         WHERE imdb_id = ?
                     """, (title, sort_title, alpha, ', '.join(genre_ids), imdb_rating, imdb_votes,
                           json.dumps(extra_info), imdb_id))
                else:
                    # Add a new entry
                    self.__insert_or_update(imdb_id, False, session, title, sort_title, genre_ids)

        # Only commit if not errors occurred
        self.conn.commit()
        self.conn.execute('VACUUM')
        prog.close()
        self.__post_update()
        notification('Success!')
        return True

    
    
    def delete_entry(self, imdb_id):
        self.cursor.execute('SELECT title || " (" || year || ")" FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return
        dlg = Dialog()
        if not dlg.yesno(
                'Confirm Deletion',
                'Are you certain you want to remove [COLOR yellow]%s[/COLOR] from the media database?' % result[0]):
            return
        self.cursor.execute('DELETE FROM media WHERE imdb_id = ?', (imdb_id,))
        self.conn.commit()
        self.__post_update()
        notification('Success!')

    def edit_entry(self, imdb_id):
        """ Modify metadata (optional) and updates rating and status of the specified entry. """

        self.cursor.execute('SELECT title, sort_title, genre_ids, extra_info FROM media WHERE imdb_id = ?', (imdb_id,))
        result = self.cursor.fetchone()
        if not result:
            return
        
        title = result[0]
        sort_title = result[1]
        genre_ids = [g.strip() for g in result[2].split(',')]
        
        if Dialog().yesno(title, 'Would you like to modify the title, sort title, and/or genres?'):
            new_values = self.__get_new_values(title, sort_title, genre_ids)
            if new_values:
                title, sort_title, alpha, genre_ids = new_values
                extra_info = json.loads(result[3])
                extra_info['genres'] = [self.genres[g] for g in genre_ids]
                self.cursor.execute(
                    'UPDATE media SET title = ?, sort_title = ?, starting_letter = ?, genre_ids = ?, '
                    'extra_info = ? WHERE imdb_id = ?',
                    (title, sort_title, alpha, ','.join(genre_ids), json.dumps(extra_info), imdb_id))
                self.conn.commit()
        
        # Update rating
        if self.__insert_or_update(imdb_id, title=title, sort_title=sort_title, genre_ids=genre_ids):
            self.__post_update()
            notification('Success!')
            
    def __get_fixed_genres(self, genre_ids: list):
        fixed_ids = list(dict.fromkeys([g for g in genre_ids if g in self.genres]))
        if 'ani' in genre_ids:
            fixed_ids = ['ani'] + [g for g in fixed_ids if g in ANIMATION_SUBGENRES]
        if len(fixed_ids) > 1 and 'fam' in fixed_ids:
            fixed_ids.remove('fam')
        if not fixed_ids:
            return genre_ids
        return fixed_ids
    
    def __get_new_values(self, title, sort_title, genre_ids):
        from xbmc import executebuiltin
        from modules.armani_utils import get_sort_title
        dlg = Dialog()
        title = dlg.input('TITLE', title)
        if not title:
            return None
        sort_title = dlg.input('SORT TITLE', sort_title).upper()
        if not sort_title:
            return None
        alpha = sort_title[0] if sort_title[0].isalpha() else '#'
        all_genre_ids = list(self.genres.keys())
        all_genre_values = list(self.genres.values())
        genre_pre = [all_genre_ids.index(g) for g in genre_ids]
        executebuiltin('SetProperty(select_type,genres,home)')
        sel = dlg.multiselect('GENRES', all_genre_values, preselect=genre_pre)
        executebuiltin('ClearProperty(select_type,home)')
        if not sel:
            return None
        genre_ids = [all_genre_ids[i] for i in sel]
        return title, sort_title, alpha, genre_ids

    def __post_update(self):
        def _menu_create(menu_id, menu_name):
            results = [{'imdb_id': r[0], 'title': r[1], 'sort_title': r[2], 'release_date': r[3]}
                       for r in self.cursor.fetchall()]
            if not results:
                return None
        
            samples = results[0:10]
            samples.sort(key=lambda x: x['release_date'])
            samples.sort(key=lambda x: x['sort_title'])
            return {
                'id': menu_id,
                'name': menu_name,
                'where': 'WHERE db_type = "%s" AND (%s)' % (db_type, filter_string),
                'count': len(results),
                'summary': '[CR]'.join([s['title'] for s in samples])
            }

        menu = {'movies': {'genres': {}, 'decades': {}, 'alpha': {}},
                'tvshows': {'genres': {}, 'decades': {}, 'alpha': {}}}
        
        self.cursor.execute('SELECT original_language, year, genre_ids FROM media')
        results = self.cursor.fetchall()
        if not results:
            self.menu = menu
            self.settings.save_json('main_menu', self.menu)
            return
        
        languages = list(dict.fromkeys([r[0] for r in results]))
        languages.sort()
        decades = list(dict.fromkeys([10 * int(r[1] / 10) for r in results]))
        decades.sort(reverse=True)
        genre_ids = list(dict.fromkeys(', '.join([r[2] for r in results]).split(', ')))
        genre_ids.sort()
        self.in_use = {
            'genres': genre_ids,
            'decades': decades,
            'languages': [k for k, v in self.languages.items() if v in languages]
        }
        self.playlist_values = {
            'genres': [{'label': self.genres[v], 'value': v} for v in genre_ids],
            'languages': [{'label': v, 'value': v} for v in languages],
            'decades': [{'label': '%d - %d' % (d, d+9), 'value': d} for d in decades]
        }
        self.settings.save_json('in_use', self.in_use)
        self.settings.save_json('playlist_values', self.playlist_values)

        sql_select = 'SELECT imdb_id, title || " (" || year || ")", sort_title, release_date ' \
                     'FROM media WHERE db_type = ? AND %s ORDER BY RANDOM()'
        
        for db_type in ('movie', 'tvshow'):
            menu_type = 'movies' if db_type == 'movie' else 'tvshows'
            for g in self.genres:
                filter_string = 'genre_ids LIKE ' + '"%' + g + '%"'
                self.cursor.execute(sql_select % 'genre_ids LIKE ?', (db_type, '%' + g + '%'))
                menu_entry = _menu_create(g, self.genres[g])
                if menu_entry:
                    menu[menu_type]['genres'][g] = menu_entry
    
            for a in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
                filter_string = 'starting_letter = "%s"' % a
                self.cursor.execute(sql_select % 'starting_letter = ?', (db_type, a))
                menu_entry = _menu_create(a, a)
                if menu_entry:
                    menu[menu_type]['alpha'][a] = menu_entry
    
            for d in (1900, 1910, 1920, 1930, 1940, 1950, 1960, 1970, 1980, 1990, 2000, 2010, 2020, 2030):
                filter_string = 'year >= %d AND year <= %d' % (d, d + 9)
                self.cursor.execute(sql_select % 'year >= ? AND year <= ?', (db_type, d, d + 9))
                menu_entry = _menu_create(str(d), '%d - %d' % (d, d + 9))
                if menu_entry:
                    menu[menu_type]['decades'][str(d)] = menu_entry
                    menu[menu_type]['decades'][str(d)] = menu_entry
        self.menu = menu
        self.settings.save_json('main_menu', self.menu)
        self.last_update = dt.now().strftime("%Y-%m-%d %H:%M:%S")
        self.settings.save('last_update', self.last_update)
        
    def __insert_or_update(self, imdb_id: str, commit=True, session=None, title: str = None, sort_title: str = None,
                           genre_ids=None, confirm_insert=False):
        from modules.kodi_utils import notification
        from modules.armani_utils import get_sort_title
        
        def _get_tmdb(url_tail):
            api_str = '&api_key=%s' if '?' in url_tail else '?api_key=%s'
            url = 'https://api.themoviedb.org/3/' + url_tail + api_str % tmdb_api_key()
            tmdb_response = session.get(url)
            if tmdb_response.status_code != 200:
                raise ValueError('Unable to retrieve: %s - %s' % (url, tmdb_response.text))
            return tmdb_response.json()
        
        def _error(msg):
            notification(32760)
            logger('ArmaniFlix / add_entry[%s]' % imdb_id, str(msg))
        
        if not session:
            session = requests.Session()
            
        # Get IMDb data
        response = session.get('https://www.imdb.com/title/%s' % imdb_id, headers=IMDB_HEADERS)
        if response.status_code != 200:
            _error('Unable to retrieve IMDB details')
            return False
        json_text = response.text.split('{"props":{"pageProps"')[1].split('"aboveTheFoldData":')[1]
        json_text = json_text.split(',"mainColumnData":{')[0]
        imdb_data = json.loads(json_text)
        
        # Details from IMDb data
        if not title:
            title = imdb_data['titleText']['text']
        if not sort_title:
            sort_title = get_sort_title(title)
        alpha = sort_title[0] if sort_title[0].isalpha() else '#'
        if not genre_ids:
            imdb_genres = {
                'Action': 'act', 'Adult': 'adu', 'Adventure': 'adv', 'Animation': 'ani', 'Biography': 'bio',
                'Comedy': 'com', 'Crime': 'cri', 'Documentary': 'doc', 'Drama': 'dra', 'Family': 'fam',
                'Fantasy': 'fan', 'Film-Noir': 'fil', 'Game Show': 'gam', 'History': 'his', 'Horror': 'hor',
                'Music': 'muc', 'Musical': 'mus', 'Mystery': 'mys', 'News': 'new', 'Reality-TV': 'rea',
                'Romance': 'rom', 'Sci-Fi': 'sci', 'Short': 'sho', 'Sport': 'spo', 'Talk-Show': 'tal',
                'Thriller': 'thr', 'War': 'war', 'Western': 'wes'
            }
            genre_ids = [imdb_genres[g['text']] for g in imdb_data['genres']['genres']]
            genre_ids = self.__get_fixed_genres(genre_ids)
            
        db_type = 'movie' if imdb_data['titleType']['id'] in ('movie', 'tvMovie', 'short') else 'tvshow'
        media_type = 'movie' if db_type == 'movie' else 'tv'
        imdb_rating = imdb_data['ratingsSummary']['aggregateRating']
        imdb_votes = imdb_data['ratingsSummary']['voteCount']
        plot = truncate_complete_sentences(imdb_data['plot']['plotText']['plainText'])
        
        if confirm_insert:
            new_values = self.__get_new_values(title, sort_title, genre_ids)
            if not new_values:
                return False
            title, sort_title, alpha, genre_ids = new_values
        
        # Get tmdb data
        tmdb_details, tmdb_release_dates, tmdb_credits, tmdb_ratings = None, None, None, None
        try:
            tmdb_find = _get_tmdb('find/%s?external_source=imdb_id' % imdb_id)
            found = tmdb_find['movie_results'] if db_type == 'movie' else tmdb_find['tv_results']
            if not found:
                _error('TMDB ID not found')
                return False
            tmdb_id = found[0]['id']
            tmdb_details = _get_tmdb('%s/%d?language=en-US' % (media_type, tmdb_id))
            if db_type == 'movie':
                tmdb_credits = _get_tmdb('movie/%d/credits' % tmdb_id)
                tmdb_release_dates = _get_tmdb('movie/%s/release_dates' % tmdb_id)['results']
            else:
                tmdb_credits = _get_tmdb('tv/%d/aggregate_credits' % tmdb_id)
                tmdb_ratings = _get_tmdb('tv/%s/content_ratings' % tmdb_id)['results']
                
        except ValueError as e:
            _error(e)
            return False
        
        # Details from TMDb data
        original_language = self.languages[tmdb_details['original_language']]
        extra_info = {
            'genres': [self.genres[g] for g in genre_ids],
            'countries': '',
            'num_episodes': 0,
            'num_seasons': 0,
            'status': tmdb_details['status']
        }
        
        # Movie details from TMDb data
        director_jobs = ('director', 'directed by')
        writer_jobs = ('author', 'book', 'comic book', 'graphic novel', 'novel', 'original story', 'screenplay',
                       'screenplay by', 'short story', 'story', 'story by', 'writer', 'written by')
        if db_type == 'movie':
            # Movie credits
            cast = tmdb_credits['cast']
            crew = sorted(tmdb_credits['crew'], key=lambda d: d['popularity'], reverse=True)
            directors = [p for p in crew if p['job'].lower() in director_jobs]
            creators = []
            writers = [p for p in crew if p['job'].lower() in writer_jobs]
            
            release_dates = []
            for d in tmdb_release_dates:
                release_dates.extend([rd['release_date'][:10] for rd in d['release_dates']])
            release_date = min(release_dates)
            runtime = tmdb_details['runtime']
    
            release_dates = {r['iso_3166_1']: r['release_dates'] for r in tmdb_release_dates}
            if 'US' not in release_dates:
                mpaa = 'NR'
            else:
                mpaa_list = [r['certification'] for r in release_dates['US'] if r['certification']]
                mpaa = 'NR' if not mpaa_list else mpaa_list[0]
    
            extra_info['countries'] = [c['name'] for c in tmdb_details['production_countries']]
            
        # TV details from TMDb data
        else:
            # TV credits
            cast = sorted(tmdb_credits['cast'], key=lambda d: d['total_episode_count'], reverse=True)
            cast = [c for c in cast if c['order'] < 8]
            for c in cast:
                c['character'] = sorted(c['roles'], key=lambda d: d['episode_count'], reverse=True)[0][
                    'character']
            creators = [{'id': c['id'], 'name': c['name']} for c in tmdb_details.get('created_by', [])]
            directors = []
            writers = []
            for c in tmdb_credits['crew']:
                for j in c['jobs']:
                    if j['job'].lower() in director_jobs:
                        directors.append(
                            {'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
                    elif j['job'].lower() in writer_jobs:
                        writers.append({'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
            directors = [{'id': p['id'], 'name': p['name']}
                         for p in sorted(directors, key=lambda d: d['episode_count'], reverse=True)][0:2]
            writers = [{'id': p['id'], 'name': p['name']}
                       for p in sorted(writers, key=lambda d: d['episode_count'], reverse=True)][0:2]
            
            release_date = tmdb_details['first_air_date']
            if tmdb_details['episode_run_time']:
                runtime = tmdb_details['episode_run_time'][0]
            else:
                episode_details = _get_tmdb('tv/%s/season/1/episode/1?language=en-US' % tmdb_id)
                runtime = episode_details['runtime'] or 0
    
            certs = {r['iso_3166_1']: r['rating'] for r in tmdb_ratings if r['rating']}
            mpaa = 'NR' if 'US' not in certs else certs['US']
            extra_info['countries'] = [self.countries[c] for c in tmdb_details['origin_country']]
            extra_info['num_seasons'] = tmdb_details['number_of_seasons']
            extra_info['num_episodes'] = tmdb_details['number_of_episodes']

        # Finalize credits
        cast = [{'id': p['id'], 'name': p['name'], 'role': p['character'], 'order': p['order']} for p in cast]
        director = [{'id': p['id'], 'name': p['name']} for p in directors]
        writer = [{'id': p['id'], 'name': p['name']} for p in writers]
        cast = list({p['id']: p for p in cast}.values())
        cast = sorted(cast, key=lambda d: d['order'])
        director = list({p['id']: p for p in director}.values())
        writer = list({p['id']: p for p in writer}.values())
        all_credits = {
            'director': director[0:2],
            'creator': creators[0:2],
            'writer': writer[0:2],
            'cast': cast[0:8]
        }
        
        creator = [p['name'] for p in all_credits.get('creator', [])]
        director = [p['name'] for p in all_credits.get('director', [])]
        writer = [p['name'] for p in all_credits.get('writer', [])]
        cast = [p['name'] for p in all_credits.get('cast', [])]

        credit_lines = []
        credit_string = '[CR][B]%s:[/B] %s'
        if creator:
            credit_lines.append(credit_string % ('Creator', ', '.join(creator)))
        elif director:
            credit_lines.append(credit_string % ('Director', ', '.join(director)))
        if cast:
            credit_lines.append(credit_string % ('Stars', ', '.join(cast[0:3])))
        plot += '[CR]' + ''.join(credit_lines)
        
        search_words = [title, sort_title] + creator + director + writer + cast
        search_words = '|'.join(list(dict.fromkeys([_search_string(w) for w in search_words])))

        self.cursor.execute(
            'INSERT OR REPLACE INTO media VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            (imdb_id, db_type, tmdb_id, title, sort_title, alpha, mpaa, runtime, imdb_rating, imdb_votes, plot,
             original_language, release_date, int(release_date[:4]), ', '.join(genre_ids), search_words,
             json.dumps(extra_info), str(date.today())))
        if commit:
            self.conn.commit()
        return True
    
    def get_meta_list(self, where="", where_values=None, sort_order='sort_title, release_date', limit:int = 0):
        if limit > 0:
            sort_order += ' LIMIT %d' % limit
        if where_values is None:
            where_values = ()
        
        try:
            self.cursor.execute(f"""
                SELECT
                    imdb_id, db_type, tmdb_id, title, sort_title, mpaa, runtime, rating, votes, plot,
                    original_language, release_date, year, genre_ids, search_string, extra_info,
                    date_added, starting_letter
                FROM
                    media
                {where}
                ORDER BY
                    {sort_order}
            """, where_values)
        except sqlite3.Error:
            return []
        
        meta = []
        for row in self.cursor.fetchall():
            extra_info = json.loads(row[15])
            
            meta.append({
                'imdb_id': row[0],
                'db_type': row[1],
                'media_type': row[1],
                'tmdb_id': row[2],
                'title': row[3] if row[10] == 'English' else '%s [COLOR grey][%s][/COLOR]' % (row[3], row[10]),
                'rootname': '%s (%d)' % (row[3], row[12]),
                'sort_title': row[4],
                'starting_letter': row[17],
                'mpaa': row[5],
                'duration': row[6],
                'rating': row[7],
                'votes': row[8],
                'plot': row[9],
                'original_language': row[10],
                'premiered': row[11],
                'year': str(row[12]),
                'decade': int(row[12] / 10) * 10,
                'genre_ids': row[13],
                'search_string': row[14],
                'original_title': row[3],
                'date_added': row[16],
                'genre': ', '.join(extra_info['genres']),
                'country': extra_info['countries'],
                'cast': '',
                'director': '',
                'writer': '',
                'keywords': '',
                'total_seasons': extra_info['num_seasons'],
                'total_aired_eps': extra_info['num_episodes']
            })
        return meta

    def fetch(self, params, limit=None):
        db_types = params.get('db_types', 'movie, movie_set, tvshow')
        values = [t.strip().lower() for t in db_types.split(',')]
        where = '(%s)' % ' OR '.join(['db_type = ?'] * len(values))
    
        if 'years' in params:
            years = params['years'].split('-', maxsplit=1)
            if len(years) == 1:
                year_where = '(year = ?)'
                year_values = [int(years)]
            else:
                year_where = "(year >= ? AND year <= ?)"
                year_values = [int(years[0]), int(years[1])]
        
            values += year_values
            where += ' AND %s' % year_where
    
        if 'alpha' in params:
            values += [params['alpha'].upper()]
            where += ' AND starting_letter = ?'
    
        if 'genres' in params:
            genre_ids = params['genres'].split(',')
            values += ['%' + g.strip() + '%' for g in genre_ids]
            where += ' AND %s' % ' AND '.join(['genre_ids LIKE ?']*len(genre_ids))
    
        if 'query' in params:
            queries = params['query'].split(',')
            values += ['%' + _search_string(q.strip()) + '%' for q in queries]
            where += ' AND (%s)' % ' OR '.join(['search_string LIKE ?']*len(queries))
    
        sort_order = params.get('sort_order', 'sort_title, release_date')
        if 'limit' not in sort_order.lower():
            sort_order += ' LIMIT %d' % (limit or FETCH_LIMIT)
        return self.get_meta_list('WHERE %s' % where, values, sort_order)

    def can_fetch(self, params):
        return len(self.fetch(params, 1)) > 0
    
    def get_meta_tmdb(self, db_type, tmdb_id):
        results = self.get_meta_list('WHERE db_type = ? AND tmdb_id = ?', (db_type, tmdb_id))
        return {} if not results else results[0]
    
    def get_meta_imdb(self, imdb_id):
        results = self.get_meta_list('WHERE imdb_id = ?', (imdb_id,))
        return {} if not results else results[0]
    
    def get_meta_action(self, action):
        from caches.armani_users import ArmaniUsers
        from caches.favorites import Favorites
        from modules.watched_status import armani_get_watch_history
        from modules.kodi_utils import get_armani_user
        armani_users = ArmaniUsers()
        
        results = []
        if action == 'favorites':
            imdb_ids = armani_users.get_favorites()
            where = 'WHERE imdb_id IN (%s)' % ', '.join(['?'] * len(imdb_ids))
            results = self.get_meta_list(where, imdb_ids)
        elif action == 'watched':
            results = [self.get_meta_tmdb(r[1], r[0]) for r in armani_get_watch_history()]
        elif action == 'playlist':
            results = self.get_meta_playlist()
        
        return [r for r in results if r]
    
    def get_meta_playlist(self):
        from modules.watched_status import armani_remove_watched, armani_remove_unwatched
        from caches.armani_users import ArmaniPlaylist
        playlist = ArmaniPlaylist().get_playlist()
        media_types = playlist.get('media_types') or ['movie']
        watched_status = playlist.get('watched_status') or ['unwatched', 'watched']

        filters = []
        values = []
        filters.append('db_type IN (%s)' % ', '.join(['?'] * len(media_types)))
        values.extend(media_types)
        
        if playlist.get('genres_all'):
            filters.append(' AND '.join(['genre_ids LIKE ?'] * len(playlist['genres_all'])))
            values.extend(['%' + g + '%' for g in playlist['genres_all']])
        if playlist.get('genres_any'):
            filters.append(' OR '.join(['genre_ids LIKE ?'] * len(playlist['genres_any'])))
            values.extend(['%' + g + '%' for g in playlist['genres_any']])
        if playlist.get('genres_none'):
            filters.append(' AND '.join(['genre_ids NOT LIKE ?'] * len(playlist['genres_none'])))
            values.extend(['%' + g + '%' for g in playlist['genres_none']])
        if playlist.get('decades'):
            filters.append(' OR '.join(['(year >= ? AND year <= ?)'] * len(playlist['decades'])))
            for d in playlist['decades']:
                values.extend([int(d), int(d) + 9])
        if playlist.get('languages'):
            filters.append(' OR '.join(['original_language = ?'] * len(playlist['languages'])))
            values.extend(playlist['languages'])
        if playlist.get('search_any'):
            filters.append(' OR '.join(['search_string LIKE ?'] * len(playlist['search_any'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_any']])
        if playlist.get('search_all'):
            filters.append(' AND '.join(['search_string LIKE ?'] * len(playlist['search_all'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_all']])
        if playlist.get('search_none'):
            filters.append(' AND '.join(['search_string NOT LIKE ?'] * len(playlist['search_none'])))
            values.extend(['%' + _search_string(s) + '%' for s in playlist['search_none']])

        s_filter = '' if not filters else 'WHERE %s' % ' AND '.join('(%s)' % f for f in filters)
        order = SIZE_FILTERS[playlist.get('size_filter', 'votes_desc')]['order']
        
        results = self.get_meta_list(s_filter, values, order)
        
        if 'unwatched' not in watched_status:
            results = armani_remove_unwatched(results)
        elif 'watched' not in watched_status:
            results = armani_remove_watched(results)
        else:
            results = armani_remove_watched(results, playlist['created'])

        results = results[0:PLAYLIST_LIMIT]
        results.sort(key=lambda x: x['premiered'])
        results.sort(key=lambda x: x['sort_title'])
        return results
    
    def get_header(self, main_key, category_key=None, sort_type=""):
        content_type, category = main_key.split('_')
        h = [MEDIA_TYPES[content_type], CATEGORIES[category]]
        header = '%s / %s' % (h[0], h[1])
        if category_key is not None:
            try:
                header += ' / %s' % self.menu[content_type][category][category_key]['name']
                if sort_type in SORTS:
                    header += ' [%s]' % SORTS[sort_type].lower()
            except KeyError:
                header = '%s / %s / Empty' % (h[0], h[1])
        return header
    
    def get_list(self, main_key):
        content_type, category = main_key.split('_')
        m = self.menu[content_type][category]
        
        return {k: {'key': k, 'title': v['name'], 'summary': v['summary'],
                    'count': v['count'], 'where': v['where']} for k, v in m.items()}
    
    def get_content(self, params):
        content_type, category = params['action'].split('_')
        m = self.menu[content_type][category].get(str(params['value'])) or {}
        if not m:
            return []
        
        order_str = 'sort_title, release_date'
        if 'order' in params:
            order_str = params['order']
            if 'limit' in params:
                order_str += ' LIMIT ' + params['limit']
        return self.get_meta_list(m['where'], sort_order=order_str)
    
    
armani = ArmaniCache()
