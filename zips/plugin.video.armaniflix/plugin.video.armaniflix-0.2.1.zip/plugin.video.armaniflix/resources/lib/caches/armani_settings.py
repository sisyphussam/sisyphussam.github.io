import sqlite3
from xbmcvfs import translatePath, exists, mkdir
from xbmc import executebuiltin
from xbmcgui import Dialog
from modules.kodi_utils import close_all_dialog
import json

PLUGIN_VERSION = '0.1.93'
SETTINGS_DB = translatePath('special://profile/addon_data/plugin.video.armaniflix/armani_settings.db')


def kodi_log():
    # Open reverse log in text viewer
    from modules.kodi_utils import exists
    log_file = translatePath('special://logpath/kodi.log')
    if not exists(log_file):
        return
    with open(log_file, 'r', errors="ignore") as fp:
        Dialog().textviewer('Kodi Log', '\n'.join(reversed(fp.readlines())))
        

def clear_caches():
    from modules.kodi_utils import favorites_db, metacache_db, maincache_db, debridcache_db, notification
    dbcon = sqlite3.connect(favorites_db)
    dbcon.execute('DELETE FROM favourites')  # ArmaniFlix doesn't use them anyway
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(metacache_db)
    dbcon.execute('DELETE FROM metadata')
    dbcon.execute('DELETE FROM season_metadata')
    dbcon.execute('DELETE FROM function_cache')
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(maincache_db)
    dbcon.execute('DELETE FROM maincache')
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(debridcache_db)
    dbcon.execute('DELETE FROM debrid_data')
    dbcon.commit()
    dbcon.close()
    notification('Cleared all caches')


class ArmaniSettings:
    def __init__(self):
        self.conn = sqlite3.connect(SETTINGS_DB)
        self.cursor = self.conn.cursor()
        
    def check(self):
        pass
        
    def get(self, setting_id: str):
        self.cursor.execute('SELECT value FROM settings WHERE id = ?', (setting_id,))
        result = self.cursor.fetchone()
        if not result:
            return None
        return result[0]
    
    def get_json(self, setting_id: str):
        return json.loads(self.get(setting_id) or "{}")
    
    def is_source(self, imdb_id, hash_string):
        self.cursor.execute('SELECT COUNT(*) FROM sources WHERE imdb_id = ? AND hash = ?', (imdb_id, hash_string))
        result = self.cursor.fetchone()
        return result[0] > 0
    
    def set_source(self, imdb_id, hash_string):
        self.cursor.execute('INSERT OR REPLACE INTO sources (imdb_id, hash) VALUES(?, ?)', (imdb_id, hash_string))
        self.conn.commit()
        
    def is_resetting(self, value: str):
        return value in self.__get_reset_list()
        
    def add_reset(self, value: str):
        reset_list = self.__get_reset_list()
        if value in reset_list:
            return
        reset_list.append(value)
        self.save('reset', ','.join(reset_list))
        
    def remove_reset(self, value):
        reset_list = self.__get_reset_list()
        if value not in reset_list:
            return
        reset_list.remove(value)
        self.save('reset', ','.join(reset_list))
        
    def __get_reset_list(self):
        self.cursor.execute('SELECT reset FROM settings')
        result = self.cursor.fetchone()
        return [] if not result else result[0].split(',')
        
    def get_user(self):
        return self.get('user_id'), self.get('user_name')
    
    def set_user(self, user_id: str, user_name: str):
        self.save('user_id', user_id)
        self.save('user_name', user_name)
        
    def save(self, setting_id: str, setting_value: str):
        self.cursor.execute('INSERT OR REPLACE INTO settings(id, value) VALUES(?, ?)', (setting_id, setting_value))
        self.conn.commit()
        
    def save_json(self, setting_id: str, setting_json: dict):
        self.save(setting_id, json.dumps(setting_json))