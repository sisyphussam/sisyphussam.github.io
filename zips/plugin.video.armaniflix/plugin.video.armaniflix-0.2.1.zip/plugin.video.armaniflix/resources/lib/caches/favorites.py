# -*- coding: utf-8 -*-
from modules.kodi_utils import database, favorites_db, get_armani_user
from modules.kodi_utils import logger

INSERT_FAV = 'INSERT INTO favourites VALUES (?, ?, ?, ?, ?)'
DELETE_FAV = 'DELETE FROM favourites where armani_user=? and db_type=? and tmdb_id=?'
SELECT_ONE_FAV = 'SELECT tmdb_id, title FROM favourites WHERE armani_user=? and db_type = ? and tmdb_id=?'
SELECT_ALL_FAV = 'SELECT tmdb_id, title, db_type FROM favourites WHERE armani_user=? and db_type=? ORDER BY sort_title'
DELETE_TYPE = 'DELETE FROM favourites WHERE armani_user=? and db_type=?'

class Favorites:
	def __init__(self):
		self.make_database_connection()
		self.set_PRAGMAS()

	def set_favourite(self, media_type, tmdb_id, title):
		try:
			sort_title = title
			articles = ['The ', 'A ', 'An ']
			for article in articles:
				if title.startswith(article):
					sort_title = title[len(article):]
					break
			self.dbcur.execute(INSERT_FAV, (get_armani_user(), media_type, str(tmdb_id), title, sort_title))
			return True
		except: return False

	def delete_favourite(self, media_type, tmdb_id):
		try:
			self.dbcur.execute(DELETE_FAV, (get_armani_user(), media_type, str(tmdb_id)))
			return True
		except: return False
		
	def is_favorite(self, db_type, tmdb_id):
		try:
			self.dbcur.execute(SELECT_ONE_FAV, (get_armani_user(), db_type, str(tmdb_id)))
		except database.Error as e:
			logger("ERR", e)
		result = self.dbcur.fetchall()
		return len(result) > 0
		
	def get_all_favorites(self, limit: int = 0):
		s_limit = '' if limit < 1 else 'LIMIT %d' % limit
		self.dbcur.execute("""
			SELECT tmdb_id, db_type FROM favourites
			WHERE armani_user = ? AND db_type IN (?, ?, ?)
			ORDER BY sort_title %s
		""" % s_limit, (get_armani_user(), 'movie', 'tvshow', 'movie_set'))
		result = self.dbcur.fetchall()
		return [(i[0], i[1]) for i in result]
	
	def has_favorite(self):
		return len(self.get_all_favorites(1)) > 0
		
	def get_favorite_movies(self):
		self.dbcur.execute("""SELECT tmdb_id, title, db_type FROM favourites
		WHERE armani_user=? and (db_type=? or db_type=?)
		ORDER BY sort_title""", (get_armani_user(), 'movie', 'movie_set'))
		result = self.dbcur.fetchall()
		result = [{'tmdb_id': str(i[0]), 'title': str(i[1]), 'db_type': str(i[2])} for i in result]
		return result

	def get_favorites(self, media_type):
		if media_type == 'movie': return self.get_favorite_movies();
	
		self.dbcur.execute(SELECT_ALL_FAV, (get_armani_user(), media_type))
		result = self.dbcur.fetchall()
		result = [{'tmdb_id': str(i[0]), 'title': str(i[1]), 'db_type': str(i[2])} for i in result]
		return result

	def clear_favorites(self, media_type):
		self.dbcur.execute(DELETE_TYPE, (get_armani_user(), media_type))
		self.dbcur.execute('VACUUM')

	def make_database_connection(self):
		self.dbcon = database.connect(favorites_db, timeout=40.0, isolation_level=None)

	def set_PRAGMAS(self):
		self.dbcur = self.dbcon.cursor()
		self.dbcur.execute('''PRAGMA synchronous = OFF''')
		self.dbcur.execute('''PRAGMA journal_mode = OFF''')

favorites = Favorites()
