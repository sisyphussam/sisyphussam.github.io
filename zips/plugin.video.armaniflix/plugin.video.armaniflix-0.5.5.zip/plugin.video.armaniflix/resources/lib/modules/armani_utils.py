import re
import unicodedata

import modules.player
from modules.kodi_utils import exists, mkdir, delete, notification, logger
from xbmcgui import Dialog
from xbmcvfs import translatePath, listdir

ARMANI_DATA_PATH = 'special://masterprofile/addon_data/plugin.video.armaniflix/%s'
KODI_SETTINGS = translatePath('special://profile/guisettings.xml')

LANGUAGE_IDS = {
    'Arabic': ('12', 'ar', 'ara'),
    'Cantonese': ('17', 'cn', 'zh', 'chi'),
    'Danish': ('24', 'da', 'dan'),
    'English': ('2', 'en', 'eng'),
    'French': ('8', 'fr', 'fre'),
    'German': ('5', 'de', 'ger', 'deu'),
    'Greek': ('16', 'el', 'ell'),
    'Italian': ('9', 'it', 'ita'),
    'Japanese': ('11', 'ja', 'jpn'),
    'Korean': ('4', 'ko', 'kor'),
    'Mandarin': ('17', 'cn', 'zh', 'chi'),
    'Norwegian': ('3', 'no', 'nb', 'nn', 'nor'),
    'Norwegian BokmÃ¥l': ('3', 'no', 'nb', 'nn', 'nor'),
    'Norwegian Nynorsk': ('3', 'no', 'nb', 'nn', 'nor'),
    'Persian': ('52', 'fa', 'per'),
    'Polish': ('26', 'pl', 'pol'),
    'Portuguese': ('32', 'pt', 'por'),
    'Russian': ('27', 'ru', 'rus'),
    'Spanish': ('28', 'es', 'spa'),
    'Swedish': ('25', 'sv', 'swe')
}


def select_player_language(source_hash: str):
    from caches.armani_settings import ArmaniSettings
    from xbmc import Player
    
    settings = ArmaniSettings()
    player = Player()
    if not player.isPlayingVideo():
        return
    
    stream_index = settings.set_audio_stream(source_hash)
    if stream_index < 0:
        return
    player.setAudioStream(stream_index)
    

def init_player_language(fen_player: modules.player.FenPlayer, original_language):
    from caches.armani_settings import ArmaniSettings

    settings = ArmaniSettings()

    audio_streams = fen_player.getAvailableAudioStreams()
    if len(audio_streams) < 2:
        return
        
    source = fen_player.playing_item
    saved = settings.get_audio_stream(source['hash'])
    if not saved:
        stream_index = 0
        if original_language in LANGUAGE_IDS:
            language_ids = LANGUAGE_IDS[original_language]
            for i in range(len(audio_streams)):
                if audio_streams[i] in language_ids:
                    stream_index = i
                    break
        saved = settings.save_audio_stream(source['hash'], source['display_name'], audio_streams, stream_index)
    
    fen_player.setAudioStream(saved['stream_index'])
    notification('Audio: %s' % saved['audio_streams'][saved['stream_index']], 2000)
    

def get_file_path(file):
    return translatePath(ARMANI_DATA_PATH % file)


def str_to_int(str_number: str, default=0):
    str_number = str_number.replace(',', '')
    try:
        i = int(str_number)
    except ValueError:
        i = default
    return i


def current_date() -> str:
    from datetime import date
    return date.today().strftime('%Y-%m-%d')


def int_to_bounds(value: int, min_value: int, max_value: int) -> int:
    return max(min(value, max_value), min_value)


def get_language_items(multi=True):
    from caches.armani_media import armani
    languages = {v['id']: v for v in armani.get_existing_languages() if v['count'] > 1 and v['id'] != 'en'}
    items = []
    if any(i in languages for i in ('cn', 'zh')):
        items.append({'name': 'Chinese', 'where': 'original_language IN ("Cantonese","Mandarin")'})
    if any(i in languages for i in ('no', 'nw')):
        items.append({'name': 'Norwegian', 'where': 'original_language LIKE "Norwegian%"'})
    
    languages = [v for v in languages.values() if v['id'] not in ('en', 'cn', 'zh', 'no', 'nw')]
    [items.append({'name': v['name'], 'where': 'original_language == "%s"' % v['name']}) for v in languages]
    items.sort(key=lambda k: k['name'])
    items = [(i['name'], i['where']) for i in items]
    if multi:
        items.insert(0, ('English', 'original_language == "English"'))
    else:
        items.insert(0, ('Foreign', 'original_language != "English"'))
        items.insert(0, ('English', 'original_language == "English"'))
        items.insert(0, ('All', ''))
    return {i[0]: i[1] for i in items}


def kodi_log():
    """ View Kodi's log sorted by descending timestamp """
    log_file = translatePath('special://logpath/kodi.log')
    if not exists(log_file):
        return
    with open(log_file, 'r', errors="ignore") as fp:
        Dialog().textviewer('Kodi Log', '\n'.join(reversed(fp.readlines())))


def clear_caches():
    """ Clear Fen's caches (Kodi caches will be cleared in a future update). """
    import sqlite3
    from modules.kodi_utils import favorites_db, metacache_db, maincache_db, debridcache_db, external_db, notification
    dbcon = sqlite3.connect(favorites_db)
    dbcon.execute('DELETE FROM favourites')  # ArmaniFlix doesn't use them anyway
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(metacache_db)
    dbcon.execute('DELETE FROM metadata')
    dbcon.execute('DELETE FROM season_metadata')
    dbcon.execute('DELETE FROM function_cache')
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(maincache_db)
    dbcon.execute('DELETE FROM maincache')
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(debridcache_db)
    dbcon.execute('DELETE FROM debrid_data')
    dbcon.commit()
    dbcon.close()

    dbcon = sqlite3.connect(external_db)
    dbcon.execute('DELETE FROM results_data')
    dbcon.commit()
    dbcon.close()
    
    notification('Cleared all caches')


def keymap_manager():
    """ Download recommended keymaps (keyboard, touch, and remote) from GitHub """
    import requests
    
    url = 'https://sisyphussam.github.io/defaults/armani_maps.xml'
    dir = translatePath('special://profile/keymaps/')
    if not exists(dir):
        mkdir(dir)
        
    files = [f for f in listdir(dir)[1] if f.lower().endswith('.xml')]
    
    if not Dialog().yesno('Download Keymaps', 'Download the latest keymaps from GitHub?[CR](All current map files will be deleted!)'):
        return
        
    for f in files:
        delete(translatePath('special://profile/keymaps/' + f))
        
    response = requests.get(url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"})
    if response.status_code != 200:
        notification('Failed to download keymaps')
        return
    with open(translatePath('special://profile/keymaps/armani_maps.xml'), 'w') as fp:
        fp.write(response.text)
    notification('Success!')
    

def armani_meta_convert(meta, armani_meta_all):
    armani_meta = armani_meta_all.get(meta.get('imdb_id'), {})
    if not armani_meta:
        meta['plot'] = plot_from_meta(meta)
        return meta
    
    meta['title'] = armani_meta['title']
    meta['plot'] = armani_meta['overview']
    meta['rating'] = armani_meta['imdb_rating']
    meta['votes'] = armani_meta['imdb_votes']
    meta['mpaa'] = armani_meta['mpaa']
    meta['premiered'] = armani_meta['release_date']
    meta['genre'] = armani_meta['genres']
    
    return meta
    

def truncate_complete_sentences(string_to_truncate, max_len=300):
    if len(string_to_truncate) > max_len:
        # Truncate
        string_to_truncate = string_to_truncate[0:max_len]
        # Remove the last incomplete sentence
        period_index = str(string_to_truncate).rfind('.')
        if period_index > -1:
            string_to_truncate = string_to_truncate[0:period_index + 1]
        string_to_truncate += '...'
    return string_to_truncate


def plot_from_meta(meta, default_plot=""):
    plot = meta.get('plot', '') or meta.get('overview', '') or default_plot
    plot_string = truncate_complete_sentences(plot)

    # Add director and stars
    director = meta.get('director', '')
    stars = ', '.join([c['name'] for c in meta.get('cast', [])][0:3])
    if director or stars:
        plot_string += '[CR][CR]'
        if director:
            plot_string += '[B]Director:[/B] %s' % director
        if stars:
            if director:
                plot_string += '[CR]'
            plot_string += '[B]Stars:[/B] %s' % stars
    return plot_string


def get_sort_title(title):
    title = title.upper()
    # Sort title initially is the normalized title (accents replaced)
    s_title = unicodedata.normalize('NFD', title)
    s_title = s_title.encode('ascii', 'ignore')
    s_title = s_title.decode("utf-8")
    s_title = re.sub(r'^[^A-Z\d]*', '', s_title)
    s_title = re.sub(r'^(A |AN |THE )', '', s_title, flags=re.IGNORECASE)
    s_title = re.sub(r'^[^A-Z\d]*', '', s_title)
    
    return title if not s_title else s_title


def get_search_string(s: str):
    s = s.lower()
    s = unicodedata.normalize('NFD', s)
    s = s.encode('ascii', 'ignore')
    s = s.decode("utf-8")
    s = re.sub(r'[^A-Za-z\d]+', '', s)
    return s
