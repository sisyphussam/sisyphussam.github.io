import sqlite3
import json

from xbmcvfs import translatePath
from xbmcgui import Dialog, ListItem
from xbmc import executebuiltin

from modules.kodi_utils import logger, notification, kodi_refresh, close_all_dialog
from caches.armani_settings import ArmaniSettings
from datetime import datetime

USER_DB = translatePath('special://profile/addon_data/plugin.video.armaniflix/armani_users.db')
WATCHED_PERCENT = 90

HEADERS = {
    'genres_any': 'INCLUDE ANY GENRE',
    'genres_all': 'INCLUDE ALL GENRES',
    'genres_none': 'EXCLUDE GENRES'
}


class ArmaniPlaylist:
    def __init__(self):
        self.settings = ArmaniSettings()
        self.conn = sqlite3.connect(USER_DB)
        self.cursor = self.conn.cursor()
        self.user_id = self.settings.get('user_id')
        self.user_name = self.settings.get('user_name')
        self.in_use = self.settings.get_json('in_use')
        self.genres = self.settings.get_json('genres')
        self.languages = self.settings.get_json('languages')
        self.playlist = self.get_playlist()
        self.dialog = Dialog()
        self.menu_options = {
            'reset': {'label': '[COLOR lightyellow][RESET][/COLOR]', 'info': 'Use the default playlist'},
            'media_types': {'label': 'Media Types', 'info': 'Include movies and/or TV shows', 'preselect': []},
            'watched_status': {'label': 'Watched Status', 'info': 'Include watched and/or unwatched content',
                               'preselect': []},
            'decades': {'label': 'Decades of Release', 'info': 'Match any selected decades', 'preselect': []},
            'languages': {'label': 'Original Languages', 'info': 'Match any selected languages', 'preselect': []},
            'genres_any': {'label': 'Genres (any)', 'info': 'Match any selected genres', 'preselect': []},
            'genres_all': {'label': 'Genres (all)', 'info': 'Match every selected genre', 'preselect': []},
            'genres_none': {'label': 'Genres (exclude)', 'info': 'Exclude selected genres', 'preselect': []},
            'search_any': {'label': 'Keywords (any)', 'info': 'Match any entered keywords'},
            'search_all': {'label': 'Keywords (all)', 'info': 'Match every entered keyword'},
            'search_none': {'label': 'Keywords (exclude)', 'info': 'Exclude entered keywords'}
        }
        
    def start(self):
        from indexers.armani import ArmaniMenu
        menu = ArmaniMenu('Playlist Editor')
        for k, data in self.menu_options.items():
            label = data['label'] if not self.playlist.get(k) else '[COLOR selected]%s[/COLOR]' % data['label']
            menu.add_item(k, label, data['info'])
            
        action = menu.select()
        if action:
            if action == 'reset':
                self.playlist = {}
                self.save_playlist()
                kodi_refresh()
            else:
                self.modify(action)
            self.start()
        
    def modify(self, key):
        executebuiltin('SetProperty(select_type,playlist,home)')
        items = []
        if not key in self.playlist:
            self.playlist[key] = []
            
        heading = self.menu_options[key]['label']
        info = self.menu_options[key]['info']
        
        if key == 'media_types':
            items = [
                {'label': 'Movies', 'value': 'movie'},
                {'label': 'TV Shows', 'value': 'tvshow'},
            ]
        elif key == 'watched_status':
            items = [
                {'label': 'Unwatched', 'value': 'unwatched'},
                {'label': 'Watched', 'value': 'watched'},
            ]
        elif key == 'decades':
            items = [{'label': '%d - %d' % (d, d + 9), 'value': d} for d in self.in_use['decades']]
        elif key == 'languages':
            languages = sorted([v for k, v in self.languages.items() if k in self.in_use['languages']])
            items = [{'label': lang, 'value': lang} for lang in languages]
        elif key.startswith('genres'):
            items = [{'label': v, 'value': k} for k, v in self.genres.items() if k in self.in_use['genres']]
        elif key.startswith('search'):
            d = ', '.join(self.playlist.get(key))
            t = Dialog().input('%s[CR][I]Use commas to delimit multiple terms[/I]' % heading, d).strip()
            self.playlist[key] = [] if not t else [s.strip() for s in t.split(',')]
            self.save_playlist()
            close_all_dialog()
            kodi_refresh()
            
        if not key.startswith('search'):
            values = [i['value'] for i in items]
            executebuiltin('SetProperty(select_info,%s,home)' % info)
            logger('values', str(values))
            logger('playlist', str(self.playlist.get(key)))
            preselect = [values.index(v) for v in self.playlist.get(key) if v in values]
            logger('pre', str(preselect))
            sel = Dialog().multiselect(heading, [i['label'] for i in items], preselect=preselect)
            if sel is not None:
                self.playlist[key] = [items[i]['value'] for i in sel]
                self.save_playlist()
                close_all_dialog()
                kodi_refresh()
        executebuiltin('ClearProperty(select_type,home)')
        executebuiltin('ClearProperty(select_info,home)')
        
    def get_playlist(self):
        self.cursor.execute('SELECT json FROM playlists WHERE user_id = ?', (self.user_id,))
        result = self.cursor.fetchone()
        if not result:
            return {'created': datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        return json.loads(result[0])

    def save_playlist(self):
        self.playlist['created'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.cursor.execute('INSERT OR REPLACE INTO playlists(user_id, json) VALUES(?, ?)',
                            (self.user_id, json.dumps(self.playlist)))
        self.conn.commit()


class ArmaniUsers:
    def __init__(self):
        self.conn = sqlite3.connect(USER_DB)
        self.cursor = self.conn.cursor()
        self.settings = ArmaniSettings()
        self.user_id = int(self.settings.get('user_id') or '-1')
        self.user_name = self.settings.get('user_name')
        
    def check(self):
        dlg = Dialog()
        self.cursor.execute('SELECT id, username FROM users ORDER BY username')
        results = self.cursor.fetchall()
        if not results:
            for t in ('playlists', 'history', 'favorites'):
                self.cursor.execute('DELETE FROM %s' % t)
            self.conn.commit()
            while 1:
                dlg.ok('Welcome to ArmaniFlix', 'A user must be created before you can begin. Press OK to proceed.')
                if self.add_user():
                    return
        else:
            existing_ids = [r[0] for r in results]
            if self.user_id not in existing_ids:
                self.user_id = results[0][0]
                self.user_name = results[0][1]
                self.settings.set_user(self.user_id, self.user_name)
                
            placeholders = ', '.join(['?'] * len(existing_ids))
            for t in ('playlists', 'history', 'favorites'):
                self.cursor.execute('DELETE FROM %s WHERE user_id NOT IN (%s)' % (t, placeholders), existing_ids)
            self.conn.commit()
            self.__update_home_properties()
            #self.select_user()
        
    def select_user(self) -> bool:
        """ Prompts for a username and PIN (if applicable) and attempts to log in.

        Returns: True if the login was successful, False otherwise
        """
        dlg = Dialog()
        
        self.cursor.execute('SELECT id, username, pin FROM users ORDER BY username')
        results = self.cursor.fetchall()
        
        ids = [r[0] for r in results]
        labels = [r[1] for r in results] + ['[COLOR lightyellow][NEW USER][/COLOR]']
        preselect = -1 if not self.user_id in ids else ids.index(self.user_id)
        index = dlg.select("Who's Watching?", labels, preselect=preselect)
        if index < 0:
            return False
        
        # Add a new user
        if index == len(results):
            return self.add_user()
        
        user_id, username, pin = results[index]
        
        # Current user doesn't need to login again
        if user_id == self.user_id:
            return True
        
        if pin and pin != dlg.numeric(0, 'User PIN (optional)', bHiddenInput=True):
            dlg.ok('Incorrect PIN', 'You did not enter the correct PIN for [B]%s[/B].' % username.upper())
            return False
                
        self.user_id = user_id
        self.settings.set_user(user_id, username)
        self.__update_home_properties()
        return True
        
    def add_user(self) -> bool:
        """ Create a new user.

        Returns: True if successful, False otherwise
        """
        dlg = Dialog()
    
        while 1:
            user_name = dlg.input('What is your desired username?').strip()
            if not user_name:
                return False
            self.cursor.execute('SELECT * FROM users WHERE username LIKE ?', (user_name,))
            if not self.cursor.fetchall():
                break
            if not dlg.yesno('Invalid User Name', 'That username is already taken. Try again?'):
                return False
    
        user_pin = dlg.numeric(0, 'Enter a PIN (optional)', bHiddenInput=True)
        if not user_pin:
            self.cursor.execute('INSERT INTO users(username) VALUES(?)', (user_name,))
        else:
            self.cursor.execute('INSERT INTO users(username,pin) VALUES(?,?)', (user_name, int(user_pin)))
        self.conn.commit()
        self.user_id = self.cursor.lastrowid
        self.settings.set_user(self.cursor.lastrowid, user_name)
        self.__update_home_properties()
        return True
    
    def edit_user(self) -> bool:
        self.cursor.execute('SELECT username, pin FROM users WHERE id = ?', (self.user_id,))
        user_name, user_pin = self.cursor.fetchone()
        dlg = Dialog()
        
        if user_pin and user_pin != dlg.numeric(0, 'Enter PIN', bHiddenInput=True):
            notification('Invalid PIN')
            return False
        
        user_name = dlg.input('Change your name', user_name).strip()
        if not user_name:
            return False
        user_pin = dlg.numeric(0, 'Change your PIN', user_pin, True).strip()
        self.cursor.execute('UPDATE users SET username = ?, pin = ? WHERE id = ?', (user_name, user_pin, self.user_id))
        self.conn.commit()
        self.user_name = user_name
        self.settings.set_user(str(self.user_id), self.user_name)
        self.__update_home_properties()
    
    def is_favorite(self, imdb_id):
        self.cursor.execute('SELECT * FROM favorites WHERE user_id = ? AND imdb_id = ?', (self.user_id, imdb_id))
        return len(self.cursor.fetchall()) > 0
    
    def has_favorite(self):
        self.cursor.execute('SELECT COUNT(*) FROM favorites WHERE user_id = ?', (self.user_id,))
        return self.cursor.fetchone()[0] > 0
    
    def get_favorites(self):
        self.cursor.execute('SELECT imdb_id FROM favorites WHERE user_id = ?', (self.user_id,))
        results = self.cursor.fetchall()
        if not results:
            return []
        return [r[0] for r in results]
    
    def add_favorite(self, imdb_id):
        if self.user_id == -1:
            return
        self.cursor.execute('INSERT OR IGNORE INTO favorites(user_id, imdb_id) VALUES(?, ?)', (self.user_id, imdb_id))
        self.conn.commit()
        notification('Added', 2000)
        kodi_refresh()
        
    def remove_favorite(self, imdb_id):
        if self.user_id == -1:
            return
        self.cursor.execute('DELETE FROM favorites WHERE user_id = ? AND imdb_id = ?', (self.user_id, imdb_id))
        self.conn.commit()
        notification('Removed', 2000)
        kodi_refresh()
        
    def get_history(self):
        self.cursor.execute('SELECT imdb_id FROM history ORDER BY last_watched DESC WHERE user_id = ?', (self.user_id,))
        results = self.cursor.fetchall()
        if not results:
            return []
        return [r[0] for r in results]
        
    def update_history(self, imdb_id):
        if self.user_id == -1:
            return
        self.cursor.execute('INSERT OR REPLACE INTO history(user_id, imdb_id, last_watched) VALUES(?, ?, ?)',
                            (self.user_id, imdb_id, str(datetime.now())))
        self.conn.commit()
        
    def get_playlist(self):
        self.cursor.execute('SELECT json FROM playlists WHERE user_id = ?', (self.user_id,))
        result = self.cursor.fetchone()
        if not result:
            return {}
        return json.loads(result[0])
        
    def save_playlist(self, data: dict):
        if self.user_id == -1:
            return
        self.cursor.execute('INSERT OR REPLACE INTO playlists(user_id, json) VALUES(?, ?)',
                            (self.user_id, json.dumps(data)))
        self.conn.commit()
        
    def watched_list(self):
        self.cursor.execute('SELECT imdb_id FROM progress WHERE user_id = ?')
        results = self.cursor.fetchall()
        if not results:
            return []
        return [r[0] for r in results]
        
    def set_movie_progress(self, imdb_id, progress=WATCHED_PERCENT):
        if self.user_id == -1:
            return
        
        self.cursor.execute('UPDATE progress SET progress = ? WHERE user_id = ? AND imdb_id = ? ',
                            (progress, self.user_id, imdb_id))
        self.conn.commit()
        self.update_history(imdb_id)

    def set_season_progress(self, imdb_id, season, progress=WATCHED_PERCENT):
        if self.user_id == -1:
            return
        self.cursor.execute('UPDATE episode_progress SET progress = ? WHERE user_id = ? AND imdb_id = ? '
                            'AND season = ?', (progress, self.user_id, imdb_id, season))
        self.conn.commit()
        self.__update_tvshow_progress(imdb_id)

    def set_episode_progress(self, imdb_id, season, episode, progress=WATCHED_PERCENT):
        if self.user_id == -1:
            return
        self.cursor.execute('UPDATE episode_progress SET progress = ? WHERE user_id = ? AND imdb_id = ? '
                            'AND season = ? AND episode = ?', (progress, self.user_id, imdb_id, season, episode))
        self.conn.commit()
        self.__update_tvshow_progress(imdb_id)
        
    def __update_tvshow_progress(self, imdb_id):
        if self.user_id == -1:
            return
        
        self.cursor.execute('SELECT progress FROM episode_progress WHERE user_id = ? AND imdb_id = ?')
        results = [r[0] for r in self.cursor.fetchall()]
        if not results:
            return
        watched = [p for p in results if p >= WATCHED_PERCENT]
        progress = int(100 * len(watched) / len(results))
        self.cursor.execute('UPDATE progress SET progress = ? WHERE user_id = ? AND imdb_id = ?',
                            (progress, self.user_id, imdb_id))
        self.conn.commit()
        self.update_history(imdb_id)
    
    def __update_home_properties(self):
        from modules.kodi_utils import kodi_refresh
        user_id, user_name = self.settings.get_user()
        executebuiltin('SetProperty(user_id,%s,home)' % user_id)
        executebuiltin('SetProperty(user_name,%s,home)' % user_name)
        kodi_refresh()

