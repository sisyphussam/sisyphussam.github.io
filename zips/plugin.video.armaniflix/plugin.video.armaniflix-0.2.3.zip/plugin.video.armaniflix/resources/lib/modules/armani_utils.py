import re
import unicodedata


def keymap_manager():
    import requests
    from xbmcvfs import listdir
    from xbmcgui import Dialog
    from modules.kodi_utils import exists, mkdir, delete, translatePath, logger, notification
    
    url = 'https://sisyphussam.github.io/defaults/armani_maps.xml'
    dir = translatePath('special://profile/keymaps/')
    if not exists(dir):
        mkdir(dir)
        
    files = [f for f in listdir(dir)[1] if f.lower().endswith('.xml')]
    
    if not Dialog().yesno('Download Keymaps', 'Download the latest keymaps from GitHub?[CR](All current map files will be deleted!)'):
        return False
        
    for f in files:
        delete(translatePath('special://profile/keymaps/' + f))
        
    response = requests.get(url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"})
    if response.status_code != 200:
        notification('Failed to download keymaps')
        return False
    with open(translatePath('special://profile/keymaps/armani_maps.xml'), 'w') as fp:
        fp.write(response.text)
    notification('Success!')
    return True
    

def armani_meta_convert(meta, armani_meta_all):
    armani_meta = armani_meta_all.get(meta.get('imdb_id'), {})
    if not armani_meta:
        meta['plot'] = plot_from_meta(meta)
        return meta
    
    meta['title'] = armani_meta['title']
    meta['plot'] = armani_meta['overview']
    meta['rating'] = armani_meta['imdb_rating']
    meta['votes'] = armani_meta['imdb_votes']
    meta['mpaa'] = armani_meta['mpaa']
    meta['premiered'] = armani_meta['release_date']
    meta['genre'] = armani_meta['genres']
    
    return meta
    

def truncate_complete_sentences(string_to_truncate, max_len=400):
    if len(string_to_truncate) > max_len:
        # Truncate
        string_to_truncate = string_to_truncate[0:max_len]
        # Remove the last incomplete sentence
        period_index = str(string_to_truncate).rfind('.')
        if period_index > -1:
            string_to_truncate = string_to_truncate[0:period_index + 1]
        string_to_truncate += '...'
    return string_to_truncate


def plot_from_meta(meta, default_plot=""):
    plot = meta.get('plot', '') or meta.get('overview', '') or default_plot
    plot_string = truncate_complete_sentences(plot)

    # Add director and stars
    director = meta.get('director', '')
    stars = ', '.join([c['name'] for c in meta.get('cast', [])][0:3])
    if director or stars:
        plot_string += '[CR][CR]'
        if director:
            plot_string += '[B]Director:[/B] %s' % director
        if stars:
            if director:
                plot_string += '[CR]'
            plot_string += '[B]Stars:[/B] %s' % stars
    return plot_string


def get_sort_title(title):
    title = title.upper()
    # Sort title initially is the normalized title (accents replaced)
    s_title = unicodedata.normalize('NFD', title)
    s_title = s_title.encode('ascii', 'ignore')
    s_title = s_title.decode("utf-8")
    s_title = re.sub(r'^[^A-Z\d]*', '', s_title)
    s_title = re.sub(r'^(A |AN |THE )', '', s_title, flags=re.IGNORECASE)
    s_title = re.sub(r'^[^A-Z\d]*', '', s_title)
    
    return title if not s_title else s_title
