import re
import unicodedata
from modules.kodi_utils import exists, mkdir, delete, notification, local_string as ls, logger
from xbmc import executebuiltin
from xbmcgui import Dialog, ListItem
from xbmcvfs import translatePath, listdir

ARMANI_DATA_PATH = 'special://profile/addon_data/plugin.video.armaniflix/%s'


def get_file_path(file):
    return translatePath(ARMANI_DATA_PATH % file)


def str_to_int(str_number: str, default=0):
    str_number = str_number.replace(',', '')
    try:
        i = int(str_number)
    except ValueError:
        i = default
    return i


def current_date() -> str:
    from datetime import date
    return date.today().strftime('%Y-%m-%d')


class ArmaniDialog:
    def __init__(self):
        from caches.armani_settings import ArmaniSettings
        self.dialog = Dialog()
        self.settings = ArmaniSettings()

    def multi_simple(self, heading, list_items, preselect=None):
        menu_name = 'multi_simple'
        if len(list_items) < 7:
            menu_name += str(len(list_items))
        
        if preselect is None:
            preselect = []
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        index = self.dialog.multiselect(heading, list_items, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return index

    def menu(self, heading, labels, preselect=-1):
        """ Open the skin's "menu" select dialog

        Args:
            heading: string - dialog heading
            labels: list of strings - items shown in the dialog
            preselect: [opt] integer - index of preselected item

        Returns:
            Returns the selected index (or -1 if cancelled)

        """
        menu_name = 'menu11'
        if len(labels) < 4:
            menu_name = 'menu3'
        elif len(labels) < 6:
            menu_name = 'menu5'
        elif len(labels) < 8:
            menu_name = 'menu7'
        elif len(labels) < 10:
            menu_name = 'menu9'
    
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        ret = self.dialog.select(heading.upper(), labels, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return ret

    def detail_menu(self, heading, list_items, use_details=True, preselect=-1, menu_type='detail_menu') -> int:
        executebuiltin('SetProperty(select_type,%s,home)' % menu_type)
        index = self.dialog.select(heading, list_items, preselect=preselect, useDetails=use_details)
        executebuiltin('ClearProperty(select_type,home)')
        return index

    def column_menu(self, menu_type, num_cols, max_rows, heading: str, labels, multi=False, preselect=None):
        import math
        num_rows = min(max_rows, math.ceil(1.0 * len(labels) / num_cols))
        menu_name = '%s%d' % (menu_type, num_rows)
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        if multi:
            if preselect is None:
                preselect = []
            sel = self.dialog.multiselect(heading.upper(), labels, preselect=preselect)
        else:
            if preselect is None:
                preselect = -1
            sel = self.dialog.select(heading.upper(), labels, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return sel
        
    def yesnocancel(self, heading: str, message: str, no_label=ls(32828), yes_label=ls(32824)):
        """ The YesNoCancel dialog can be used to inform the user about questions and get the answer.

        Args:
            heading: string - dialog heading.
            message: string - message text.
            no_label: [opt] label to put on the no button.
            yes_label: [opt] label to put on the yes button.

        Returns:
            Returns the integer value for the selected button (-1:cancelled, 0:no, 1:yes)

        """
        index = self.dialog.yesnocustom(heading, message, ls(32840), no_label, yes_label)
        return -1 if index == 2 else index

    def numeric(self, heading: str, message: str, default="", hidden=False) -> str:
        """ Open a numeric dialog with a custom heading

        Args:
            heading: string - dialog heading
            message: string - dialog message (a typical numeric dialog's heading)
            default: [opt] string - default value
            hidden: [opt] bool - masked input

        Returns:
            Returns the entered data as a string. Returns the default value if the dialog was canceled.

        """
        executebuiltin('SetProperty(numeric_header,%s,home)' % heading)
        value = self.dialog.numeric(0, message, default, hidden)
        executebuiltin('ClearProperty(numeric_header,home)')
        return value

    def min_max(self, heading, valid_range: tuple, min_value=None, max_value=None):
        def _main_dialog():
            _items = [
                ListItem('Minimum %s' % heading, 'NONE' if min_value is None else str(min_value)),
                ListItem('Maximum %s' % heading, 'NONE' if max_value is None else str(max_value)),
                ListItem('[COLOR yellow]RESET[/COLOR]', 'Clear all values')
            ]
            executebuiltin('SetProperty(select_type,single3,home)')
            _i = self.dialog.select('%s Range' % heading, _items)
            executebuiltin('ClearProperty(select_type,home)')
            return _i
    
        if valid_range[1] > 9999:
            s_range = f'{valid_range[0]:,} - {valid_range[1]:,}'
        else:
            s_range = f'{valid_range[0]} - {valid_range[1]}'
    
        if min_value is None:
            min_value = valid_range[0]
        if max_value is None:
            max_value = valid_range[1]
    
        while 1:
            i = _main_dialog()
            if i < 0:
                if max_value < min_value:
                    max_value = valid_range[1]
                return min_value, max_value
            if i == 0:
                n = self.numeric('%s - Minimum' % heading, s_range)
                if not n:
                    continue
                min_value = max(valid_range[0], min(valid_range[1], int(n)))
            elif i == 1:
                n = self.numeric('%s - Maximum' % heading, s_range)
                if not n:
                    continue
                max_value = max(valid_range[0], min(valid_range[1], int(n)))
            else:
                min_value, max_value = valid_range

    def alpha_menu(self, heading, labels, preselect=-1) -> int:
        import math
        num_rows = min(5, math.ceil(len(labels) / 6.0))
        menu_name = 'alpha%d' % num_rows
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        index = self.dialog.select(heading.upper(), labels, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return index

    def decade_menu(self, heading, labels, preselect, multi=False):
        import math
        num_rows = min(4, math.ceil(len(labels) / 4.0))
        menu_name = 'decades%d' % num_rows
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        if multi:
            sel = self.dialog.multiselect(heading.upper(), labels, preselect=preselect)
        else:
            sel = self.dialog.select(heading.upper(), labels, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return sel

    def genre_menu(self, heading, labels, preselect, multi=False):
        import math
        num_rows = min(8, math.ceil(len(labels) / 4.0))
        menu_name = 'genres%d' % num_rows
        executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
        if multi:
            sel = self.dialog.multiselect(heading.upper(), labels, preselect=preselect)
        else:
            sel = self.dialog.select(heading.upper(), labels, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return sel
    
    def __get_advanced_media_types(self):
        return self.settings.get_json('dialog_advanced_media_type') or {
            'string': 'All', 'where': ''
        }
    
    def __save_advanced_media_types(self, data: dict):
        self.settings.save_json('dialog_advanced_media_type', data)
    
    def __get_advanced_language(self):
        return self.settings.get_json('dialog_advanced_language') or {
            'string': 'All', 'where': ''
        }
    
    def __save_advanced_language(self, data: dict):
        self.settings.save_json('dialog_advanced_language', data)
        
    def __get_advanced_years(self):
        return self.settings.get_json('dialog_advanced_years') or {
            'string': '1900 - Now', 'where': '', 'min_year': None, 'max_year': None
        }
    
    def __save_advanced_years(self, data: dict):
        self.settings.save_json('dialog_advanced_years', data)
        
    def __get_advanced_rating(self):
        return self.settings.get_json('dialog_advanced_rating') or {
            'string': '0 - 10 (0 - Max)', 'where': '',
            'min_rating': None, 'max_rating': None, 'min_votes': None, 'max_votes': None
        }
    
    def __save_advanced_rating(self, data: dict):
        self.settings.save_json('dialog_advanced_rating', data)
        
    def __get_advanced_genres(self):
        return self.settings.get_json('dialog_advanced_genres') or {
            'string': 'Any', 'where': '', 'any': [], 'all': [], 'none': []
        }
    
    def __save_advanced_genres(self, data: dict):
        self.settings.save_json('dialog_advanced_genres', data)
        
    def __get_advanced_people(self):
        return self.settings.get_json('dialog_advanced_people') or {
            'string': 'None', 'where': '',
            'actor': [], 'actress': [], 'crew': [], 'collaboration': False
        }
    
    def __save_advanced_people(self, data: dict):
        self.settings.save_json('dialog_advanced_people', data)

    def advanced_search(self):
        from caches.armani_media import armani
        
        fmt1 = '[COLOR white]%s[/COLOR]'
        fmt2 = '[COLOR lightyellow]%s[/COLOR]'
        
        adv_values = {
            'media_type': self.__get_advanced_media_types(),
            'language': self.__get_advanced_language(),
            'years': self.__get_advanced_years(),
            'rating': self.__get_advanced_rating(),
            'genres': self.__get_advanced_genres(),
            'people': self.__get_advanced_people()
        }
        i = -1
        while 1:
            where_list = ['(%s)' % v['where'] for v in adv_values.values() if v['where']]
            if not where_list:
                num_results = 0
            else:
                armani.cursor.execute(f'SELECT COUNT(*) FROM media WHERE {" AND ".join(where_list)}')
                num_results = armani.cursor.fetchone()[0]
            
            items = [
                ListItem('[COLOR yellow]SEARCH[/COLOR]', f'[COLOR lightyellow]{num_results} titles[/COLOR]'),
                ListItem(fmt1 % 'Type', fmt2 % adv_values['media_type']['string']),
                ListItem(fmt1 % 'Language', fmt2 % adv_values['language']['string']),
                ListItem(fmt1 % 'Release Date', fmt2 % adv_values['years']['string']),
                ListItem(fmt1 % 'IMDb Rating', fmt2 % adv_values['rating']['string']),
                ListItem(fmt1 % 'Genres', fmt2 % adv_values['genres']['string']),
                ListItem(fmt1 % 'People', fmt2 % adv_values['people']['string'])
            ]
            
            i = self.detail_menu('Advanced Search', items, True, i, 'advanced')
            if i < 0:
                return None
            if i == 0:
                if num_results == 0:
                    notification('No Results')
                    continue
                break
            elif i == 1:
                adv_values['media_type'] = self.advanced_media_type()
            elif i == 2:
                adv_values['language'] = self.advanced_language()
            elif i == 3:
                adv_values['years'] = self.advanced_years()
            elif i == 4:
                adv_values['rating'] = self.advanced_rating()
            elif i == 5:
                adv_values['genres'] = self.advanced_genres()
            else:
                adv_values['people'] = self.advanced_people()
        
        return 'WHERE ' + ' AND '.join(where_list)
    
    def advanced_media_type(self):
        media_types = {
            'All': '',
            'Movies': 'db_type == "movie"',
            'TV Shows': 'db_type == "tvshow"',
            'Returning Series': 'db_type == "tvshow" AND status == "Returning Series"',
            'Completed Series': 'db_type == "tvshow" AND status != "Returning Series"'
        }
        media_type_keys = list(media_types.keys())
        saved = self.__get_advanced_media_types()
        media_type = saved['string']
        if media_type not in media_types:
            media_type = 'All'
            
        i = self.menu('Media Type', media_type_keys, media_type_keys.index(media_type))
        if i > -1:
            media_type = media_type_keys[i]
        saved.update({'string': media_type, 'where': media_types[media_type]})
        self.__save_advanced_media_types(saved)
        return saved

    def advanced_language(self):
        languages = {
            'All': '',
            'English': 'original_language == "English"',
            'Non-English': 'original_language != "English"',
            'Asian': 'original_language IN ("Cantonese", "Mandarin", "Japanese", "Korean", "Thai")',
            'Other': 'original_language NOT IN ("English", "Cantonese", "Mandarin", "Japanese", "Korean", "Thai")'
        }
        language_keys = list(languages.keys())
        saved = self.__get_advanced_language()
        language = saved['string']
        if language not in languages:
            language = 'All'
    
        i = self.menu('Language', [v for v in language_keys], language_keys.index(language))
        if i > -1:
            language = language_keys[i]
        saved.update({'string': language, 'where': languages[language]})
        self.__save_advanced_language(saved)
        return saved
        
    def advanced_years(self):
        from datetime import date
        saved = self.__get_advanced_years()
        min_year = saved.get('min_year')
        max_year = saved.get('max_year')
        years = ['None'] + [str(y) for y in range(1920, date.today().year + 1)]
        
        i = -1
        while 1:
            items = [
                ['Min. Year', min_year],
                ['Max. Year', max_year],
            ]
            i = self.__advanced_menu('Release Date', items, i)
            if i < 0:
                break
            if i == 0:
                min_year = max_year = None
            elif i == 1:
                pre = -1 if not min_year else years.index(min_year)
                j = self.menu('Minimum Year', years, pre)
                min_year = None if j < 1 else years[j]
            else:
                pre = -1 if not max_year else years.index(max_year)
                j = self.menu('Maximum Year', years, pre)
                max_year = None if j < 1 else years[j]
                

        where = []
        if min_year:
            where.append(f'year >= {min_year}')
        if max_year:
            where.append(f'year <= {max_year}')
            
        saved.update({'string': f'{min_year or "1900"} - {max_year or "Now"}',
                      'where': '' if not where else ' AND '.join(where),
                      'min_year': min_year, 'max_year': max_year})
        self.__save_advanced_years(saved)
        return saved
    
    def advanced_rating(self):
        saved = self.__get_advanced_rating()
        min_rating = saved.get('min_rating')
        max_rating = saved.get('max_rating')
        min_votes = saved.get('min_votes')
        max_votes = saved.get('max_votes')
        
        ratings = ['None'] + ['%.1f' % (r / 10.0) for r in range(50, 101)]
        votes = ['None'] + ['5,000', '10,000', '25,000', '50,000', '100,000', '250,000', '500,000', '1,000,000']
        
        i = -1
        while 1:
            items = [
                ['Min. Rating', min_rating],
                ['Max. Rating', max_rating],
                ['Min. Votes', min_votes],
                ['Max. Votes', max_votes],
            ]
            i = self.__advanced_menu('IMDb Rating', items, i)
            if i < 0:
                break
            if i == 0:
                min_rating = max_rating = min_votes = max_votes = None
            elif i == 1:
                pre = -1 if min_rating not in ratings else ratings.index(min_rating)
                j = self.menu('Minimum Rating', ratings, pre)
                min_rating = None if j < 1 else ratings[j]
            elif i == 2:
                pre = -1 if max_rating not in ratings else ratings.index(max_rating)
                j = self.menu('Maximum Rating', ratings, pre)
                max_rating = None if j < 1 else ratings[j]
            elif i == 3:
                pre = -1 if min_votes not in votes else votes.index(min_votes)
                j = self.menu('Minimum Vote Count', votes, pre)
                min_votes = None if j < 1 else votes[j]
            else:
                pre = -1 if max_votes not in votes else votes.index(max_votes)
                j = self.menu('Maximum Vote Count', votes, pre)
                max_votes = None if j < 1 else votes[j]

        where = []
        if min_rating:
            where.append(f'rating >= {min_rating}')
        if max_rating:
            where.append(f'rating <= {max_rating}')
        if min_votes:
            where.append(f'votes >= {min_votes.replace(",", "")}')
        if max_votes:
            where.append(f'votes <= {max_votes.replace(",", "")}')

        saved.update({
            'string': f'{min_rating or "0"} - {max_rating or "10"} ({min_votes or "0"} - {max_votes or "Max"})',
            'where': '' if not where else ' AND '.join(where),
            'min_rating': min_rating, 'max_rating': max_rating,
            'min_votes': min_votes, 'max_votes': max_votes
        })
        self.__save_advanced_rating(saved)
        return saved
    
    def advanced_genres(self):
        from caches.armani_media import armani
        saved = self.__get_advanced_genres()
        
        genres = armani.get_existing_genres()
        genre_ids = [g['id'] for g in genres]
        genre_names = [g['name'] for g in genres]
        genre_keys = ['any', 'all', 'none']
        genre_headings = ['Include ANY Genre', 'Include ALL Genres', 'Exclude Genres']
        for k in ('any', 'all', 'none'):
            saved[k] = [g for g in saved[k] if g in genre_ids]
    
        i = -1
        while 1:
            genre_indices = {'any': [genre_ids.index(g) for g in saved['any']],
                             'all': [genre_ids.index(g) for g in saved['all']],
                             'none': [genre_ids.index(g) for g in saved['none']]}
        
            items = [
                ['Any', ', '.join(genre_names[j] for j in genre_indices['any']) or 'None'],
                ['All', ', '.join(genre_names[j] for j in genre_indices['all']) or 'NONE'],
                ['Exclude', ', '.join(genre_names[j] for j in genre_indices['none']) or 'NONE']
            ]
            i = self.__advanced_menu('Genres', items, i)
        
            if i < 0:
                break
            if i == 0:
                saved.update({'any': [], 'all': [], 'none': []})
            else:
                genre_key, genre_heading = genre_keys[i - 1], genre_headings[i - 1]
                pre = [genre_ids.index(g) for g in saved[genre_key]]
                sel = self.genre_menu(genre_heading, genre_names, pre, True)
                if sel is None:
                    continue
                saved[genre_key] = [genre_ids[i] for i in sel]

        strings = []
        where = []
        if genre_indices['any']:
            strings.append('ANY(%s)' % ','.join(genre_names[i] for i in genre_indices['any']))
            where.append('(%s)' % (' OR '.join('genre_ids LIKE "%s"' % ('%' + g + '%') for g in saved['any'])))
        if genre_indices['all']:
            strings.append('ALL(%s)' % ','.join(genre_names[i] for i in genre_indices['all']))
            where.append(' AND '.join('genre_ids LIKE "%s"' % ('%' + g + '%') for g in saved['all']))
        if genre_indices['none']:
            strings.append('EXCLUDE(%s)' % ','.join(genre_names[i] for i in genre_indices['none']))
            where.append(' AND '.join('genre_ids NOT LIKE "%s"' % ('%' + g + '%') for g in saved['none']))
            
        saved.update({'string': ' | '.join(strings) or 'None', 'where': ' AND '.join(where) or ''})
        self.__save_advanced_genres(saved)
        return saved

    def advanced_people(self):
        from caches.armani_media import armani
        saved = self.__get_advanced_people()
        
        people = armani.get_people()
        people_groups = {
            'actor': {p['id']: p['name'] for p in people if 'actor' in p['jobs']},
            'actress': {p['id']: p['name'] for p in people if 'actress' in p['jobs']},
            'crew': {p['id']: p['name'] for p in people if any(j in p['jobs'] for j in ('director', 'writer'))},
        }
        people_keys = ['actor', 'actress', 'crew']
        people_headings = ['Actors', 'Actresses', 'Directors / Writers']
    
        i = -1
        while 1:
            items = [
                ['Actors', ', '.join([people_groups['actor'][p] for p in saved['actor']]) or 'None'],
                ['Actresses', ', '.join([people_groups['actress'][p] for p in saved['actress']]) or 'None'],
                ['Crew', ', '.join([people_groups['crew'][p] for p in saved['crew']]) or 'None'],
                ['Collaboration', str(saved['collaboration'])]
            ]
            i = self.__advanced_menu('People', items, i)
        
            if i < 0:
                break
            if i == 0:
                saved.update({'actor': [], 'actress': [], 'crew': [], 'collaboration': False})
            else:
                people_key, people_heading = people_keys[i - 1], people_headings[i - 1]
                people_ids = list(people_groups[people_key].keys())
                people_names = list(people_groups[people_key].values())
                pre = [people_ids.index(p) for p in saved[people_key]]
                sel = self.dialog.multiselect(people_heading, people_names, preselect=pre)
                if sel is None:
                    continue
                saved[people_key] = [people_ids[i] for i in sel]
                
        strings = []
        where = []
        joiner = ' AND ' if saved['collaboration'] else ' OR '
        if saved['actor']:
            where.append(joiner.join('cast_ids LIKE "%s"' % ('%<' + p + '>%') for p in saved['actor']))
            strings.append(joiner.join(people_groups['actor'][p] for p in saved['actor']))
        if saved['actress']:
            where.append(joiner.join('cast_ids LIKE "%s"' % ('%<' + p + '>%') for p in saved['actress']))
            strings.append(joiner.join(people_groups['actress'][p] for p in saved['actress']))
        if saved['crew']:
            where.append(joiner.join('crew_ids LIKE "%s"' % ('%<' + p + '>%') for p in saved['crew']))
            strings.append(joiner.join(people_groups['crew'][p] for p in saved['crew']))
            
        saved.update({'string': joiner.join(strings) or 'None', 'where': joiner.join(where) or ''})
        self.__save_advanced_people(saved)
        return saved

    def __advanced_menu(self, heading, items, preselect=-1):
        fmt1 = '[COLOR white]%s[/COLOR]'
        fmt2 = '[COLOR lightyellow]%s[/COLOR]'
        list_items = [ListItem('[COLOR yellow]RESET[/COLOR]', '[COLOR grey]Restore defaults[/COLOR]')]
        list_items.extend([ListItem(fmt1 % i[0], fmt2 % str(i[1])) for i in items])
    
        executebuiltin('SetProperty(select_type,multi%d,home)' % len(list_items))
        i = self.dialog.select(heading, list_items, preselect=preselect)
        executebuiltin('ClearProperty(select_type,home)')
        return i


def kodi_log():
    """ View Kodi's log sorted by descending timestamp """
    log_file = translatePath('special://logpath/kodi.log')
    if not exists(log_file):
        return
    with open(log_file, 'r', errors="ignore") as fp:
        Dialog().textviewer('Kodi Log', '\n'.join(reversed(fp.readlines())))


def clear_caches():
    """ Clear Fen's caches (Kodi caches will be cleared in a future update). """
    import sqlite3
    from modules.kodi_utils import favorites_db, metacache_db, maincache_db, debridcache_db, notification
    dbcon = sqlite3.connect(favorites_db)
    dbcon.execute('DELETE FROM favourites')  # ArmaniFlix doesn't use them anyway
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(metacache_db)
    dbcon.execute('DELETE FROM metadata')
    dbcon.execute('DELETE FROM season_metadata')
    dbcon.execute('DELETE FROM function_cache')
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(maincache_db)
    dbcon.execute('DELETE FROM maincache')
    dbcon.commit()
    dbcon.close()
    
    dbcon = sqlite3.connect(debridcache_db)
    dbcon.execute('DELETE FROM debrid_data')
    dbcon.commit()
    dbcon.close()
    notification('Cleared all caches')


def keymap_manager():
    """ Download recommended keymaps (keyboard, touch, and remote) from GitHub """
    import requests
    
    url = 'https://sisyphussam.github.io/defaults/armani_maps.xml'
    dir = translatePath('special://profile/keymaps/')
    if not exists(dir):
        mkdir(dir)
        
    files = [f for f in listdir(dir)[1] if f.lower().endswith('.xml')]
    
    if not Dialog().yesno('Download Keymaps', 'Download the latest keymaps from GitHub?[CR](All current map files will be deleted!)'):
        return
        
    for f in files:
        delete(translatePath('special://profile/keymaps/' + f))
        
    response = requests.get(url, headers={"Cache-Control": "no-cache", "Pragma": "no-cache"})
    if response.status_code != 200:
        notification('Failed to download keymaps')
        return
    with open(translatePath('special://profile/keymaps/armani_maps.xml'), 'w') as fp:
        fp.write(response.text)
    notification('Success!')
    

def armani_meta_convert(meta, armani_meta_all):
    armani_meta = armani_meta_all.get(meta.get('imdb_id'), {})
    if not armani_meta:
        meta['plot'] = plot_from_meta(meta)
        return meta
    
    meta['title'] = armani_meta['title']
    meta['plot'] = armani_meta['overview']
    meta['rating'] = armani_meta['imdb_rating']
    meta['votes'] = armani_meta['imdb_votes']
    meta['mpaa'] = armani_meta['mpaa']
    meta['premiered'] = armani_meta['release_date']
    meta['genre'] = armani_meta['genres']
    
    return meta
    

def truncate_complete_sentences(string_to_truncate, max_len=300):
    if len(string_to_truncate) > max_len:
        # Truncate
        string_to_truncate = string_to_truncate[0:max_len]
        # Remove the last incomplete sentence
        period_index = str(string_to_truncate).rfind('.')
        if period_index > -1:
            string_to_truncate = string_to_truncate[0:period_index + 1]
        string_to_truncate += '...'
    return string_to_truncate


def plot_from_meta(meta, default_plot=""):
    plot = meta.get('plot', '') or meta.get('overview', '') or default_plot
    plot_string = truncate_complete_sentences(plot)

    # Add director and stars
    director = meta.get('director', '')
    stars = ', '.join([c['name'] for c in meta.get('cast', [])][0:3])
    if director or stars:
        plot_string += '[CR][CR]'
        if director:
            plot_string += '[B]Director:[/B] %s' % director
        if stars:
            if director:
                plot_string += '[CR]'
            plot_string += '[B]Stars:[/B] %s' % stars
    return plot_string


def get_sort_title(title):
    title = title.upper()
    # Sort title initially is the normalized title (accents replaced)
    s_title = unicodedata.normalize('NFD', title)
    s_title = s_title.encode('ascii', 'ignore')
    s_title = s_title.decode("utf-8")
    s_title = re.sub(r'^[^A-Z\d]*', '', s_title)
    s_title = re.sub(r'^(A |AN |THE )', '', s_title, flags=re.IGNORECASE)
    s_title = re.sub(r'^[^A-Z\d]*', '', s_title)
    
    return title if not s_title else s_title


def get_search_string(s: str):
    s = s.lower()
    s = unicodedata.normalize('NFD', s)
    s = s.encode('ascii', 'ignore')
    s = s.decode("utf-8")
    s = re.sub(r'[^A-Za-z\d]+', '', s)
    return s
