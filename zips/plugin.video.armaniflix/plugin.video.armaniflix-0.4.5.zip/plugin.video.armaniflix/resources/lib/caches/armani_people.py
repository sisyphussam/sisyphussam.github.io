from caches.armani_media import armani
from caches.armani_settings import ArmaniSettings
from modules.armani_utils import ArmaniDialog
from apis.armani_imdb_api import imdb_person_search
from modules.kodi_utils import notification, close_all_dialog, executebuiltin, build_url

SETTINGS = ArmaniSettings()
SETTING_KEY = 'armani_people'
HEADINGS = {
    'all': 'All People',
    'actor': 'Actors',
    'actress': 'Actresses',
    'crew': 'Directors & Writers',
}


def edit_person_jobs(person):
    person_jobs = [] if not person.get('jobs') else person['jobs'].split(',')
    jobs = ['actor', 'actress', 'director', 'writer']
    pre = [jobs.index(j) for j in person_jobs]
    sel = ArmaniDialog().multi_simple('Select Jobs', [j.capitalize() for j in jobs], pre)
    if sel:
        person['jobs'] = ','.join(jobs[i] for i in sel)


def get_person_where(person):
    s = '%<' + person['id'] + '>%'
    return 'cast_ids LIKE "%s" OR crew_ids LIKE "%s"' % (s, s)


def delete_person(person):
    armani.cursor.execute('DELETE FROM people WHERE imdb_id = ?', (person['id'],))
    armani.conn.commit()


class ArmaniPeople:
    def __init__(self):
        self.settings = ArmaniSettings()
        self.saved_data = self.settings.get_json(SETTING_KEY) or {
            'editing': {'all': None, 'actor': None, 'actress': None, 'crew': None},
            'viewing': {'all': None, 'actor': None, 'actress': None, 'crew': None}
        }
        self.dialog = ArmaniDialog()
        
    def save(self):
        self.settings.save_json(SETTING_KEY, self.saved_data)
        
    def get_people(self, group, people_key, selected_person=None):
        people = armani.get_people()
        if not people:
            return [], -1
        if people_key in ('actor', 'actress'):
            people = [p for p in people if people_key in p['jobs']]
        elif people_key == 'crew':
            people = [p for p in people if any(k in p['jobs'] for k in ('writer', 'director'))]
            
        saved_id = self.saved_data[group][people_key]
            
        preselect = -1
        if selected_person:
            for i in range(len(people)):
                p = people[i]
                if selected_person['id'] == p['id'] or selected_person['name'] <= p['name']:
                    preselect = i
                    break
        elif saved_id:
            for i in range(len(people)):
                p = people[i]
                if saved_id == p['id']:
                    preselect = i
                    break
            
        self.saved_data[group][people_key] = None if preselect == -1 else people[preselect]['id']
        self.save()
        return people, preselect
    
    def view_credits(self, people_key='all'):
        people, pre = self.get_people('viewing', people_key)
        i = self.dialog.menu(HEADINGS[people_key], [p['name'] for p in people], pre)
        if i < 0:
            return
        self.saved_data['viewing'][people_key] = people[i]['id']
        self.save()
        
        person = people[i]
        where = 'WHERE ' + get_person_where(person)
        
        armani.cursor.execute('SELECT * FROM media %s LIMIT 1' % where)
        if not armani.cursor.fetchall():
            notification('No titles found')
            return

        url = {'mode': 'armani_fetch', 'action': 'custom', 'where': where, 'armani_title': person['name']}
        close_all_dialog()
        executebuiltin('RunPlugin(%s)' % build_url(url))
        
    def modify_people(self, people_key='all', selected_person=None):
        people, pre = self.get_people('editing', people_key, selected_person)
        if not people:
            return
        
        heading = HEADINGS[people_key]
        i = self.dialog.menu(heading, [p['name'] for p in people], pre)
        if i == -1:
            return
        self.modify_person(people[i])
        self.modify_people(people_key, people[i])

    def modify_person(self, person):
        armani.cursor.execute('SELECT title, year FROM media '
                              'WHERE %s ORDER by release_date' % get_person_where(person))
        titles = ['%s (%d)' % r for r in armani.cursor.fetchall()]
    
        i = self.dialog.dialog.yesnocustom(
            person['name'],
            f'Job: {person["jobs"]}[CR]Number of titles: {len(titles)}[CR]Known for: {person["known_for"]}',
            'Delete', 'Edit', 'Add Titles')
        if i < 0:
            return
        elif i == 0:
            self.edit_person_table(person)
        elif i == 1:
            armani.imdb_add_person_credits(person)
        elif i == 2:
            delete_person(person)
            return
        self.modify_person(person)
        
    def edit_person_table(self, person, preselect=-1):
        from xbmcgui import ListItem
        fmt1 = '[COLOR white]%s[/COLOR]'
        fmt2 = '[COLOR lightyellow]%s[/COLOR]'
        options = [
            ListItem(fmt1 % 'Name', fmt2 % person['name']),
            ListItem(fmt1 % 'Known For', fmt2 % person['known_for']),
            ListItem(fmt1 % 'Jobs', fmt2 % person['jobs'])
        ]
        i = self.dialog.detail_menu(person['name'].upper(), options, True, preselect, 'person_edit')
        if i < 0:
            return
        if i == 0:
            v = self.dialog.dialog.input('Name', person['name']).strip()
            if not v:
                return self.edit_person_table(person, i)
            armani.cursor.execute('UPDATE people SET name = ? WHERE imdb_id = ?', (v, person['id']))
            armani.conn.commit()
            person['name'] = v
        elif i == 1:
            v = self.dialog.dialog.input('Known For', person['known_for']).strip()
            if not v:
                return self.edit_person_table(person, i)
            armani.cursor.execute('UPDATE people SET known_for = ? WHERE imdb_id = ?', (v, person['id']))
            armani.conn.commit()
            person['known_for'] = v
        elif i == 2:
            edit_person_jobs(person)
            armani.cursor.execute('UPDATE people SET jobs = ? WHERE imdb_id = ?', (person['jobs'], person['id']))
            armani.conn.commit()
        
        self.edit_person_table(person, i)
    
    def add_person(self):
        person = imdb_person_search()
        if not person:
            return
        found_person = armani.get_person(person['id'])
        if found_person:
            notification('%s already added' % found_person['name'])
            return

        while 1:
            edit_person_jobs(person)
            if not person.get('jobs'):
                if self.dialog.dialog.yesno('Job is Required', 'A person must have at least one job. Try again?'):
                    continue
                return
            break

        armani.cursor.execute('INSERT INTO people VALUES(?, ?, ?, ?)',
                              (person['id'], person['name'], person['known_for'], person['jobs']))
        armani.conn.commit()
        notification('%s added' % person['name'])
        self.modify_person(person)
        