import sqlite3
import json

from xbmcvfs import translatePath
from xbmcgui import Dialog, ListItem
from xbmc import executebuiltin

from modules.kodi_utils import logger, notification, kodi_refresh, close_all_dialog, local_string as ls, delete
from caches.armani_settings import ArmaniSettings
from datetime import datetime

USER_DB = translatePath('special://profile/addon_data/plugin.video.armaniflix/armani_users.db')
WATCHED_PERCENT = 90

HEADERS = {
    'genres_any': 'INCLUDE ANY GENRE',
    'genres_all': 'INCLUDE ALL GENRES',
    'genres_none': 'EXCLUDE GENRES'
}

def get_pin(default=""):
    executebuiltin('SetProperty(numeric_header,%s,home)' % ls(33550))
    user_pin = Dialog().numeric(0, ls(33529), default, True)
    executebuiltin('ClearProperty(numeric_header,home)')
    return user_pin
    

class ArmaniPlaylist:
    def __init__(self):
        self.settings = ArmaniSettings()
        self.conn = sqlite3.connect(USER_DB)
        self.cursor = self.conn.cursor()
        self.user_id = self.settings.get('user_id')
        self.user_name = self.settings.get('user_name')
        self.in_use = self.settings.get_json('in_use')
        self.genres = self.settings.get_json('genres')
        self.languages = self.settings.get_json('languages')
        self.playlist = self.get_playlist()
        self.dialog = Dialog()
        self.menu_options = {
            'reset': {'label': '[COLOR lightyellow][RESET][/COLOR]', 'info': 'Use the default playlist'},
            'media_types': {'label': 'Media Types', 'info': 'Include movies and/or TV shows', 'preselect': []},
            'watched_status': {'label': 'Watched Status', 'info': 'Include watched and/or unwatched content',
                               'preselect': []},
            'decades': {'label': 'Decades of Release', 'info': 'Match any selected decades', 'preselect': []},
            'languages': {'label': 'Original Languages', 'info': 'Match any selected languages', 'preselect': []},
            'genres_any': {'label': 'Genres (any)', 'info': 'Match any selected genres', 'preselect': []},
            'genres_all': {'label': 'Genres (all)', 'info': 'Match every selected genre', 'preselect': []},
            'genres_none': {'label': 'Genres (exclude)', 'info': 'Exclude selected genres', 'preselect': []},
            'search_any': {'label': 'Keywords (any)', 'info': 'Match any entered keywords'},
            'search_all': {'label': 'Keywords (all)', 'info': 'Match every entered keyword'},
            'search_none': {'label': 'Keywords (exclude)', 'info': 'Exclude entered keywords'}
        }
        
    def start(self):
        from indexers.armani import ArmaniMenu
        menu = ArmaniMenu('Playlist Editor')
        for k, data in self.menu_options.items():
            label = data['label'] if not self.playlist.get(k) else '[COLOR selected]%s[/COLOR]' % data['label']
            menu.add_item(k, label, data['info'])
            
        action = menu.select()
        if action:
            if action == 'reset':
                self.playlist = {}
                self.save_playlist()
                kodi_refresh()
            else:
                self.modify(action)
            self.start()
        
    def modify(self, key):
        executebuiltin('SetProperty(select_type,playlist,home)')
        items = []
        if not key in self.playlist:
            self.playlist[key] = []
            
        heading = self.menu_options[key]['label']
        info = self.menu_options[key]['info']
        
        if key == 'media_types':
            items = [
                {'label': 'Movies', 'value': 'movie'},
                {'label': 'TV Shows', 'value': 'tvshow'},
            ]
        elif key == 'watched_status':
            items = [
                {'label': 'Unwatched', 'value': 'unwatched'},
                {'label': 'Watched', 'value': 'watched'},
            ]
        elif key == 'decades':
            items = [{'label': '%d - %d' % (d, d + 9), 'value': d} for d in self.in_use['decades']]
        elif key == 'languages':
            languages = sorted([v for k, v in self.languages.items() if k in self.in_use['languages']])
            items = [{'label': lang, 'value': lang} for lang in languages]
        elif key.startswith('genres'):
            items = [{'label': v, 'value': k} for k, v in self.genres.items() if k in self.in_use['genres']]
        elif key.startswith('search'):
            d = ', '.join(self.playlist.get(key))
            t = Dialog().input('%s[CR][I]Use commas to delimit multiple terms[/I]' % heading, d).strip()
            self.playlist[key] = [] if not t else [s.strip() for s in t.split(',')]
            self.save_playlist()
            close_all_dialog()
            kodi_refresh()
            
        if not key.startswith('search'):
            values = [i['value'] for i in items]
            executebuiltin('SetProperty(select_info,%s,home)' % info)
            logger('values', str(values))
            logger('playlist', str(self.playlist.get(key)))
            preselect = [values.index(v) for v in self.playlist.get(key) if v in values]
            logger('pre', str(preselect))
            sel = Dialog().multiselect(heading, [i['label'] for i in items], preselect=preselect)
            if sel is not None:
                self.playlist[key] = [items[i]['value'] for i in sel]
                self.save_playlist()
                close_all_dialog()
                kodi_refresh()
        executebuiltin('ClearProperty(select_type,home)')
        executebuiltin('ClearProperty(select_info,home)')
        
    def get_playlist(self):
        self.cursor.execute('SELECT json FROM playlists WHERE user_id = ?', (self.user_id,))
        result = self.cursor.fetchone()
        if not result:
            return {'created': datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
        return json.loads(result[0])

    def save_playlist(self):
        self.playlist['created'] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.cursor.execute('INSERT OR REPLACE INTO playlists(user_id, json) VALUES(?, ?)',
                            (self.user_id, json.dumps(self.playlist)))
        self.conn.commit()


class ArmaniUsers:
    def __init__(self):
        self.conn = sqlite3.connect(USER_DB)
        self.cursor = self.conn.cursor()
        self.settings = ArmaniSettings()
        self.user_id = int(self.settings.get('user_id') or '-1')

    def check(self):
        if not self.activate_current_user(True):
            self.reset_users(False)
    
        executebuiltin('SetFocus(9001)')
        
    def get_users(self):
        """ Returns a dict list of all users (id, user_name, pin) """
        self.cursor.execute('SELECT id, user_name, pin FROM users ORDER BY user_name')
        return [{'id': r[0], 'user_name': r[1], 'pin': r[2]} for r in self.cursor.fetchall()]
    
    def get_current_user(self):
        """ Returns the saved user if it exists, or the default user the current user does not exist.

        Returns: Dict with keys 'id', 'user_name', 'pin'
        """
        user_id = int(self.settings.get('user_id') or '1')
        self.cursor.execute('SELECT id, user_name, pin FROM users WHERE id = ?', (user_id,))
        result = self.cursor.fetchone()
        if not result and user_id != 1:
            self.cursor.execute('SELECT id, user_name, pin FROM users WHERE id = 1')
            result = self.cursor.fetchone()
            self.settings.save('user_id', '1')
        if not result:
            # notification('Could not retrieve current user')
            return {}
        return {'id': result[0], 'user_name': result[1], 'pin': result[2]}
    
    def activate_user(self, user_id, silent=False) -> bool:
        """ Set the user with the specified id as the current user """
        self.cursor.execute('SELECT user_name, pin FROM users WHERE id = ?', (user_id,))
        result = self.cursor.fetchone()
        if not result:
            if not silent:
                notification('Invalid user: %d' % user_id)
            return False
        self.settings.save('user_id', user_id)
        self.user_id = user_id
        executebuiltin('SetProperty(user_id,%d,home)' % user_id)
        executebuiltin('SetProperty(user_name,%s,home)' % result[0])
        if not silent:
            notification(ls(33549) % result[0])
        return True
    
    def activate_current_user(self, silent=False) -> bool:
        """ Activate the current user (called when loading ArmaniFlix) """
        current_user = self.get_current_user()
        if not current_user:
            return False
        return self.activate_user(current_user['id'], silent)
    
    def reset_users(self, confirm=True):
        from modules.watched_status import delete_invalid_users
        if confirm and not Dialog().yesno('Confirm Reset', 'Resetting the user database will clear all favorites, playlists, and watch history. Proceed?'):
            return
        self.cursor.execute('SELECT id FROM users')
        self.cursor.execute('INSERT OR REPLACE INTO users(id, user_name, pin) VALUES(?, ?, ?)', (1, 'Default User', ''))
        self.cursor.execute('DELETE FROM users WHERE id != 1')
        self.cursor.execute('DELETE FROM favorites WHERE user_id != 1')
        self.cursor.execute('DELETE FROM playlists WHERE user_id != 1')
        self.conn.commit()
        delete_invalid_users()
        self.activate_user(1, True)
        notification('Reset user database')

    def select_user(self) -> bool:
        users = self.get_users()
        dlg = Dialog()
        
        current_user = self.get_current_user()
    
        if not users:
            notification('No users found')
            return False
        
        if len(users) == 1:
            self.activate_user(users[0]['id'])
            return False
        
        other_users = [u for u in users if u['id'] != current_user['id']]
        
        executebuiltin('SetProperty(select_type,login,home)')
        index = dlg.select(ls(33602), [u['user_name'] for u in other_users])
        executebuiltin('ClearProperty(select_type,home)')
        if index < 0:
            return False
        user = other_users[index]
            
        if user['pin'] and user['pin'] != get_pin():
            notification(33605)
            return False
        
        self.activate_user(user['id'])
        executebuiltin('SetFocus(9001)')
        return True
        
    def get_ids(self):
        self.cursor.execute('SELECT id FROM users')
        return [r[0] for r in self.cursor.fetchall()]
    
    def modify_user(self, user_id):
        self.cursor.execute('SELECT user_name, pin FROM users WHERE id = ?', (user_id,))
        user_data = self.cursor.fetchone()
        if not user_data:
            return
        user_name, user_pin = user_data
        if user_pin is None:
            user_pin = ''
        dlg = Dialog()
        
        # All but default user can be deleted
        sel = 0 if user_id == 1 else dlg.yesnocustom(ls(33546) % user_name, ls(33538), ls(32840), ls(33539), ls(33540))
        if sel not in (0, 1):
            return
        
        if sel == 0:
            new_name = dlg.input(ls(33527), user_name).strip() or user_name
            new_pin = get_pin(user_pin)
            self.cursor.execute('UPDATE users SET user_name = ?, pin = ? WHERE id = ?', (new_name, new_pin, user_id))
            self.conn.commit()
            notification(ls(33545) % user_name)
        elif sel == 1:
            from modules.watched_status import delete_invalid_users
            self.cursor.execute('DELETE FROM users WHERE id = ?', (user_id,))
            self.cursor.execute('DELETE FROM favorites WHERE user_id = ?', (user_id,))
            self.cursor.execute('DELETE FROM playlists WHERE user_id = ?', (user_id,))
            self.conn.commit()
            delete_invalid_users()
            notification(ls(33544) % user_name)
            
        self.activate_current_user(True)
        
    def add_user(self) -> bool:
        dlg = Dialog()
    
        user_name = dlg.input(ls(33527)).strip()
        if not user_name:
            return False
        
        self.cursor.execute('SELECT COUNT(*) FROM users WHERE user_name LIKE ?', (user_name,))
        if self.cursor.fetchone()[0] > 0:
            notification(ls(33528) % user_name.upper())
            return False
    
        user_pin = get_pin()
        if not user_pin:
            self.cursor.execute('INSERT INTO users(user_name) VALUES(?)', (user_name,))
        else:
            self.cursor.execute('INSERT INTO users(user_name,pin) VALUES(?,?)', (user_name, int(user_pin)))
            
        self.conn.commit()
        notification(ls(33530) % user_name)
        return True
    
    def is_favorite(self, imdb_id):
        self.cursor.execute('SELECT * FROM favorites WHERE user_id = ? AND imdb_id = ?', (self.user_id, imdb_id))
        return len(self.cursor.fetchall()) > 0
    
    def has_favorite(self):
        self.cursor.execute('SELECT COUNT(*) FROM favorites WHERE user_id = ?', (self.user_id,))
        return self.cursor.fetchone()[0] > 0
    
    def get_favorites(self):
        self.cursor.execute('SELECT imdb_id FROM favorites WHERE user_id = ?', (self.user_id,))
        results = self.cursor.fetchall()
        if not results:
            return []
        return [r[0] for r in results]
    
    def add_favorite(self, imdb_id):
        if self.user_id == -1:
            return
        self.cursor.execute('INSERT OR IGNORE INTO favorites(user_id, imdb_id) VALUES(?, ?)', (self.user_id, imdb_id))
        self.conn.commit()
        notification('Added', 2000)
        kodi_refresh()
        
    def remove_favorite(self, imdb_id):
        if self.user_id == -1:
            return
        self.cursor.execute('DELETE FROM favorites WHERE user_id = ? AND imdb_id = ?', (self.user_id, imdb_id))
        self.conn.commit()
        notification('Removed', 2000)
        kodi_refresh()
        
    def get_playlist(self):
        self.cursor.execute('SELECT json FROM playlists WHERE user_id = ?', (self.user_id,))
        result = self.cursor.fetchone()
        if not result:
            return {}
        return json.loads(result[0])
        
    def save_playlist(self, data: dict):
        if self.user_id == -1:
            return
        self.cursor.execute('INSERT OR REPLACE INTO playlists(user_id, json) VALUES(?, ?)',
                            (self.user_id, json.dumps(data)))
        self.conn.commit()
        