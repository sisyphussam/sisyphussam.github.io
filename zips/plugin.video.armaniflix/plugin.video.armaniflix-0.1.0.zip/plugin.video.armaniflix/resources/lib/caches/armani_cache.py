import json
import csv
import time
import requests
from datetime import date
from random import randint
from xbmcgui import Dialog, DialogProgress
from xbmcvfs import translatePath, delete, exists, copy
import sqlite3
import re
import unicodedata
from modules.kodi_utils import notification, local_string as ls, logger
from modules.armani_utils import truncate_complete_sentences

DB = translatePath('special://profile/addon_data/plugin.video.armaniflix/databases/armani.db')
CONFIG = translatePath('special://profile/addon_data/plugin.video.armaniflix/armani.json')
TEMP = translatePath('special://profile/addon_data/plugin.video.armaniflix/temp.json')

GIT = {
    'config': 'https://sisyphussam.github.io/defaults/config.json',
    'database': 'https://sisyphussam.github.io/defaults/armani.db'
}

MEDIA_TYPES = {
    'movies': ls(32028),
    'tvshows': ls(32029)
}

CATEGORIES = {
    'alpha': ls(33621),
    'genres': ls(33622),
    'decades': ls(33623),
    'top_rated': ls(33624)
}

SORTS = {
    'rating': ls(33515),
    'votes': ls(33516),
    'year': ls(33517),
    'random': ls(33218)
}

NUM_EXAMPLES = 6
FETCH_LIMIT = 200
PLAYLIST_LIMIT = 100

TMDB_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI1NTFiYWEzYjU4YTM0MmM0NGUwNmM5OGE1NTYwODA4ZiIsInN1YiI6IjYzZWM3ODAzMWYzZ" \
             "TYwMDA3ZmI1ZTQxYSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.YFH_FtAhTLPZcWLKUYvofUKiPsfiHFpN9pZK" \
             "I-M9O7o"
TMDB_HEADERS = {'Authorization': 'Bearer %s' % TMDB_TOKEN, 'accept': 'application/json'}
IMDB_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "DNT": "1",
                "Connection": "close",
                "Upgrade-Insecure-Requests": "1"}


def _search_string(s):
    s = unicodedata.normalize('NFD', s)
    s = s.encode('ascii', 'ignore')
    s = s.decode("utf-8")
    s = re.sub(r'[^A-Za-z\d]+', '', s)
    return s


def _db_types_to_where(db_types: str):
    db_types = [t.strip().lower() for t in db_types.split(',')]
    where = ' OR '.join(['db_type = ?'] * len(db_types))
    return where, db_types


class ArmaniCache:
    """ A database containing all movies and TV shows listed in GitHub CSV files. """
    
    def __init__(self):
        self.config = {}
        self.language = 'en-US'
        self.conn = sqlite3.connect(DB)
        self.cursor = self.conn.cursor()
        self.__load_config()
        
    def __load_config(self):
        if not exists(CONFIG):
            with open(CONFIG, 'w') as fp:
                json.dump({}, fp)
            self.config = {}
    
        with open(CONFIG, 'r') as fp:
            self.config = json.load(fp)
            
        if any(s not in self.config for s in ('tmdb_token', 'imdb_lists', 'genres', 'languages', 'countries')):
            self.download_default_config()
            self.download_default_database()

    def __save_config(self):
        with open(CONFIG, 'w') as fp:
            json.dump(self.config, fp, indent=2)
            
    def get_menu(self):
        return self.config.get('menu') or {
            'movies': {'alpha': {}, 'decades': {}, 'genres': {}},
            'tvshows': {'alpha': {}, 'decades': {}, 'genres': {}}
        }
    
    def get_genres(self):
        return self.config.get('genres', {})
        
    def download_defaults(self, silent=False) -> bool:
        """ Get configuration data and database from GitHub
        
        Returns: True if successful, False otherwise
        
        """
        download_db, download_config = True, True
        if not silent:
            ret = Dialog().yesnocustom(
                'RESTORE DEFAULTS',
                'What would you like to restore?[CR][COLOR yellow](Note: updates will be lost)[/COLOR]',
                'Both', 'Database', 'Config'
            )
            if ret < 0:
                return False
            download_db = ret == 0 or ret == 2
            download_config = ret == 1 or ret == 2
            
        success = True
        if download_config:
            if not self.download_default_config():
                notification('[COLOR red]Failed to restore config[/COLOR]')
                success = False
            else:
                notification('[COLOR lime]Config restored[/COLOR]')
        if download_db:
            if not self.download_default_database():
                notification('[COLOR red]Failed to restore database[/COLOR]')
                success = False
            else:
                notification('[COLOR lime]Database restored[/COLOR]')
        
        return success
        
    def download_default_config(self) -> bool:
        """ Download configuration file from GitHub
        
        Returns: True if successful, False otherwise
        
        """
        response = requests.get(GIT['config'])
        if response.status_code != 200:
            return False
        data = response.json()
        self.config['tmdb_token'] = data['tmdb_token']
        self.config['imdb_lists'] = data['imdb_lists']
        self.config['genres'] = data['genres']
        self.config['languages'] = data['languages']
        self.config['countries'] = data['countries']
        self.__save_config()
        return True
    
    def download_default_database(self) -> bool:
        """ Download database from GitHub
        
        Returns: True if successful, False otherwise
        
        """
        response = requests.get(GIT['database'])
        if response.status_code != 200:
            return False
        
        self.conn.close()
        delete(DB)
        with open(DB, 'wb') as out_file:
            out_file.write(response.content)
            
        self.conn = sqlite3.connect(DB)
        self.cursor = self.conn.cursor()
        self.__setup_menu()
        return True

    def download_updates(self) -> bool:
        """ Fetches IMDb lists (config) and updates the database.
        
        If an entry exists in the database, then its rating, votes, title, sort_title, and
        TV show status (if applicable) are updated. Otherwise, a new entry is added to
        the database.

        Returns: True if all database rows were updated (i.e., not canceled), False otherwise

        """
        def _row_error(msg):
            logger('ArmaniFlix / Row error', '%s - %s' % (msg, str(row)))
    
        lists = {k: v for k, v in self.config['imdb_lists'].items() if v}
        prog = DialogProgress()
        prog.create('UPDATING DATABASE', 'Initializing...')
        all_rows = []
    
        session = requests.Session()
        i = 0
        for list_name, list_id in lists.items():
            prog.update(int(100 * i / len(lists)), 'Fetching IMDb list:[CR]     [COLOR yellow]%s[/COLOR]' % list_name)
            i += 1
            csv_url = 'https://www.imdb.com/list/%s/export?ref_=ttls_exp' % list_id
            time.sleep(randint(1, 3))
            download = session.get(csv_url, headers=IMDB_HEADERS)
            if download.status_code != 200:
                Dialog().ok('CSV ERROR', 'The CSV for "%s" could not be downloaded' % list_name)
                logger('IMDB Import (%s)' % list_name, 'Error retrieving CSV')
                return False
            decoded_content = download.content.decode('utf-8')
            rows = list(csv.reader(decoded_content.splitlines(), delimiter=','))
            rows.pop(0)  # remove header row
            if not rows:
                continue
            all_rows.extend(rows)
            if prog.iscanceled():
                return False

        failure_count, new_count, delete_count = 0, 0, 0
        if all_rows:
            self.cursor.execute('SELECT imdb_id FROM media')
            delete_ids = [r[0] for r in self.cursor.fetchall() if r[0] not in [i[1] for i in all_rows]]
            delete_count = len(delete_ids)
            for delete_id in delete_ids:
                self.cursor.execute('DELETE FROM media WHERE imdb_id = ?', (delete_id,))
            self.conn.commit()
    
        valid_genres = self.config['genres']
        i = 0
        canceled = False
        
        for row in all_rows:
            if prog.iscanceled():
                canceled = True
                break
            prog_string = 'Fetching metadata for entry %d of %d.' % (i + 1, len(all_rows))
            if failure_count > 0:
                prog_string += '[CR][COLOR red](Failed to add %d entries)[/COLOR]' % failure_count
            
            prog.update(int(100 * i / len(all_rows)), prog_string)
            i += 1

            imdb_id = row[1]
            imdb_rating = float(row[8]) if row[8] else 0.0
            imdb_votes = int(row[12]) if row[12] else 0
            comment = [s.strip() for s in row[4].split('||')]
            title, sort_title, genre_ids = None, None, None
            if len(comment) == 3:
                sort_title = comment[0].strip().upper()
                title = comment[1].strip()
                genre_ids = [g.lower().strip() for g in comment[2].split(',')]
                if not title:
                    _row_error('Invalid title')
                    failure_count += 1
                    continue
                if not sort_title:
                    _row_error('Invalid sort title')
                    failure_count += 1
                    continue
                if any(g not in valid_genres for g in genre_ids):
                    _row_error('Invalid genre')
                    failure_count += 1
                    continue
            
            self.cursor.execute('SELECT extra_info, db_type, tmdb_id FROM media where imdb_id = ?', (imdb_id,))
            existing = self.cursor.fetchone()
            if existing:
                if not title:
                    self.cursor.execute('UPDATE media SET rating = ?, votes = ? WHERE imdb_id = ?',
                                        (imdb_rating, imdb_votes, imdb_id))
                else:
                    alpha = sort_title[0] if sort_title[0].isalpha() else '#'
                    db_type = existing[1]
                    tmdb_id = existing[2]
                    extra_info = json.loads(existing[0])
                    extra_info['genres'] = [valid_genres[g] for g in genre_ids]
                    if db_type == 'tvshow' and extra_info['status'] == 'Returning Series':
                        url = 'https://api.themoviedb.org/3/tv/%d?language=en-US' % tmdb_id
                        tmdb_response = session.get(url, headers=TMDB_HEADERS)
                        if tmdb_response.status_code != 200:
                            _row_error('Unable to retrieve TMDb details')
                        else:
                            tmdb_details = tmdb_response.json()
                            extra_info['status'] = tmdb_details['status']
                            extra_info['num_seasons'] = tmdb_details['number_of_seasons']
                            extra_info['num_episodes'] = tmdb_details['number_of_episodes']
                    self.cursor.execute("""
                        UPDATE media
                        SET title = ?, sort_title = ?, starting_letter = ?, genre_ids = ?, rating = ?, votes = ?,
                            extra_info = ?
                        WHERE imdb_id = ?
                    """, (title, sort_title, alpha, ', '.join(genre_ids), imdb_rating, imdb_votes,
                          json.dumps(extra_info), imdb_id))
            else:
                if self.insert_or_update(imdb_id, False, session, title, sort_title, genre_ids):
                    new_count += 1
                    # Commit occasionally in case of crash
                    if new_count % 100 == 0:
                        self.conn.commit()
                else:
                    failure_count += 1
                
        self.conn.commit()
        self.conn.execute('VACUUM')
        session.close()
        self.__setup_menu()
        prog.close()
        status_string = '[CR][COLOR lime]%d added[/COLOR]' % new_count
        if delete_count > 0:
            status_string += ' | [COLOR yellow]%d removed[/COLOR]' % delete_count
        if failure_count > 0:
            status_string += ' | [COLOR red]%d failed[/COLOR]' % failure_count
        
        if canceled:
            Dialog().ok('UPDATE INCOMPLETE', 'The update was cancelled.' + status_string)
            return False
        
        Dialog().ok('UPDATE COMPLETE', 'The update has completed.' + status_string)
        return True
        
    def insert_or_update(self, imdb_id: str, commit=True, session=None, title: str = None, sort_title: str = None,
                         genre_ids=None):
        """ Insert new entries or update existing entries.
        
        All metadata will be downloaded from IMDb and TMDb.

        Args:
            imdb_id: tt#######
            commit: Commit changes to the database?
            session: requests.Session
            title: If not set, title will be obtained from IMDb
            sort_title: If not set, sort_title will be obtained from title
            genre_ids: If not set, genre_ids will be obtained from IMDb

        Returns: True if no error occurred, False otherwise

        """
        from modules.kodi_utils import notification
        from modules.armani_utils import get_sort_title
        
        def _get_tmdb(url_tail):
            url = 'https://api.themoviedb.org/3/' + url_tail
            tmdb_response = session.get(url, headers=TMDB_HEADERS)
            if tmdb_response.status_code != 200:
                raise ValueError('Unable to retrieve: %s - %s' % (url, tmdb_response.text))
            return tmdb_response.json()
        
        def _error(msg):
            notification(32760)
            logger('ArmaniFlix / add_entry[%s]' % imdb_id, str(msg))
        
        if not session:
            session = requests.Session()
            
        # Get IMDb data
        response = session.get('https://www.imdb.com/title/%s' % imdb_id, headers=IMDB_HEADERS)
        if response.status_code != 200:
            _error('Unable to retrieve IMDB details')
            return False
        json_text = response.text.split('{"props":{"pageProps"')[1].split('"aboveTheFoldData":')[1]
        json_text = json_text.split(',"mainColumnData":{')[0]
        imdb_data = json.loads(json_text)
        
        # Details from IMDb data
        if not title:
            title = imdb_data['titleText']['text']
        if not sort_title:
            sort_title = get_sort_title(title)
        alpha = sort_title[0] if sort_title[0].isalpha() else '#'
        if not genre_ids:
            imdb_genres = {
                'Action': 'act', 'Adult': 'adu', 'Adventure': 'adv', 'Animation': 'ani', 'Biography': 'bio',
                'Comedy': 'com', 'Crime': 'cri', 'Documentary': 'doc', 'Drama': 'dra', 'Family': 'fam',
                'Fantasy': 'fan', 'Film Noir': 'fil', 'Game Show': 'gam', 'History': 'his', 'Horror': 'hor',
                'Musical': 'mus', 'Mystery': 'mys', 'News': 'new', 'Reality-TV': 'rea', 'Romance': 'rom',
                'Sci-Fi': 'sci', 'Short': 'sho', 'Sport': 'spo', 'Talk-Show': 'tal', 'Thriller': 'thr',
                'War': 'war', 'Western': 'wes'
            }
            genre_ids = [imdb_genres[g['text']] for g in imdb_data['genres']['genres']]
        genre_ids = [g for g in genre_ids if g in self.config['genres']]
        db_type = 'movie' if imdb_data['titleType']['id'] in ('movie', 'tvMovie', 'short') else 'tvshow'
        media_type = 'movie' if db_type == 'movie' else 'tv'
        imdb_rating = imdb_data['ratingsSummary']['aggregateRating']
        imdb_votes = imdb_data['ratingsSummary']['voteCount']
        plot = truncate_complete_sentences(imdb_data['plot']['plotText']['plainText'])
        
        # Get tmdb data
        tmdb_details, tmdb_release_dates, tmdb_credits, tmdb_ratings = None, None, None, None
        try:
            tmdb_find = _get_tmdb('find/%s?external_source=imdb_id' % imdb_id)
            found = tmdb_find['movie_results'] if db_type == 'movie' else tmdb_find['tv_results']
            if not found:
                _error('TMDB ID not found')
                return False
            tmdb_id = found[0]['id']
            tmdb_details = _get_tmdb('%s/%d?language=en-US' % (media_type, tmdb_id))
            if db_type == 'movie':
                tmdb_credits = _get_tmdb('movie/%d/credits' % tmdb_id)
                tmdb_release_dates = _get_tmdb('movie/%s/release_dates' % tmdb_id)['results']
            else:
                tmdb_credits = _get_tmdb('tv/%d/aggregate_credits' % tmdb_id)
                tmdb_ratings = _get_tmdb('tv/%s/content_ratings' % tmdb_id)['results']
                
        except ValueError as e:
            _error(e)
            return False
        
        # Details from TMDb data
        original_language = self.config['languages'][tmdb_details['original_language']]
        extra_info = {
            'genres': [self.config['genres'][g] for g in genre_ids],
            'countries': '',
            'num_episodes': 0,
            'num_seasons': 0,
            'status': tmdb_details['status']
        }
        
        # Movie details from TMDb data
        director_jobs = ('director', 'directed by')
        writer_jobs = ('author', 'book', 'comic book', 'graphic novel', 'novel', 'original story', 'screenplay',
                       'screenplay by', 'short story', 'story', 'story by', 'writer', 'written by')
        if db_type == 'movie':
            # Movie credits
            cast = tmdb_credits['cast']
            crew = sorted(tmdb_credits['crew'], key=lambda d: d['popularity'], reverse=True)
            directors = [p for p in crew if p['job'].lower() in director_jobs]
            creators = []
            writers = [p for p in crew if p['job'].lower() in writer_jobs]
            
            release_dates = []
            for d in tmdb_release_dates:
                release_dates.extend([rd['release_date'][:10] for rd in d['release_dates']])
            release_date = min(release_dates)
            runtime = tmdb_details['runtime']
    
            release_dates = {r['iso_3166_1']: r['release_dates'] for r in tmdb_release_dates}
            if 'US' not in release_dates:
                mpaa = 'NR'
            else:
                mpaa_list = [r['certification'] for r in release_dates['US'] if r['certification']]
                mpaa = 'NR' if not mpaa_list else mpaa_list[0]
    
            extra_info['countries'] = [c['name'] for c in tmdb_details['production_countries']]
            
        # TV details from TMDb data
        else:
            # TV credits
            cast = sorted(tmdb_credits['cast'], key=lambda d: d['total_episode_count'], reverse=True)
            cast = [c for c in cast if c['order'] < 8]
            for c in cast:
                c['character'] = sorted(c['roles'], key=lambda d: d['episode_count'], reverse=True)[0][
                    'character']
            creators = [{'id': c['id'], 'name': c['name']} for c in tmdb_details.get('created_by', [])]
            directors = []
            writers = []
            for c in tmdb_credits['crew']:
                for j in c['jobs']:
                    if j['job'].lower() in director_jobs:
                        directors.append(
                            {'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
                    elif j['job'].lower() in writer_jobs:
                        writers.append({'id': c['id'], 'name': c['name'], 'episode_count': j['episode_count']})
            directors = [{'id': p['id'], 'name': p['name']}
                         for p in sorted(directors, key=lambda d: d['episode_count'], reverse=True)][0:2]
            writers = [{'id': p['id'], 'name': p['name']}
                       for p in sorted(writers, key=lambda d: d['episode_count'], reverse=True)][0:2]
            
            release_date = tmdb_details['first_air_date']
            if tmdb_details['episode_run_time']:
                runtime = tmdb_details['episode_run_time'][0]
            else:
                episode_details = _get_tmdb('tv/%s/season/1/episode/1?language=en-US' % tmdb_id)
                runtime = episode_details['runtime'] or 0
    
            certs = {r['iso_3166_1']: r['rating'] for r in tmdb_ratings if r['rating']}
            mpaa = 'NR' if 'US' not in certs else certs['US']
            extra_info['countries'] = [self.config['countries'][c] for c in tmdb_details['origin_country']]
            extra_info['num_seasons'] = tmdb_details['number_of_seasons']
            extra_info['num_episodes'] = tmdb_details['number_of_episodes']

        # Finalize credits
        cast = [{'id': p['id'], 'name': p['name'], 'role': p['character'], 'order': p['order']} for p in cast]
        director = [{'id': p['id'], 'name': p['name']} for p in directors]
        writer = [{'id': p['id'], 'name': p['name']} for p in writers]
        cast = list({p['id']: p for p in cast}.values())
        cast = sorted(cast, key=lambda d: d['order'])
        director = list({p['id']: p for p in director}.values())
        writer = list({p['id']: p for p in writer}.values())
        all_credits = {
            'director': director[0:2],
            'creator': creators[0:2],
            'writer': writer[0:2],
            'cast': cast[0:8]
        }
        
        creator = [p['name'] for p in all_credits.get('creator', [])]
        director = [p['name'] for p in all_credits.get('director', [])]
        writer = [p['name'] for p in all_credits.get('writer', [])]
        cast = [p['name'] for p in all_credits.get('cast', [])]

        credit_lines = []
        credit_string = '[CR][B]%s:[/B] %s'
        if creator:
            credit_lines.append(credit_string % ('Creator', ', '.join(creator)))
        elif director:
            credit_lines.append(credit_string % ('Director', ', '.join(director)))
        if cast:
            credit_lines.append(credit_string % ('Stars', ', '.join(cast[0:3])))
        plot += '[CR]' + ''.join(credit_lines)
        
        search_words = [title, sort_title] + creator + director + writer + cast
        search_words = '|'.join(list(dict.fromkeys([_search_string(w) for w in search_words])))

        self.cursor.execute(
            'INSERT OR REPLACE INTO media VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            (imdb_id, db_type, tmdb_id, title, sort_title, alpha, mpaa, runtime, imdb_rating, imdb_votes, plot,
             original_language, release_date, int(release_date[:4]), ', '.join(genre_ids), search_words,
             json.dumps(extra_info), str(date.today())))
        if commit:
            self.conn.commit()
        return True
    
    def __setup_menu(self):
        def _menu_create(menu_id, menu_name):
            results = [{'imdb_id': r[0], 'title': r[1], 'sort_title': r[2], 'release_date': r[3]}
                       for r in self.cursor.fetchall()]
            if not results:
                return None
        
            samples = results[0:10]
            samples.sort(key=lambda x: x['release_date'])
            samples.sort(key=lambda x: x['sort_title'])
            return {
                'id': menu_id,
                'name': menu_name,
                'where': 'WHERE db_type = "%s" AND (%s)' % (db_type, filter_string),
                'count': len(results),
                'summary': '[CR]'.join([s['title'] for s in samples])
            }
    
        menu = {'movies': {'genres': {}, 'decades': {}, 'alpha': {}},
                'tvshows': {'genres': {}, 'decades': {}, 'alpha': {}}}
        sql_select = 'SELECT imdb_id, title || " (" || year || ")", sort_title, release_date ' \
                     'FROM media WHERE db_type = ? AND %s ORDER BY RANDOM()'
        valid_genres = self.config['genres']
        for db_type in ('movie', 'tvshow'):
            menu_type = 'movies' if db_type == 'movie' else 'tvshows'
            for g in valid_genres:
                filter_string = 'genre_ids LIKE ' + '"%' + g + '%"'
                self.cursor.execute(sql_select % 'genre_ids LIKE ?', (db_type, '%' + g + '%'))
                menu_entry = _menu_create(g, valid_genres[g])
                if menu_entry:
                    menu[menu_type]['genres'][g] = menu_entry
        
            for a in '#ABCDEFGHIJKLMNOPQRSTUVWXYZ':
                filter_string = 'starting_letter = "%s"' % a
                self.cursor.execute(sql_select % 'starting_letter = ?', (db_type, a))
                menu_entry = _menu_create(a, a)
                if menu_entry:
                    menu[menu_type]['alpha'][a] = menu_entry
        
            for d in (1900, 1910, 1920, 1930, 1940, 1950, 1960, 1970, 1980, 1990, 2000, 2010, 2020, 2030):
                filter_string = 'year >= %d AND year <= %d' % (d, d + 9)
                self.cursor.execute(sql_select % 'year >= ? AND year <= ?', (db_type, d, d + 9))
                menu_entry = _menu_create(str(d), '%d - %d' % (d, d + 9))
                if menu_entry:
                    menu[menu_type]['decades'][str(d)] = menu_entry
        self.config['menu'] = menu
        self.__save_config()
    
    def get_meta_list(self, where="", where_values=None, sort_order='sort_title, release_date'):
        if where_values is None:
            where_values = ()
        
        try:
            self.cursor.execute(f"""
                SELECT
                    imdb_id, db_type, tmdb_id, title, sort_title, mpaa, runtime, rating, votes, plot,
                    original_language, release_date, year, genre_ids, search_string, extra_info,
                    date_added, starting_letter
                FROM
                    media
                {where}
                ORDER BY
                    {sort_order}
            """, where_values)
        except sqlite3.Error:
            return []
        
        meta = []
        for row in self.cursor.fetchall():
            extra_info = json.loads(row[15])
            
            meta.append({
                'imdb_id': row[0],
                'db_type': row[1],
                'media_type': row[1],
                'tmdb_id': row[2],
                'title': row[3] if row[10] == 'English' else '%s [COLOR grey][%s][/COLOR]' % (row[3], row[10]),
                'rootname': '%s (%d)' % (row[3], row[12]),
                'sort_title': row[4],
                'starting_letter': row[17],
                'mpaa': row[5],
                'duration': row[6],
                'rating': row[7],
                'votes': row[8],
                'plot': row[9],
                'original_language': row[10],
                'premiered': row[11],
                'year': row[12],
                'decade': int(row[12] / 10) * 10,
                'genre_ids': row[13],
                'search_string': row[14],
                'original_title': row[3],
                'date_added': row[16],
                'genre': ', '.join(extra_info['genres']),
                'country': extra_info['countries'],
                'cast': '',
                'director': '',
                'writer': '',
                'keywords': '',
                'total_seasons': extra_info['num_seasons'],
                'total_aired_eps': extra_info['num_episodes']
            })
        return meta

    def fetch(self, params):
        db_types = params.get('db_types', 'movie, movie_set, tvshow')
        values = [t.strip().lower() for t in db_types.split(',')]
        where = '(%s)' % ' OR '.join(['db_type = ?'] * len(values))
    
        if 'years' in params:
            years = params['years'].split('-', maxsplit=1)
            if len(years) == 1:
                year_where = '(year = ?)'
                year_values = [int(years)]
            else:
                year_where = "(year >= ? AND year <= ?)"
                year_values = [int(years[0]), int(years[1])]
        
            values += year_values
            where += ' AND %s' % year_where
    
        if 'alpha' in params:
            values += [params['alpha'].upper()]
            where += ' AND starting_letter = ?'
    
        if 'genres' in params:
            values += ['%' + g.strip() + '%' for g in params['genres'].split(',')]
            where += ' AND %s' % ' AND '.join(['genre_ids LIKE ?'])
    
        if 'query' in params:
            values += ['%' + _search_string(params['query']) + '%']
            where += ' AND search_string LIKE ?'
    
        sort_order = params.get('sort_order', 'sort_title, release_date')
        if 'limit' not in sort_order.lower():
            sort_order += ' LIMIT %d' % FETCH_LIMIT
    
        return self.get_meta_list('WHERE %s' % where, values, sort_order)

    def can_fetch(self, params):
        return len(self.fetch(params)) > 0
    
    def get_meta_tmdb(self, db_type, tmdb_id):
        results = self.get_meta_list('WHERE db_type = ? AND tmdb_id = ?', (db_type, tmdb_id))
        return {} if not results else results[0]
    
    def get_meta_action(self, action):
        from caches.favorites import Favorites
        from modules.watched_status import armani_get_watch_history
        from modules.kodi_utils import get_armani_user
        results = []
        if action == 'favorites':
            results = [self.get_meta_tmdb(r[1], r[0]) for r in Favorites().get_all_favorites()]
        elif action == 'watched':
            results = [self.get_meta_tmdb(r[1], r[0]) for r in armani_get_watch_history()]
        elif action == 'playlist':
            results = self.get_meta_playlist(get_armani_user())
        
        return [r for r in results if r]
    
    def get_meta_playlist(self, user):
        from modules.watched_status import armani_filter_watched
        if 'playlists' not in self.config or user not in self.config['playlists']:
            return []
        playlist = self.config['playlists'][user]
        
        filters = []
        values = []
        if 'db_type' in playlist:
            filters.append('db_type == ?')
            values.append(playlist['db_type'])
        if 'genres_all' in playlist:
            filters.append(' AND '.join(['genre_ids LIKE ?'] * len(playlist['genres_all'])))
            values.extend(['%' + g + '%' for g in playlist['genres_all']])
        if 'genres_any' in playlist:
            filters.append(' OR '.join(['genre_ids LIKE ?'] * len(playlist['genres_any'])))
            values.extend(['%' + g + '%' for g in playlist['genres_any']])
        if 'genres_none' in playlist:
            filters.append(' AND '.join(['genre_ids NOT LIKE ?'] * len(playlist['genres_none'])))
            values.extend(['%' + g + '%' for g in playlist['genres_none']])
        if 'decades' in playlist:
            filters.append(' OR '.join(['(year >= ? AND year <= ?)'] * len(playlist['decades'])))
            for d in playlist['decades']:
                values.extend([d, d + 9])
        if 'languages' in playlist:
            filters.append(' OR '.join(['original_language = ?'] * len(playlist['languages'])))
            values.extend(playlist['languages'])
        
        s_filter = '' if not filters else 'WHERE %s' % ' AND '.join('(%s)' % f for f in filters)
        filter_date = playlist['created'] if playlist.get('include_watched', True) else '01-01-1000'
        results = armani_filter_watched(user, self.get_meta_list(s_filter, values), filter_date)
        if len(results) > PLAYLIST_LIMIT:
            size_filter = playlist.get('size_filter', {'key': 'rating', 'reverse': True})
            f_key = size_filter.get('key', 'rating')
            f_reverse = size_filter.get('reverse', True)
            results.sort(key=lambda x: x[f_key], reverse=f_reverse)
            results = results[0:PLAYLIST_LIMIT]
            results.sort(key=lambda x: x['premiered'])
            results.sort(key=lambda x: x['sort_title'])
        return results
    
    def __get_playlist_results(self, user, playlist):
        from modules.watched_status import armani_filter_watched
        filters = []
        values = []
        if 'db_type' in playlist:
            filters.append('db_type == ?')
            values.append(playlist['db_type'])
        if 'genres_all' in playlist:
            filters.append(' AND '.join(['genre_ids LIKE ?'] * len(playlist['genres_all'])))
            values.extend(['%' + g + '%' for g in playlist['genres_all']])
        if 'genres_any' in playlist:
            filters.append(' OR '.join(['genre_ids LIKE ?'] * len(playlist['genres_any'])))
            values.extend(['%' + g + '%' for g in playlist['genres_any']])
        if 'genres_none' in playlist:
            filters.append(' AND '.join(['genre_ids NOT LIKE ?'] * len(playlist['genres_none'])))
            values.extend(['%' + g + '%' for g in playlist['genres_none']])
        if 'decades' in playlist:
            filters.append(' OR '.join(['(year >= ? AND year <= ?)'] * len(playlist['decades'])))
            for d in playlist['decades']:
                values.extend([d, d + 9])
        if 'languages' in playlist:
            filters.append(' OR '.join(['original_language = ?'] * len(playlist['languages'])))
            values.extend(playlist['languages'])
    
        s_filter = '' if not filters else 'WHERE %s' % ' AND '.join('(%s)' % f for f in filters)
        filter_date = playlist['created'] if playlist.get('include_watched', True) else '01-01-1000'
        return armani_filter_watched(user, self.get_meta_list(s_filter, values), filter_date)
    
    def playlist_reset(self, user):
        from modules.kodi_utils import ListItem
        
        def _build_menu():
            list_items: list[ListItem] = []
            for m in menu_items:
                list_item = ListItem('[COLOR %s][B]%s[/B][/COLOR]' % (m.get('color', 'white'), m['label']))
                list_item.setProperty('description', m['description'])
                list_items.append(list_item)
            return list_items
        
        playlist = {'created': str(date.today()), 'db_type': 'movie', 'include_watched': False}
        results = self.get_meta_list()
        genre_id_string = ', '.join([m['genre_ids'] for m in results])
        genre_ids = list(dict.fromkeys(genre_id_string.split(', ')))
        genre_ids.sort()
        genre_names = [self.get_genres()[g] for g in genre_ids]
        languages = list(dict.fromkeys([m['original_language'] for m in results]))
        languages.sort()
        decades = list(dict.fromkeys([10 * int(m['year'] / 10) for m in results]))
        decades.sort(reverse=True)
        decade_names = ['%d - %d' % (d, d + 9) for d in decades]
        include_watched = [(False, "No"), (True, 'Yes')]
        include_watched_index = 0
        media_types = [('movie', 'Movies'), ('tvshow', 'TV shows'), (None, 'Movies & TV shows')]
        media_type_index = 0
        empty_list_string = '---'
        
        menu_strings = {
            'db_type': media_types[0][1],
            'include_watched': include_watched[0][1],
            'genres_any': empty_list_string,
            'genres_all': empty_list_string,
            'genres_none': empty_list_string,
            'decades': empty_list_string,
            'languages': empty_list_string
        }
        
        menu_items = [
            {'label': 'Media type',
             'description': 'A playlist can contain movies, TV shows, or movies and TV shows.'},
            {'label': 'Include watched content',
             'description': 'Should movies that you have already watched be included?'},
            {'label': 'Include ANY genres',
             'description': 'At least one selected genre must be present.'},
            {'label': 'Include ALL genres',
             'description': 'All selected genres must be present.'},
            {'label': 'Exclude genres',
             'description': 'None of the selected genres can be present.'},
            {'label': 'Decades',
             'description': 'The release year must lie within one of the selected ranges.'},
            {'label': 'Languages',
             'description': 'The original language must be one of the selected languages.'},
            {'label': 'CREATE PLAYLIST', 'color': 'gold',
             'description': 'Save the playlist and display results.'}
        ]
        
        main_menu = _build_menu()
        
        dlg = Dialog()
        while 1:
            results = self.__get_playlist_results(user, playlist)
            
            main_menu[0].setLabel2(menu_strings['db_type'])
            main_menu[1].setLabel2(menu_strings['include_watched'])
            main_menu[2].setLabel2(menu_strings['genres_any'])
            main_menu[3].setLabel2(menu_strings['genres_all'])
            main_menu[4].setLabel2(menu_strings['genres_none'])
            main_menu[5].setLabel2(menu_strings['decades'])
            main_menu[6].setLabel2(menu_strings['languages'])
            main_menu[7].setLabel2('%d results' % len(results))
            
            menu_ret = dlg.select('PLAYLIST GENERATOR', main_menu, useDetails=True)
            if menu_ret < 0:
                return False

            if menu_ret == len(main_menu) - 1:
                break
                
            title = main_menu[menu_ret].getLabel().upper()
                
            if menu_ret == 0:
                media_type_index = (media_type_index + 1) % len(media_types)
                playlist['db_type'], menu_strings['db_type'] = media_types[media_type_index]
                if not playlist['db_type']:
                    playlist.pop('db_type', None)
            elif menu_ret == 1:
                include_watched_index = (include_watched_index + 1) % len(include_watched)
                playlist['include_watched'], menu_strings['include_watched'] = include_watched[include_watched_index]
            elif menu_ret == 2:
                ret = dlg.multiselect(title, genre_names)
                if ret is None:
                    continue
                if not ret:
                    playlist.pop('genres_any', None)
                    menu_strings['genres_any'] = empty_list_string
                else:
                    playlist['genres_any'] = [genre_ids[i] for i in ret]
                    menu_strings['genres_any'] = ', '.join([genre_names[i] for i in ret])
            elif menu_ret == 3:
                ret = dlg.multiselect(title, genre_names)
                if ret is None:
                    continue
                if not ret:
                    playlist.pop('genres_all', None)
                    menu_strings['genres_all'] = empty_list_string
                else:
                    playlist['genres_all'] = [genre_ids[i] for i in ret]
                    menu_strings['genres_all'] = ', '.join([genre_names[i] for i in ret])
            elif menu_ret == 4:
                ret = dlg.multiselect(title, genre_names)
                if ret is None:
                    continue
                if not ret:
                    playlist.pop('genres_none', None)
                    menu_strings['genres_none'] = empty_list_string
                else:
                    playlist['genres_none'] = [genre_ids[i] for i in ret]
                    menu_strings['genres_none'] = ', '.join([genre_names[i] for i in ret])
            elif menu_ret == 5:
                ret = dlg.multiselect(title, decade_names)
                if ret is None:
                    continue
                if not ret:
                    playlist.pop('decades', None)
                    menu_strings['decades'] = empty_list_string
                else:
                    playlist['decades'] = [decades[i] for i in ret]
                    menu_strings['decades'] = ', '.join(['%ds' % d for d in playlist['decades']])
            elif menu_ret == 6:
                ret = dlg.multiselect(title, languages)
                if ret is None:
                    continue
                if not ret:
                    playlist.pop('languages', None)
                    menu_strings['languages'] = empty_list_string
                else:
                    playlist['languages'] = [languages[i] for i in ret]
                    menu_strings['languages'] = ', '.join(playlist['languages'])
                    
        # Filter if too many results
        if len(results) > PLAYLIST_LIMIT:
            filters = [
                {'label': 'Remove lowest rated', 'filter': ('rating', True)},
                {'label': 'Remove highest rated', 'filter': ('rating', False)},
                {'label': 'Remove least voted', 'filter': ('votes', True)},
                {'label': 'Remove most voted', 'filter': ('votes', False)},
                {'label': 'Remove oldest', 'filter': ('premiered', True)},
                {'label': 'Remove newest', 'filter': ('premiered', False)}
            ]
            ret = dlg.select('TOO MANY RESULTS TO DISPLAY', [f['label'] for f in filters])
            if ret < 0:
                ret = 0
            filter_key, reverse = filters[ret]['filter']
            playlist['size_filter'] = {'key': filter_key, 'reverse': reverse}

        if 'playlists' not in self.config:
            self.config['playlists'] = {user: playlist}
        else:
            self.config['playlists'][user] = playlist

        self.__save_config()
        return True
    
    def get_header(self, main_key, category_key=None, sort_type=""):
        """ Returns Content Type / Category / Category Key [sort type] header

        Examples:
            get_header('movies_genres')
            get_header('movies_alpha', 'A')
            get_header('movies_decades', 1920, 'year asc')

        Args:
            main_key: movies_genres, tvshows_decades, movies_alpha, etc.
            category_key: action, 1960, #, etc. (optional)
            sort_type: rating, votes, year asc, year desc, random (optional)

        Returns:
            The header associated with the main key, category key, and sort type

        """
        content_type, category = main_key.split('_')
        h = [MEDIA_TYPES[content_type], CATEGORIES[category]]
        header = '%s / %s' % (h[0], h[1])
        if category_key is not None:
            header += ' / %s' % self.get_menu()[content_type][category][category_key]['name']
            if sort_type in SORTS:
                header += ' [%s]' % SORTS[sort_type].lower()
        return header
    
    def get_list(self, main_key):
        """
        Returns a dict containing the title, summary and count associated with the specified key
        (used for menu InfoLabels).

        Example:
            get_list('tvshows_decades')

        Args:
            main_key: movies_genres, tvshows_decades, movies_alpha, etc.

        Returns:
            A dict containing key, title, summary, and count. For example:

            {'key': '1980', 'title': '1980 - 1989', 'summary': EXAMPLE_LIST, 'count': NUM_RESULTS}
        """
        content_type, category = main_key.split('_')
        m = self.get_menu()[content_type][category]
        
        return {k: {'key': k, 'title': v['name'], 'summary': v['summary'],
                    'count': v['count'], 'where': v['where']} for k, v in m.items()}
    
    def get_content(self, params):
        content_type, category = params['action'].split('_')
        m = self.get_menu()[content_type][category][str(params['value'])]
        order_str = 'sort_title, release_date'
        if 'order' in params:
            order_str = params['order']
            if 'limit' in params:
                order_str += ' LIMIT ' + params['limit']
        return self.get_meta_list(m['where'], sort_order=order_str)
    
    def fetch_hash(self, imdb_id) -> str:
        """
        Return the saved hash associated with the specified IMDb id if it exists.
        (A saved hash will have a higher priority when sources are generated.)

        Args:
            imdb_id: the IMDb id (e.g., tt0095016)

        Returns:
            The hash string if it exists, empty string otherwise
        """
        hashes = self.config.get('hashes', {})
        return "" if imdb_id not in hashes else hashes[imdb_id]
    
    def save_hash(self, imdb_id, source):
        """
        Store a hash from a source in the database (one hash per IMDb ID).
        (A saved hash will have a higher priority when sources are generated.)

        Args:
            imdb_id: the IMDb id (e.g., tt0095016)
            source: a dict containing a 'hash' value
        """
        if 'hashes' not in self.config:
            self.config['hashes'] = {}
        self.config['hashes'][imdb_id] = source['hash']
        self.__save_config()


armani = ArmaniCache()
