import requests
import json
import re
from modules.kodi_utils import notification, logger
from xbmcgui import Dialog, DialogProgress
from modules.armani_utils import get_sort_title, get_file_path, get_search_string
from time import sleep
from random import randint
from datetime import datetime


TODAY = datetime.today()

IMDB_HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:66.0) Gecko/20100101 Firefox/66.0",
                "Accept-Encoding": "gzip, deflate",
                "Accept-Language": "en-US,en;q=0.5",
                "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
                "DNT": "1",
                "Connection": "close",
                "Upgrade-Insecure-Requests": "1"}

IMDB_URL_ADVANCED_BASE = 'https://www.imdb.com/search/title/?sort=num_votes,desc&country_of_origin=!IN,!TR,!PK&'
IMDB_URL_PERSON_FIND = 'https://www.imdb.com/find/?s=nm&q=%s'
DEFAULT_TITLE_TYPE = 'title_type=feature,short,tv_series,tv_miniseries,tv_movie'

GENRE_MAP = {
    'act': 'Action',
    'adu': 'Adult',
    'adv': 'Adventure',
    'ani': 'Animation',
    'bio': 'Biography',
    'com': 'Comedy',
    'cri': 'Crime',
    'doc': 'Documentary',
    'dra': 'Drama',
    'fam': 'Family',
    'fan': 'Fantasy',
    'fil': 'Film-Noir',
    'gam': 'Game-Show',
    'his': 'History',
    'hor': 'Horror',
    'muc': 'Music',
    'mus': 'Musical',
    'mys': 'Mystery',
    'news': 'News',
    'rea': 'Reality-TV',
    'rom': 'Romance',
    'sci': 'Sci-Fi',
    'sho': 'Short',
    'spo': 'Sport',
    'tal': 'Talk-Show',
    'thr': 'Thriller',
    'war': 'War',
    'wes': 'Western'
}

KEYWORD_MAP = {
    'sil': 'silent-film',
    'sup': 'superhero',
    'sur': 'surrealism'
}

KEYWORDS = {
    'action-hero': 'Action Hero',
    'alien': 'Aliens',
    'anime': 'Anime',
    'child-protagonist': 'Children',
    'dark-comedy': 'Dark Comedy',
    'dystopia': 'Dystopian',
    'high-school': 'High School',
    'monster': 'Monsters',
    'official-bond-film': 'James Bond',
    'neo-noir': 'Neo Noir',
    'silent-film': 'Silent Film',
    'slasher': 'Slasher',
    'superhero': 'Superhero',
    'surrealism': 'Surrealism',
    'teenage-protagonist': 'Teenagers',
    'based-on-true-story': 'True Story',
    'vampire': 'Vampires',
    'werewolf': 'Werewolves',
    'zombie': 'Zombies'
}

IMDB_GENRES = {
    'Action': 'act', 'Adult': 'adu', 'Adventure': 'adv', 'Animation': 'ani', 'Biography': 'bio',
    'Comedy': 'com', 'Crime': 'cri', 'Documentary': 'doc', 'Drama': 'dra', 'Family': 'fam',
    'Fantasy': 'fan', 'Film-Noir': 'fil', 'Game-Show': 'gam', 'History': 'his', 'Horror': 'hor',
    'Music': 'muc', 'Musical': 'mus', 'Mystery': 'mys', 'News': 'new', 'Reality-TV': 'rea',
    'Romance': 'rom', 'Sci-Fi': 'sci', 'Short': 'sho', 'Sport': 'spo', 'Talk-Show': 'tal',
    'Thriller': 'thr', 'War': 'war', 'Western': 'wes'
}

IMDB_ADVANCED_CERTIFICATES = (
    {'label': 'G', 'label2': 'General Audiences', 'value': 'US:G'},
    {'label': 'PG', 'label2': 'Parental Guidance Suggested', 'value': 'US:PG'},
    {'label': 'PG-13', 'label2': 'Parents Strongly Cautioned', 'value': 'US:PG-13'},
    {'label': 'R', 'label2': 'Restricted', 'value': 'US:R'},
    {'label': 'NC-17', 'label2': 'Adults Only', 'value': 'US:NC-17'}
)

IMDB_ADVANCED_LANGUAGES = [
    ('Any', ''),
    ('English', 'primary_language=en'),
    ('Foreign', 'primary_language=!en'),
    ('Arabic', 'primary_language=ar'),
    ('Chinese', 'primary_language=zh,yue,cmn'),
    ('Danish', 'primary_language=da'),
    ('French', 'primary_language=fr'),
    ('German', 'primary_language=de'),
    ('Italian', 'primary_language=it'),
    ('Japanese', 'primary_language=ja'),
    ('Korean', 'primary_language=ko'),
    ('Norwegian', 'primary_language=no'),
    ('Persian', 'primary_language=fa'),
    ('Portuguese', 'primary_language=pt'),
    ('Russian', 'primary_language=ru'),
    ('Spanish', 'primary_language=es'),
    ('Swedish', 'primary_language=sv')
]

IMDB_SEARCH_FILTER = get_file_path('imdb/search_filter.json')
IMDB_CUSTOM = get_file_path('imdb/custom_values.json')
IMDB_LISTS = get_file_path('imdb/lists.json')
IMDB_USER_ID = 'ur163156999'


def check():
    from xbmcvfs import mkdir, exists
    imdb_path = get_file_path('imdb/')
    if not exists(imdb_path):
        mkdir(imdb_path)
        
        
def imdb_person_info(person_id, session=None) -> dict:
    notification('Fetching info', 1000)
    url = 'https://www.imdb.com/name/%s/' % person_id
    _text = get_imdb_text(url, session)
    if not _text:
        return {}
    try:
        _text = _text.split('"aboveTheFold":')[1].split(',"mainColumnData"', maxsplit=1)[0]
    except IndexError:
        return {}
    
    data = json.loads(_text)
    name = data['nameText']['text']
    known_for = data['knownFor']['edges'][0]['node']['title']['titleText']['text']
    main_job = data['primaryProfessions'][0]['category']['text'].lower()
    
    data = {'id': person_id, 'name': name, 'known_for': known_for, 'main_job': main_job}
    if main_job in ('actor', 'actress', 'director', 'writer'):
        data['jobs'] = main_job
    return data


def imdb_person_search(default='') -> dict:
    """ Search IMDb for a person's name

    Returns:
        A dict containing the id, name, and "known for" title of the found person

    """
    
    def _get_matches():
        _text = get_imdb_text(url, session)
        if not _text:
            return []
        try:
            _text = _text.split('"nameResults":')[1].split(',"titleResults":')[0]
        except IndexError:
            return []
        _data = json.loads(_text)
        _data = _data['results']
        if not _data:
            return []
        
        # Remove people that don't have a "known_for" field
        _results = {}
        for _d in _data:
            try:
                _r = {'id': _d['id'], 'name': _d['displayNameText'],
                      'known_for': '%s (%s)' % (_d['knownForTitleText'], _d['knownForTitleYear'])}
                _results[_d['id']] = _r
                pass
            except KeyError:
                continue
        if not _results:
            return []
        return list(_results.values())
    
    # Get query
    dlg = Dialog()
    query = dlg.input(
        "Search IMDb for a person's name[CR][I]Enter the full name and check spelling before proceeding[/I]",
        default).strip()
    if not query:
        return {}
    
    with requests.Session() as session:
        # Check for an exact match
        url = (IMDB_URL_PERSON_FIND % query) + '&exact=True'
        matches = _get_matches()
        if matches:
            s = get_search_string(query)
            for m in matches:
                if s in get_search_string(m['name']):
                    return m
            return matches[0]
        
        notification('Searching for a partial match')
        sleep(randint(2, 3))
        
        # Check for partial match
        url = (IMDB_URL_PERSON_FIND % query)
        matches = _get_matches()
        if matches:
            return matches[0]
    
    notification('No results')
    return {}


def imdb_get_person_credits(person):
    from xbmcgui import ListItem
    import modules.armani_dialogs as armani_dialogs
    
    job_index, type_index, vote_index, rating_index = 0, 0, 4, 3
    jobs = person['jobs'].split(',')
    db_types = [
        ('Movies', 'movie'),
        ('TV Shows', 'tvshow')
    ]
    min_votes = ['0', '1,000', '2,500', '5,000', '10,000', '25,000', '50,000', '100,000', '250,000',
                 '500,000', '1,000,000']
    min_ratings = ['0', '5', '6', '6.5', '7', '7.5', '8', '8.5', '9']
    
    i = -1
    fmt = '[COLOR white]%s[/COLOR]'
    while 1:
        options = [
            ListItem(fmt % 'Job', jobs[job_index]),
            ListItem(fmt % 'Media Type', db_types[type_index][0]),
            ListItem(fmt % 'Min. Votes', str(min_votes[vote_index])),
            ListItem(fmt % 'Min. Rating', str(min_ratings[rating_index])),
            ListItem('[COLOR yellow]SEARCH[/COLOR]')
        ]
        i = armani_dialogs.detail_menu(person['name'], options, i)
        if i < 0:
            return None
        if i == 0:
            if len(jobs) == 1:
                continue
            elif len(jobs) == 2:
                job_index = (job_index + 1) % len(jobs)
                continue
            j = armani_dialogs.menu('Job', jobs, job_index)
            if j > -1:
                job_index = j
        elif i == 1:
            j = armani_dialogs.menu('Media Type', [t[0] for t in db_types], type_index)
            if j > -1:
                type_index = j
        elif i == 2:
            j = armani_dialogs.menu('Min. Votes', min_votes, vote_index)
            if j > -1:
                vote_index = j
        elif i == 3:
            j = armani_dialogs.menu('Min. Rating', min_ratings, rating_index)
            if j > -1:
                rating_index = j
        else:
            return imdb_person_title_search(person['id'],
                                            jobs[job_index],
                                            db_types[type_index][1],
                                            min_ratings[rating_index],
                                            min_votes[vote_index].replace(',', ''))


def imdb_person_title_search(person_id, job_type, db_type='movie', min_rating='5', min_votes='5000'):
    url = 'https://www.imdb.com/filmosearch/?explore=title_type&sort=user_rating,desc&mode=detail&page=1&' \
          'role=%s&job_type=%s&title_type=%s&user_rating=%s,&num_votes=%s,'
    
    title_type = 'movie,tvMovie,short' if db_type == 'movie' else 'tvSeries,tvMiniSeries'
    url = url % (person_id, job_type, title_type, min_rating, min_votes)

    text = get_imdb_text(url)
    if not text:
        return None
    text = text.replace('\n', '')
    
    rows = text.split('<div class="lister-item-content">')
    rows.pop(0)
    
    items = []
    
    for html in rows:
        html = html.split('<a href="/title/', maxsplit=1)[1]  # Go to ID
        imdb_id, html = html.split('/', maxsplit=1)
        html = html.split('>', maxsplit=1)[1]  # Go to title
        title, html = html.split('</a>', maxsplit=1)
        html = html.split('<span class="lister-item-year', maxsplit=1)[1]
        html = html.split('>', maxsplit=1)[1]  # Go to year (in brackets)
        year, html = html.split('</span>', maxsplit=1)
        title += ' ' + year
        html = html.split('<span class="genre">', maxsplit=1)[1]  # Go to genres
        genres, html = html.split('</span>', maxsplit=1)
        html = html.split('<meta itemprop="ratingValue" content="', maxsplit=1)[1]  # Go to rating
        rating, html = html.split('"', maxsplit=1)
        html = html.split('<meta itemprop="ratingCount" content="', maxsplit=1)[1]  # Go to votes
        votes, html = html.split('"', maxsplit=1)
        html = html.split('<p class="">', maxsplit=1)[1]  # Go to plot
        plot = html.split('</p>', maxsplit=1)[0].strip()
        plot = re.compile(r'<[^>]+>').sub('', plot)
        items.append(_get_item(db_type, imdb_id, title, genres, rating, votes, plot))
    items.sort(key=lambda k: k['sort_title'])
    return items


def imdb_title_search(default="", min_rating=0, min_votes=1000, pages=3, input_title=True):
    from xbmcgui import Dialog
    if not input_title and default:
        title = default
    else:
        title = Dialog().input('Search for the title of a movie or show', default).strip()
        if not title:
            return None
    url_tail = 'min_rating=%.1f&title=%s' % (min_rating, title)
    return imdb_advanced_search(url_tail, pages, min_votes)


def imdb_advanced_search(url_tail: str, total_pages=3, min_votes=5000, max_votes=-1) -> list:
    """ Return advanced search results with the most votes sorted by title

    Args:
        url_tail: The URL parameters (e.g, "user_rating=8,&role=nm1010101")
        total_pages: The number of pages to parse (each contains 50 titles)
        min_votes: The minimum vote count (num_votes must not be in url_tail)
        max_votes: The maximum vote count

    Returns:
        Returns a list of sorted search results

    """
    if not url_tail:
        return []
    
    if 'title_type' not in url_tail:
        url_tail += '&' + DEFAULT_TITLE_TYPE
    if url_tail.startswith('&'):
        url_tail = url_tail[1:]
    url = IMDB_URL_ADVANCED_BASE + url_tail
    
    results = {}
    
    page_count = 0
    
    prog = DialogProgress()
    h = 'Fetching list of titles...'
    prog.create('Performing search', 'Please wait...')
    while page_count < total_pages:
        if -1 < max_votes <= min_votes:
            break
        if prog.iscanceled():
            break
        
        page_url = url + '&num_votes=%d,' % min_votes
        if max_votes > -1:
            page_url += '%d' % max_votes
        prog.update(int(100 * page_count / total_pages),
                    '%s\n  Page: %d of %d' % (h, page_count + 1, total_pages))
        
        if page_count > 0:
            sleep(randint(2, 3))
        page_count += 1
        
        json_text = get_imdb_text(page_url)
        if not json_text:
            break
        
        try:
            json_text = json_text.split('"titleListItems":')[1].split(',"total":')[0]
        except IndexError:
            notification('Error parsing URL')
            logger('PARSE FAILURE', page_url)
            break
        
        json_data = json.loads(json_text)
        last_page = len(json_data) < 50
        for d in json_data:
            if not d['genres']:
                continue
            data = {
                'id': d['titleId'],
                'title': d['titleText'],
                'sort_title': get_sort_title(d['titleText']),
                'year': d['releaseYear'],
                'genres': d['genres'],
                'type': d['titleType']['id'],
                'plot': d['plot'],
                'rating': d['ratingSummary']['aggregateRating'],
                'votes': d['ratingSummary']['voteCount']
            }
            data['release_date'] = '%s-01-01' % data['year']
            
            max_votes = data['votes']
            if data['type'] in ('tvSeries', 'tvMiniSeries'):
                data['media_type'], data['db_type'] = 'TV', 'tvshow'
            else:
                data['media_type'], data['db_type'] = 'movie', 'movie'
                
            data['label'] = '%s / %s (%d) | %.1f (%d)' % (
                data['media_type'], data['title'], data['year'], data['rating'], data['votes'])
            results[d['titleId']] = data
        if last_page:
            break
    
    prog.close()
    
    output = sorted(list(results.values()), key=lambda k: k['release_date'])
    output.sort(key=lambda k: k['sort_title'])
    
    return [_get_item(d['db_type'], d['id'], '%s (%d)' % (d['title'], d['year']), ', '.join(d['genres']),
                      str(d['rating']), str(d['votes']), d['plot'])
            for d in output]


def imdb_find_advanced(params):
    from xbmcgui import ListItem
    from caches.armani_users import UserSettings
    import modules.armani_dialogs as armani_dialogs
    
    def _defaults():
        return {
            'type_index': 1,
            'title': '',
            'person': None,
            'genre_keys': {'include': [], 'exclude': []},
            'keywords': [],
            'language_index': 0,
            'mpaa_indices': [],
            'years': [1900, TODAY.year],
            'rating_votes': (None, None, None, None),
            'page_index': 2
        }
    
    def _reset():
        values.update(_defaults())
        _more_init()
        with UserSettings() as user_settings:
            user_settings.save_json('imdb_find_advanced', values)
        
    def _load():
        with UserSettings() as user_settings:
            values.update(user_settings.get_json('imdb_find_advanced'))
        if 'db_type' in params:
            values['type_index'] = 1 if params['db_type'] == 'movie' else 2
        if 'title' in params:
            values['title'] = params['title'].strip()
        if 'person' in params:
            values['person'] = params['person']
        if 'genre_id' in params:
            _g = params['genre_id']
            if _g in GENRE_MAP:
                values['genre_keys']['include'] = [_g]
            elif _g in KEYWORD_MAP:
                values['keywords'] = [KEYWORD_MAP[_g]]
        if 'decade' in params:
            _d = int(params['decade'])
            values['years'] = [_d, _d + 9]
            
    def _save():
        _keys = ('type_index', 'title', 'person', 'genre_keys', 'keywords',
                 'language_index', 'years', 'mpaa_indices', 'rating_votes', 'page_index')
        with UserSettings() as user_settings:
            user_settings.save_json('imdb_find_advanced', {k: values[k] for k in _keys})
            
    def _genres_init():
        try:
            _include_values = [GENRE_MAP[k] for k in values['genre_keys']['include']]
            _exclude_values = [GENRE_MAP[k] for k in values['genre_keys']['exclude']]
        except:
            values['genre_keys'] = {'include': [], 'exclude': []}
            _include_values, _exclude_values = [], []
            
        _combined_values = _include_values + [f'!{g}' for g in _exclude_values]
        values['genre_string'] = ', '.join(_combined_values) or 'None'
        values['genre_values'] = ','.join(_combined_values)
        genre_menu.set_value('include', ', '.join(_include_values) or 'None')
        genre_menu.set_value('exclude', ', '.join(_exclude_values) or 'None')
            
    def _more_init():
        _genres_init()
        
        s_rating_votes = armani_dialogs.get_rating_vote_strings(
            values['rating_votes'][0], values['rating_votes'][1],
            values['rating_votes'][2], values['rating_votes'][3])[2]
        more_menu.set_value('date', '%d - %d' % (values['years'][0], values['years'][1]))
        more_menu.set_value('person', 'None' if not values['person'] else values['person']['name'])
        more_menu.set_value('genres', values['genre_string'])
        more_menu.set_value('keywords', ', '.join(values['keywords']) or 'None')
        more_menu.set_value('language', IMDB_ADVANCED_LANGUAGES[values['language_index']][0])
        more_menu.set_value('mpaa', ', '.join(IMDB_ADVANCED_CERTIFICATES[_i]['label']
                                              for _i in values['mpaa_indices']) or 'All')
        more_menu.set_value('rating', s_rating_votes)
        more_menu.set_value('pages', page_counts[values['page_index']])
        
        _default_values = _defaults()
        _all_values = {}
        _more_values = []
        for _value_key, _menu_key in (('years', 'date'),
                                      ('person', 'person'),
                                      ('genre_keys', 'genres'),
                                      ('keywords', 'keywords'),
                                      ('language_index', 'language'),
                                      ('mpaa_indices', 'mpaa'),
                                      ('rating_votes', 'rating'),
                                      ('page_index', 'pages')):
            
            if _default_values[_value_key] == values[_value_key]:
                continue
            _more_values.append(more_menu.get_label2(_menu_key))
        values['more_string'] = ' | '.join(_more_values) or 'Defaults'
        
    def _show_genre_menu():
        _genres_init()
        _selected = genre_menu.select()
        if _selected is None:
            return
        if _selected == 'reset':
            values['genre_keys'] = {'include': [], 'exclude': []}
        else:
            _pre = [genre_keys.index(k) for k in values['genre_keys'][_selected]]
            _sel = armani_dialogs.genre_menu('Genres to %s' % _selected.capitalize(), genre_values, _pre, True)
            if _sel is not None:
                values['genre_keys'][_selected] = [genre_keys[_i] for _i in _sel]
        
        _show_genre_menu()
        
    def _show_more_menu():
        while 1:
            _more_init()
            _selected = more_menu.select()
            if _selected is None:
                return
            if _selected == 'date':
                values['years'] = list(armani_dialogs.year_range((values['years'][0], values['years'][1])))
            elif _selected == 'person':
                from caches.armani_media import armani
                query = Dialog().input('Search for a name').strip()
                if not query:
                    values['person'] = None
                    continue
                q = get_search_string(query)
                people = {p['id']: p for p in armani.get_people() if q in get_search_string(p['name'])}
                if not people:
                    if not Dialog().yesno('No Results', f'"{query}" is not in the database. Search IMDb?'):
                        continue
                    person = imdb_person_search(query)
                else:
                    person_menu = armani_dialogs.KeyMenu('Find a Person')
                    for p in people.values():
                        person_menu.add_item(p['id'], p['name'])
                    person_menu.add_item('another', 'SOMEONE ELSE', format_index=1)
                    person_select = person_menu.select()
                    if person_select is None:
                        continue
                    if person_select == 'another':
                        person = imdb_person_search(query)
                    else:
                        person = people[person_select]
                if person:
                    values['person'] = person
            elif _selected == 'genres':
                _show_genre_menu()
            elif _selected == 'keywords':
                t = Dialog().input('Enter IMDb keywords[CR][I]Use commas to delimit words[/I]',
                                   ','.join(values['keywords'])).strip()
                values['keywords'] = [] if not t else ['-'.join(w.strip().split()) for w in t.split(',')]
            elif _selected == 'language':
                _i = armani_dialogs.genre_menu('Languages', [v[0] for v in IMDB_ADVANCED_LANGUAGES],
                                               values['language_index'])
                if _i > -1:
                    values['language_index'] = _i
            elif _selected == 'mpaa':
                _sel = armani_dialogs.double_line_menu('Certificates', mpaa_items, values['mpaa_indices'], True)
                if _sel is not None:
                    values['mpaa_indices'] = _sel
            elif _selected == 'rating':
                values['rating_votes'] = armani_dialogs.rating_votes(values['rating_votes'])
            elif _selected == 'pages':
                _i = armani_dialogs.menu('Pages to Scan', page_counts, values['page_index'])
                if _i > -1:
                    values['page_index'] = _i
                
    title_types = [
        ('All', 'movie,tvMovie,short,tvSeries,tvMiniSeries'),
        ('Movies', 'movie,tvMovie,short'),
        ('TV Shows', 'tvSeries,tvMiniSeries')
    ]
    page_counts = ['1', '2', '3', '4', '5',
                   '6', '7', '8', '9', '10']
    genre_keys = list(GENRE_MAP.keys())
    genre_values = list(GENRE_MAP.values())

    values = _defaults()
    _load()
    
    main_menu = armani_dialogs.KeyMenu('IMDb Search', 1, 'title')
    main_menu.add_item('reset', 'RESET', format_index=3)
    main_menu.add_item('title', 'Title')
    main_menu.add_item('type', 'Media Type')
    main_menu.add_item('more', 'More Options...')
    main_menu.add_item('search', 'SEARCH', format_index=1)
    
    more_menu = armani_dialogs.KeyMenu('More Options', 1)
    more_menu.add_item('date', 'Release Date')
    more_menu.add_item('person', 'Person')
    more_menu.add_item('genres', 'Genres')
    more_menu.add_item('keywords', 'Keywords')
    more_menu.add_item('language', 'Language')
    more_menu.add_item('mpaa', 'Certificate')
    more_menu.add_item('rating', 'IMDb Rating')
    more_menu.add_item('pages', 'Max. Pages')

    genre_menu = armani_dialogs.KeyMenu('Genres', 2)
    genre_menu.add_item('reset', 'Reset', 'Clear genres', format_index=1)
    genre_menu.add_item('include', 'Include Genres')
    genre_menu.add_item('exclude', 'Exclude Genres')
    
    _more_init()
    
    mpaa_items = [ListItem(m['label'], m['label2']) for m in IMDB_ADVANCED_CERTIFICATES]
   
    while 1:
        main_menu.set_value('title', values['title'])
        main_menu.set_value('type', title_types[values['type_index']][0])
        main_menu.set_value('more', values['more_string'])
        selection = main_menu.select()
        if selection is None:
            _save()
            return None
        if selection == 'reset':
            _reset()
        elif selection == 'title':
            values['title'] = Dialog().input('Search for a title', values['title']).strip()
        elif selection == 'type':
            i = armani_dialogs.menu('Media Type', [t[0] for t in title_types], values['type_index'])
            if i > -1:
                values['type_index'] = i
        elif selection == 'more':
            _show_more_menu()
        elif selection == 'search':
            _save()
            url_params = [
                'title_type=%s' % title_types[values['type_index']][1],
                'release_date=%d-01-01,%d-12-31' % (values['years'][0], values['years'][1])
            ]
            if values['rating_votes'][0] or values['rating_votes'][1]:
                rating = ('' if not values['rating_votes'][0] else str(values['rating_votes'][0]),
                          '' if not values['rating_votes'][1] else str(values['rating_votes'][1]))
                url_params.append('user_rating=%s,%s' % rating)
            if values['title']:
                url_params.append('title=%s' % values['title'])
            if values['person']:
                url_params.append('role=%s' % values['person']['id'])
            if values['genre_values']:
                url_params.append('genres=%s' % values['genre_values'])
            if values['keywords']:
                url_params.append('keywords=%s' % ','.join(values['keywords']))
            if values['language_index'] > 0:
                url_params.append(IMDB_ADVANCED_LANGUAGES[values['language_index']][1])
            if values['mpaa_indices']:
                url_params.append('certificates=%s' % ','.join(IMDB_ADVANCED_CERTIFICATES[i]['value']
                                                               for i in values['mpaa_indices']))
    
            url_tail = '&'.join(url_params)
            pages = int(page_counts[values['page_index']])
            min_votes = 0 if not values['rating_votes'][2] else values['rating_votes'][2]
            max_votes = -1 if not values['rating_votes'][3] else values['rating_votes'][3]
            return imdb_advanced_search(url_tail, pages, min_votes, max_votes)
        
        
def get_imdb_text(url, session=None) -> str:
    """ Returns the HTML of a web page.

    Args:
        url: IMDb URL
        session: (optional) requests session

    Returns:
        Returns the text (HTML) of a web page if it is successfully retrieved, an empty string otherwise

    """
    try:
        response = requests.get(url, headers=IMDB_HEADERS) if not session else session.get(
            url, headers=IMDB_HEADERS, timeout=5)
    except requests.exceptions.Timeout:
        notification('Timed out')
        logger('get_imdb_text: timeout', url)
        return ''
    
    if response.status_code != 200:
        notification('Error retrieving url')
        logger('get_imdb_text: failed', url)
        return ''
    return response.text


def get_imdb_json(url: str, split_a: str, split_b: str, session=None) -> dict:
    """ Return JSON found between two strings in a web page containing javascript.

    Args:
        url: IMDb URL
        split_a: JSON begins after this string
        split_b: JSON begins before this string
        session: (optional) requests session

    Returns:
        Returns the JSON if it exists, an empty dictionary otherwise

    """
    # Perform the search and extract results from javascript JSON
    json_text = get_imdb_text(url, session)
    if not json_text:
        return {}
    try:
        json_text = json_text.split(split_a)[1].split(split_b)[0]
    except IndexError:
        notification('Error retrieving data')
        logger('get_imdb_json: scrape error', url)
    
    try:
        data = json.loads(json_text)
        return data
    except json.JSONDecodeError:
        notification('Error retrieving data')
        logger('get_imdb_json: parse error', url)
        return {}

        
def _get_item(db_type: str, imdb_id: str, title_year: str, genres, rating: str, votes: str, plot: str):
    if type(genres) is list:
        genres = ', '.join(genres)
    title_year = title_year.strip()
    info = '[COLOR cyan]%s[/COLOR][CR]' % title_year.upper()
    info += '[COLOR lightgrey]%s[/COLOR][CR]' % genres.strip()
    info += '[COLOR lightyellow]%s (%s)[/COLOR][CR][CR]' % (rating.strip(), votes.strip())
    info += plot.strip()
    return {
        'db_type': db_type,
        'id': imdb_id.strip().lower(),
        'label': title_year,
        'sort_title': get_sort_title(title_year),
        'info': info
    }
    



