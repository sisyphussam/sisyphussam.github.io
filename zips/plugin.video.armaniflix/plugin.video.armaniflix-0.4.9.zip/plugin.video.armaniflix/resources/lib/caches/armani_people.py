from caches.armani_media import armani
from caches.armani_users import UserSettings
from modules.armani_utils import get_search_string
import modules.armani_dialogs as armani_dialogs
from xbmcgui import Dialog
from apis.armani_imdb_api import imdb_person_search
from modules.kodi_utils import notification, close_all_dialog, executebuiltin, build_url, local_string as ls

SETTING_KEY = 'armani_people'
HEADINGS = {
    'all': 'All People',
    'actor': 'Actors',
    'actress': 'Actresses',
    'crew': 'Directors & Writers',
}


def edit_person_jobs(person):
    person_jobs = [] if not person.get('jobs') else person['jobs'].split(',')
    jobs = ['actor', 'actress', 'director', 'writer']
    pre = [jobs.index(j) for j in person_jobs]
    sel = armani_dialogs.menu('Select Jobs', [j.capitalize() for j in jobs], pre, True)
    if sel:
        person['jobs'] = ','.join(jobs[i] for i in sel)


def get_person_where(person):
    s = '%<' + person['id'] + '>%'
    return 'cast_ids LIKE "%s" OR crew_ids LIKE "%s"' % (s, s)


def delete_person(person):
    armani.cursor.execute('DELETE FROM people WHERE imdb_id = ?', (person['id'],))
    armani.conn.commit()


def view_credits(person):
    where = 'WHERE ' + get_person_where(person)

    armani.cursor.execute('SELECT * FROM media %s LIMIT 1' % where)
    if not armani.cursor.fetchall():
        notification('No titles found')
        return

    url = {'mode': 'armani_fetch', 'where': where, 'armani_title': person['name']}
    close_all_dialog()
    executebuiltin('RunPlugin(%s)' % build_url(url))


class ArmaniPeople:
    def __init__(self):
        with UserSettings() as user_settings:
            self.saved_data = user_settings.get_json(SETTING_KEY) or {
                'editing': {'all': None, 'actor': None, 'actress': None, 'crew': None},
                'viewing': {'all': None, 'actor': None, 'actress': None, 'crew': None}
            }
        
    def save(self):
        with UserSettings() as user_settings:
            user_settings.save_json(SETTING_KEY, self.saved_data)
        
    def get_people(self, group, people_key, selected_person=None):
        people = armani.get_people()
        if not people:
            return [], -1
        if people_key in ('actor', 'actress'):
            people = [p for p in people if people_key in p['jobs']]
        elif people_key == 'crew':
            people = [p for p in people if any(k in p['jobs'] for k in ('writer', 'director'))]
            
        saved_id = self.saved_data[group][people_key]
            
        preselect = -1
        if selected_person:
            for i in range(len(people)):
                p = people[i]
                if selected_person['id'] == p['id'] or selected_person['name'] <= p['name']:
                    preselect = i
                    break
        elif saved_id:
            for i in range(len(people)):
                p = people[i]
                if saved_id == p['id']:
                    preselect = i
                    break
            
        self.saved_data[group][people_key] = None if preselect == -1 else people[preselect]['id']
        self.save()
        return people, preselect
    
    def view_credits_find(self):
        dlg = Dialog()
        query = dlg.input(ls(33619)).strip()
        if not query:
            return
        q = get_search_string(query)
        people = [p for p in armani.get_people() if q in get_search_string(p['name'])]
        if not people:
            if not dlg.yesno('No Results', 'No names matching "%s" were found. Add a new name?' % query):
                return
            person = self.add_person(query, True, False)
            if person:
                view_credits(person)
        elif len(people) == 1:
            view_credits(people[0])
        else:
            i = armani_dialogs.menu('"%s"' % query, [p['name'] for p in people])
            if i < 0:
                return
            view_credits(people[i])
        
    def view_credits_job(self, people_key='all'):
        people, pre = self.get_people('viewing', people_key)
        if not people:
            notification('No people found')
            return
        
        i = armani_dialogs.menu(HEADINGS[people_key], [p['name'] for p in people], pre)
        if i < 0:
            return
        self.saved_data['viewing'][people_key] = people[i]['id']
        self.save()
        view_credits(people[i])
        
    def modify_people(self, people_key='all', selected_person=None):
        people, pre = self.get_people('editing', people_key, selected_person)
        if not people:
            return
        
        heading = HEADINGS[people_key]
        i = armani_dialogs.menu(heading, [p['name'] for p in people], pre)
        if i == -1:
            return
        self.modify_person(people[i])
        self.modify_people(people_key, people[i])

    def modify_person(self, person):
        armani.cursor.execute('SELECT title, year FROM media '
                              'WHERE %s ORDER by release_date' % get_person_where(person))
        titles = ['%s (%d)' % r for r in armani.cursor.fetchall()]
    
        i = Dialog().yesnocustom(
            person['name'],
            f'Job: {person["jobs"]}[CR]Number of titles: {len(titles)}[CR]Known for: {person["known_for"]}',
            'Delete', 'Edit', 'Add Titles')
        if i < 0:
            return
        elif i == 0:
            self.edit_person_table(person)
        elif i == 1:
            armani.imdb_add_person_credits(person)
        elif i == 2:
            delete_person(person)
            return
        self.modify_person(person)
        
    def edit_person_table(self, person, preselect=-1):
        from xbmcgui import ListItem
        fmt1 = '[COLOR white]%s[/COLOR]'
        fmt2 = '[COLOR lightyellow]%s[/COLOR]'
        dlg = Dialog()
        options = [
            ListItem(fmt1 % 'Name', fmt2 % person['name']),
            ListItem(fmt1 % 'Known For', fmt2 % person['known_for']),
            ListItem(fmt1 % 'Jobs', fmt2 % person['jobs'])
        ]
        i = armani_dialogs.double_line_menu(person['name'], options, preselect)
        if i < 0:
            return
        if i == 0:
            v = dlg.input('Name', person['name']).strip()
            if not v:
                return self.edit_person_table(person, i)
            armani.cursor.execute('UPDATE people SET name = ? WHERE imdb_id = ?', (v, person['id']))
            armani.conn.commit()
            person['name'] = v
        elif i == 1:
            v = dlg.input('Known For', person['known_for']).strip()
            if not v:
                return self.edit_person_table(person, i)
            armani.cursor.execute('UPDATE people SET known_for = ? WHERE imdb_id = ?', (v, person['id']))
            armani.conn.commit()
            person['known_for'] = v
        elif i == 2:
            edit_person_jobs(person)
            armani.cursor.execute('UPDATE people SET jobs = ? WHERE imdb_id = ?', (person['jobs'], person['id']))
            armani.conn.commit()
        
        self.edit_person_table(person, i)
        
    def add_person(self, default='', add_confirm=False, modify=True):
        person = imdb_person_search(default)
        if not person:
            return None
        found_person = armani.get_person(person['id'])
        if found_person:
            notification('%s already added' % found_person['name'])
            return found_person

        if add_confirm:
            armani.cursor.execute('SELECT COUNT(*) FROM media WHERE ' + get_person_where(person))
            num_titles = armani.cursor.fetchone()[0]
            if not Dialog().yesno(
                    person['name'], f'Add [B]{person["name"]}[/B] to the database?[CR]'
                                    f'(Number of titles: {num_titles})'):
                return None

        while 1:
            edit_person_jobs(person)
            if not person.get('jobs'):
                return None
            break

        armani.cursor.execute('INSERT INTO people VALUES(?, ?, ?, ?)',
                              (person['id'], person['name'], person['known_for'], person['jobs']))
        armani.conn.commit()
        notification('%s added' % person['name'])
        if modify:
            self.modify_person(person)
        return person
        