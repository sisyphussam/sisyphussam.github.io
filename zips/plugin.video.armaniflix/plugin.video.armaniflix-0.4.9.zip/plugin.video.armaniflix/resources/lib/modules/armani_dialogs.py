from xbmcgui import Dialog, ListItem
from xbmc import executebuiltin
from modules.kodi_utils import logger, local_string as ls, notification, close_all_dialog, build_url
from typing import List


def numeric(heading, message, default="", hidden=False) -> str:
    executebuiltin('SetProperty(numeric_header,%s,home)' % heading)
    value = Dialog().numeric(0, message, default, hidden)
    executebuiltin('ClearProperty(numeric_header,home)')
    return value


def _launch_menu(menu_name, heading, items, preselect, multi=False, use_details=False):
    if preselect is None:
        preselect = [] if multi else -1
    executebuiltin('SetProperty(select_type,%s,home)' % menu_name)
    if multi:
        ret = Dialog().multiselect(heading, items, 0, preselect, use_details)
    else:
        ret = Dialog().select(heading.upper(), items, 0, preselect, use_details)
    executebuiltin('ClearProperty(select_type,home)')
    return ret


def double_line_menu(heading, items, preselect=None, multi=False):
    menu_name = 'double%d' % min(8, len(items))
    return _launch_menu(menu_name, heading, items, preselect, multi)


def advanced_menu(heading, items, preselect=-1):
    fmt1 = '[COLOR white]%s[/COLOR]'
    fmt2 = '[COLOR lightyellow]%s[/COLOR]'
    list_items = [ListItem('[COLOR yellow]RESET[/COLOR]', '[COLOR grey]Restore defaults[/COLOR]')]
    list_items.extend([ListItem(fmt1 % i[0], fmt2 % str(i[1])) for i in items])
    return double_line_menu(heading, list_items, preselect)


def menu(heading, labels, preselect=None, multi=False):
    menu_name = 'menu%d' % min(11, len(labels))
    return _launch_menu(menu_name, heading, labels, preselect, multi)


def detail_menu(heading, items: List[ListItem], preselect=None, multi=False):
    menu_name = 'detail%d' % max(3, min(11, len(items)))
    return _launch_menu(menu_name, heading, items, preselect, multi, True)


def info_menu(heading, list_items, preselect=-1):
    executebuiltin('SetProperty(select_type,info_select,home)')
    i = Dialog().select(heading.upper(), list_items, 0, preselect)
    executebuiltin('ClearProperty(select_type,home)')
    return i


def alpha_menu(heading, labels, preselect=-1):
    import math
    num_rows = min(5, math.ceil(len(labels) / 6.0))
    menu_name = 'alpha%d' % num_rows
    return _launch_menu(menu_name, heading, labels, preselect)


def genre_menu(heading, labels, preselect=None, multi=False):
    import math
    num_rows = min(8, math.ceil(len(labels) / 4.0))
    menu_name = 'genres%d' % num_rows
    return _launch_menu(menu_name, heading, labels, preselect, multi)


def decade_menu(heading, labels, preselect, multi=False):
    import math
    num_rows = min(4, math.ceil(len(labels) / 4.0))
    menu_name = 'decades%d' % num_rows
    return _launch_menu(menu_name, heading, labels, preselect, multi)


def year_range(default_range=None, valid_years=None):
    from datetime import date
    from modules.armani_utils import int_to_bounds

    if not valid_years:
        valid_years = range(1900, 1 + date.today().year)

    if not default_range:
        min_year, max_year = valid_years[0], valid_years[-1]
    else:
        min_year = int_to_bounds(default_range[0], valid_years[0], valid_years[-1])
        max_year = int_to_bounds(default_range[1], valid_years[0], valid_years[-1])

    pre = -1 if min_year not in valid_years else valid_years.index(min_year)
    j = menu('Select First Year', [str(y) for y in valid_years], pre)
    if j < 0:
        return min_year, max_year
    min_year, max_year = valid_years[j], valid_years[-1]
    years = [y for y in valid_years if y >= min_year]
    if len(years) > 1:
        j = menu('Select Last Year', [str(y) for y in years])
        if j > -1:
            max_year = years[j]

    return min_year, max_year


def rating_range(min_rating=None):
    ratings = [0.0] + [i / 10.0 for i in range(50, 91)]
    max_rating = 10.0
    if min_rating not in ratings:
        min_rating = 0.0

    i = menu('Minimum Rating', [str(r) for r in ratings], ratings.index(min_rating))
    if i > -1:
        min_rating = ratings[i]
    if min_rating < 9.0:
        start_max = 50 if min_rating == 0.0 else int(min_rating * 10)
        max_ratings = [i / 10.0 for i in range(start_max, 91)] + [10]
        max_ratings.reverse()
        i = menu('Maximum Rating', [str(r) for r in max_ratings], 0)
        max_rating = 10.0 if i < 0 else max_ratings[i]

    if min_rating == 0.0:
        min_rating = None
    if max_rating == 10.0:
        max_rating = None

    return min_rating, max_rating


def vote_range():
    v = numeric('Minimum Vote Count', 'Blank for none')
    min_votes = None if not v else int(v)
    v = numeric('Maximum Vote Count', 'Blank for none')
    max_votes = None if not v else int(v)
    return min_votes, max_votes


def person_alpha(current_people=None):
    from caches.armani_media import armani
    people = armani.get_people()
    if current_people is None:
        current_people = []
    if current_people:
        people = [p for p in people if p['id'] not in (c['id'] for c in current_people)]
    alpha_list = list(dict.fromkeys(p['name'][0].upper() for p in people))

    i = -1
    while 1:
        i = alpha_menu('People', alpha_list, i)
        if i < 0:
            return None
        alpha = alpha_list[i]
        alpha_people = [p for p in people if p['name'].upper().startswith(alpha)]
        j = menu(f'People / {alpha}', [p['name'] for p in alpha_people])
        if j > -1:
            return alpha_people[j]

    
class MainMenu:
    def __init__(self):
        from caches.armani_media import armani
        from caches.armani_users import UserSettings
        self.__media = armani
        self.__save_key = 'home_menu'
        with UserSettings() as user_settings:
            self.home_menu = user_settings.get_json(self.__save_key)
            
    def __save(self):
        from caches.armani_users import UserSettings
        with UserSettings() as user_settings:
            user_settings.save_json(self.__save_key, self.home_menu)

    def media_alpha(self, db_type):
        if db_type == 'movie':
            title = 'Movie / A - Z'
        else:
            title = 'TV / A - Z'
        alpha = self.__media.get_existing_alpha(db_type)
        if not alpha:
            return
    
        options = alpha + ['All']
    
        i = self.__open_menu(title, options, alpha_menu, 'alpha_%s' % db_type)
        if i < 0:
            return
    
        where = 'WHERE db_type = "%s"' % db_type
        if i < len(alpha):
            a = alpha[i]
            where += ' AND starting_letter = "%s"' % a
        else:
            a = 'All Titles'
    
        title += ' / ' + a
        self.__launch_menu_item(title, where)
        
    def media_genre(self, db_type):
        if db_type == 'movie':
            title = 'Movies / Genres'
        else:
            title = 'TV / Genres'
        genres = self.__media.get_existing_genres(db_type)

        i = self.__open_menu(title, [g['name'] for g in genres], genre_menu, 'genres_%s' % db_type)
        if i < 0:
            return
        g = genres[i]
        where = 'WHERE db_type = "%s"' % db_type
        where += ' AND genre_ids LIKE "%' + g['id'] + '%"'
        title += ' / ' + g['name']
        self.__launch_menu_item(title, where)

    def media_decade(self, db_type):
        if db_type == 'movie':
            title = 'Movies / Decades'
        else:
            title = 'TV / Decades'
        decades = self.__media.get_existing_decades(db_type)
    
        i = self.__open_menu(title, ['%ds' % d for d in decades], decade_menu, 'decades_%s' % db_type)
        if i < 0:
            return
        d = decades[i]
        where = 'WHERE db_type = "%s"' % db_type
        where += ' AND decade = %d' % d
        title += ' / %d - %d' % (d, d + 9)
        self.__launch_menu_item(title, where)
        
    def people_alpha(self):
        p = self.__alpha_person('people_alpha')
        if not p:
            return
        self.__launch_menu_item(p['name'], 'WHERE ' + p['where'])
        
    def people_collaboration(self):
        def _select_person():
            alpha_list = list(dict.fromkeys(p['name'][0].upper() for p in new_people))
            while 1:
                _i = alpha_menu('Add Person', alpha_list)
                if _i < 0:
                    return
                _a = alpha_list[_i]
                _people = [_p for _p in new_people if _p['name'][0].upper() == _a]
                _i = menu('Add Person / %s' % _a, [_p['name'] for _p in _people])
                if _i > -1:
                    current_ids.append(_people[_i]['id'])
                    return
                
        def _save():
            self.home_menu['people_collaboration'] = ','.join(current_ids)
            self.__save()

        s = self.home_menu.get('people_collaboration')
        all_people = self.__media.get_people()
        current_ids = [] if not s else [i.strip() for i in s.split(',')]
        fmt1, fmt2, fmt3 = '[COLOR white]%s[/COLOR]', '[COLOR lightgrey][I]%s[/I][/COLOR]', '[COLOR yellow]%s[/COLOR]'
        
        while 1:
            selected_people = [p for p in all_people if p['id'] in current_ids]
            new_people = [p for p in all_people if p['id'] not in current_ids]
            current_ids = [p['id'] for p in selected_people]  # get_people sorts names
            
            where_list = []
            for person_id in current_ids:
                s = '%<' + person_id + '>%'
                where_list.append('(cast_ids LIKE "%s" OR crew_ids LIKE "%s")' % (s, s))
            where = ''
            results = []
            if where_list and len(selected_people) > 1:
                where = 'WHERE ' + ' AND '.join(where_list)
                self.__media.cursor.execute('SELECT title FROM media %s' % where)
                results = [r[0] for r in self.__media.cursor.fetchall()]
                
            if selected_people:
                s_people = '[COLOR lightpink]%s[/COLOR]' % ', '.join(p['name'] for p in selected_people)
            else:
                s_people = fmt2 % 'Add two or more people'
        
            items = [
                ListItem(fmt1 % 'Add', s_people),
                ListItem(fmt1 % 'Remove', fmt2 % 'Delete names or start over')
            ]
            if len(current_ids) > 1:
                items.append(ListItem(fmt3 % 'VIEW RESULTS', fmt2 % '%d matches' % len(results)))
            
            i = double_line_menu('PEOPLE WORKING TOGETHER', items, 2 if results else 0)
            
            if i < 0:
                _save()
                return
            if i == 0:
                _select_person()
            elif i == 1:
                if len(current_ids) == 1:
                    current_ids = []
                elif len(current_ids) > 1:
                    sel = menu('Remove People', [p['name'] for p in selected_people], [], True)
                    if sel:
                        for index in sorted(sel, reverse=True):
                            del current_ids[index]
            else:
                if not results:
                    notification('No matches')
                else:
                    _save()
                    title = ', '.join(p['name'] for p in selected_people)
                    self.__launch_menu_item(title, where)
                    return
            
    def __alpha_person(self, alpha_key):
        people = self.__media.get_people()
        alpha_list = list(dict.fromkeys(p['name'][0].upper() for p in people))
        i = self.__open_menu('People', alpha_list, alpha_menu, alpha_key)
        if i < 0:
            return None
        a = alpha_list[i]
        people = [p for p in people if p['name'][0].upper() == a]
        i = self.__open_menu(f'People / {a}', [p['name'] for p in people], menu, f'{alpha_key}_{a}')
        if i < 0:
            return self.__alpha_person(alpha_key)
    
        person = people[i]
        s = '%<' + person['id'] + '>%'
        return {'name': person['name'], 'where': 'cast_ids LIKE "%s" OR crew_ids LIKE "%s"' % (s, s)}
        
    def __launch_menu_item(self, title, where):
        self.__media.cursor.execute('SELECT * FROM media %s LIMIT 1' % where)
        if not self.__media.cursor.fetchall():
            notification('No titles found')
            return
    
        url = {'mode': 'armani_fetch', 'where': where, 'armani_title': title}
        close_all_dialog()
        executebuiltin('RunPlugin(%s)' % build_url(url))

    def __open_menu(self, heading, options, menu_func, index_key) -> int:
        if not options:
            return -1
        pre = self.home_menu.get(index_key) or -1

        i = menu_func(heading, options, pre)
        if i < 0:
            return -1
        self.home_menu[index_key] = i
        self.__save()
        return i
    
    
class SearchDialog:
    def __init__(self):
        from caches.armani_users import UserSettings
        with UserSettings() as user_settings:
            self.__advanced_search_data = user_settings.get_json('advanced_search')
            self.__search_history = user_settings.get_json('search_history') or {
                'title': [], 'person': []
            }
        if not self.__advanced_search_data:
            self.__reset_advanced_search()
            
    def __save_search_history(self):
        from caches.armani_users import UserSettings
        self.__search_history['title'] = self.__search_history['title'][0:10]
        self.__search_history['person'] = self.__search_history['person'][0:10]
        with UserSettings() as user_settings:
            user_settings.save_json('search_history', self.__search_history)

    def title_search(self, default=''):
        import json
        
        def _search():
            close_all_dialog()
            url_params = build_url({'mode': 'build_armani_results', 'armani_title': f'"{title.upper()}"',
                                    'fetch_params': json.dumps({'query': title})})
            executebuiltin('ActivateWindow(Videos,%s,return)' % url_params)
            self.__search_history['title'].insert(0, title)
            self.__search_history['title'] = list(dict.fromkeys(self.__search_history['title']))
            self.__save_search_history()

        history = self.__search_history['title']
        if history:
            i = menu('Find a Title', ['[COLOR yellow][NEW SEARCH][/COLOR]'] + history)
            if i < 0:
                return
            if i > 0:
                title = history[i - 1]
                return _search()
        
        title = Dialog().input(ls(33620), default).strip()
        if title:
            _search()
        
    def person_search(self):
        from caches.armani_media import armani
        from modules.armani_utils import get_search_string
        from caches.armani_people import ArmaniPeople, view_credits
        
        def _save(_person):
            if _person['id'] in [p['id'] for p in self.__search_history['person']]:
                self.__search_history['person'].remove(_person)
            self.__search_history['person'].insert(0, _person)
            self.__save_search_history()
            
        history = self.__search_history['person']
        if history:
            i = menu('Find a Person', ['[COLOR yellow][NEW SEARCH][/COLOR]'] + [p['name'] for p in history])
            if i < 0:
                return
            if i > 0:
                person = history[i - 1]
                _save(person)
                view_credits(person)
                return
        
        query = Dialog().input(ls(33619)).strip()
        if not query:
            return
        q = get_search_string(query)
        people = [p for p in armani.get_people() if q in get_search_string(p['name'])]
        if not people:
            if not Dialog().yesno('No Results', 'No names matching "%s" were found. Add a new name?' % query):
                return
            person = ArmaniPeople().add_person(query, True, True)
            if person:
                _save(person)
                view_credits(person)
        elif len(people) == 1:
            _save(people[0])
            view_credits(people[0])
        else:
            i = menu('"%s"' % query, [p['name'] for p in people])
            if i < 0:
                return
            _save(people[i])
            view_credits(people[i])

    def advanced_search(self):
        from caches.armani_media import armani
        from modules.armani_utils import get_language_items
    
        get_language_items()
    
        fmt1 = '[COLOR white]%s[/COLOR]'
        fmt2 = '[COLOR lightyellow]%s[/COLOR]'
    
        adv_values = {
            'media_type': self.__get_advanced_media_types(),
            'language': self.__get_advanced_language(),
            'years': self.__get_advanced_years(),
            'mpaa': self.__get_advanced_mpaa(),
            'rating': self.__get_advanced_rating(),
            'genres': self.__get_advanced_genres(),
            'people': self.__get_advanced_people()
        }
    
        sort_order = self.__get_advanced_sort()
        executebuiltin('SetFocus(30000)')
        i = -1
        while 1:
            where_list = ['(%s)' % v['where'] for v in adv_values.values() if v['where']]
            if not where_list:
                num_results = 0
            else:
                armani.cursor.execute(f'SELECT COUNT(*) FROM media WHERE {" AND ".join(where_list)}')
                num_results = armani.cursor.fetchone()[0]
        
            items = [
                ListItem('[COLOR yellow]SEARCH[/COLOR]', f'[COLOR lightyellow]{num_results} titles[/COLOR]'),
                ListItem(fmt1 % 'Type', fmt2 % adv_values['media_type']['string']),
                ListItem(fmt1 % 'Language', fmt2 % adv_values['language']['string']),
                ListItem(fmt1 % 'Release Date', fmt2 % adv_values['years']['string']),
                ListItem(fmt1 % 'Certificate', fmt2 % adv_values['mpaa']['string']),
                ListItem(fmt1 % 'IMDb Rating', fmt2 % adv_values['rating']['string']),
                ListItem(fmt1 % 'Genres', fmt2 % adv_values['genres']['string']),
                ListItem(fmt1 % 'People', fmt2 % adv_values['people']['string']),
                ListItem(fmt1 % 'Sort By', fmt2 % sort_order['string']),
                ListItem('[COLOR tomato]RESET[/COLOR]'),
            ]
        
            i = detail_menu('Advanced Search', items, i)
            if i < 0:
                executebuiltin('SetFocus(8001)')
                return
            if i == 0:
                if num_results == 0:
                    notification('No Results')
                    continue
                break
            elif i == 1:
                adv_values['media_type'] = self.__advanced_media_type()
            elif i == 2:
                adv_values['language'] = self.__advanced_language()
            elif i == 3:
                adv_values['years'] = self.__advanced_years()
            elif i == 4:
                adv_values['mpaa'] = self.__advanced_mpaa()
            elif i == 5:
                adv_values['rating'] = self.__advanced_rating()
            elif i == 6:
                adv_values['genres'] = self.__advanced_genres()
            elif i == 7:
                adv_values['people'] = self.__advanced_people()
            elif i == 8:
                sort_order = self.__advanced_sort()
            else:
                self.__reset_advanced_search()
                return self.advanced_search()
    
        executebuiltin('SetFocus(8001)')

        window_action = 'ActivateWindow(Videos,%s,return)'
        close_all_dialog()
        executebuiltin(window_action % build_url({'mode': 'build_armani_results',
                                                  'armani_title': 'Advanced Search Results',
                                                  'where': 'WHERE ' + ' AND '.join(where_list),
                                                  'sort': sort_order['sort']}))
    
    def __reset_advanced_search(self):
        from caches.armani_users import UserSettings
        data = {
            'filters': {},
            'sort': {'string': 'Title', 'sort': 'sort_title, release_date'}
        }
        with UserSettings() as user_settings:
            user_settings.save_json('advanced_search', data)
        self.__advanced_search_data = data
    
    def __save_advanced_search(self):
        from caches.armani_users import UserSettings
        with UserSettings() as user_settings:
            user_settings.save_json('advanced_search', self.__advanced_search_data)
    
    def __get_advanced_media_types(self):
        return self.__advanced_search_data['filters'].get('media_type') or {
            'string': 'All', 'where': ''
        }
    
    def __get_advanced_language(self):
        return self.__advanced_search_data['filters'].get('language') or {
            'string': 'All', 'where': ''
        }
    
    def __get_advanced_years(self):
        from datetime import date
        y = date.today().year
        
        return self.__advanced_search_data['filters'].get('years') or {
            'string': '1900 - %d' % y, 'where': '', 'min_year': 1900, 'max_year': y
        }
    
    def __get_advanced_rating(self):
        return self.__advanced_search_data['filters'].get('rating') or {
            'string': '0 - 10 (0 - Max)', 'where': '',
            'min_rating': None, 'max_rating': None, 'min_votes': None, 'max_votes': None
        }
    
    def __get_advanced_genres(self):
        return self.__advanced_search_data['filters'].get('genres') or {
            'string': 'Any', 'where': '', 'any': [], 'all': [], 'none': []
        }
    
    def __get_advanced_people(self):
        return self.__advanced_search_data['filters'].get('people') or {
            'string': 'None', 'where': '', 'people': [], 'collaboration': False
        }
    
    def __get_advanced_mpaa(self):
        return self.__advanced_search_data['filters'].get('mpaa') or {
            'string': 'Any', 'where': ''
        }
    
    def __get_advanced_sort(self):
        return self.__advanced_search_data['sort'] or {
            'string': 'Title', 'sort': 'sort_title, release_date'
        }
    
    def __advanced_sort(self):
        sorts = {
            'Title': 'sort_title, release_date',
            'Newest': 'release_date DESC, sort_title',
            'Oldest': 'release_date, sort_title',
            'Highest Rated': 'rating DESC, votes DESC',
            'Lowest Rated': 'rating, votes',
            'Most Votes': 'votes DESC, sort_title',
            'Fewest Votes': 'votes, sort_title'
        }
        sort_keys = list(sorts.keys())
        saved = self.__get_advanced_sort()
        saved_sort = saved['string']
        if saved_sort not in sorts:
            saved_sort = 'Title'
        
        i = menu('Sort By', sort_keys, sort_keys.index(saved_sort))
        if i > -1:
            saved_sort = sort_keys[i]
        saved.update({'string': saved_sort, 'sort': sorts[saved_sort]})
        self.__advanced_search_data['sort'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_media_type(self):
        media_types = {
            'All': '',
            'Movies': 'db_type == "movie"',
            'TV Shows': 'db_type == "tvshow"',
            'Returning Series': 'db_type == "tvshow" AND status == "Returning Series"',
            'Completed Series': 'db_type == "tvshow" AND status != "Returning Series"'
        }
        media_type_keys = list(media_types.keys())
        saved = self.__get_advanced_media_types()
        media_type = saved['string']
        if media_type not in media_types:
            media_type = 'All'
        
        i = menu('Media Type', media_type_keys, media_type_keys.index(media_type))
        if i > -1:
            media_type = media_type_keys[i]
        saved.update({'string': media_type, 'where': media_types[media_type]})
        self.__advanced_search_data['filters']['media_type'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_language(self):
        from modules.armani_utils import get_language_items
        languages = get_language_items(False)
        language_keys = list(languages.keys())
        saved = self.__get_advanced_language()
        language = saved['string']
        if language not in languages:
            language = 'All'
        
        i = menu('Language', [v for v in language_keys], language_keys.index(language))
        if i > -1:
            language = language_keys[i]
        saved.update({'string': language, 'where': languages[language]})
        self.__advanced_search_data['filters']['language'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_years(self):
        from caches.armani_media import armani
        saved = self.__get_advanced_years()
        try:
            min_year = int(saved.get('min_year') or '0')
            max_year = int(saved.get('max_year') or '0')
        except ValueError:
            min_year, max_year = 0, 0
        
        armani.cursor.execute('SELECT DISTINCT year FROM media ORDER BY year')
        valid_years = [r[0] for r in armani.cursor.fetchall()]
        
        min_year, max_year = year_range((min_year, max_year), valid_years)
        where = []
        if min_year:
            where.append(f'year >= {min_year}')
        if max_year:
            where.append(f'year <= {max_year}')
        saved.update({'string': f'{min_year or "1900"} - {max_year or "Now"}',
                      'where': '' if not where else ' AND '.join(where),
                      'min_year': min_year, 'max_year': max_year})
        self.__advanced_search_data['filters']['years'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_mpaa(self):
        saved = self.__get_advanced_mpaa()
        items = {
            'Any': '',
            'No Rating': 'mpaa == "NR"',
            'G': 'mpaa IN ("G", "TV-Y", "TV-Y7", "TV-G")',
            'PG': 'mpaa IN ("PG", "TV-PG")',
            'PG-13': 'mpaa IN ("PG-13", "TV-14")',
            'R': 'mpaa IN ("R", "TV-MA")',
            'NC-17': 'mpaa == "NC-17"'
        }
        mpaa_labels = list(items.keys())
        mpaa_where = list(items.values())
        
        pre = -1 if saved['string'] not in mpaa_labels else mpaa_labels.index(saved['string'])
        i = menu('Certificate', mpaa_labels, pre)
        if i < 0:
            return saved
        
        saved.update({'string': mpaa_labels[i], 'where': mpaa_where[i]})
        self.__advanced_search_data['filters']['mpaa'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_rating(self):
        saved = self.__get_advanced_rating()
        min_rating = saved.get('min_rating')
        max_rating = saved.get('max_rating')
        min_votes = saved.get('min_votes')
        max_votes = saved.get('max_votes')
        i = -1
        while 1:
            rating_string = f'{min_rating or 0.0} - {max_rating or 10.0}'
            vote_string = f'{min_votes or 0} - {max_votes or "MAX"}'
            items = [
                ['Rating', rating_string],
                ['Vote Count', vote_string]
            ]
            i = advanced_menu('IMDb Rating', items, i)
            if i < 0:
                break
            if i == 0:
                min_rating = max_rating = min_votes = max_votes = None
            elif i == 1:
                min_rating, max_rating = rating_range(min_rating)
            else:
                min_votes, max_votes = vote_range()
        
        where = []
        if min_rating:
            where.append(f'rating >= {min_rating}')
        if max_rating:
            where.append(f'rating <= {max_rating}')
        if min_votes:
            where.append(f'votes >= {min_votes}')
        if max_votes:
            where.append(f'votes <= {max_votes}')
        
        saved.update({
            'string': f'{rating_string} ({vote_string})',
            'where': '' if not where else ' AND '.join(where),
            'min_rating': min_rating, 'max_rating': max_rating,
            'min_votes': min_votes, 'max_votes': max_votes
        })
        self.__advanced_search_data['filters']['rating'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_genres(self):
        from caches.armani_media import armani
        saved = self.__get_advanced_genres()
        
        genres = armani.get_existing_genres()
        genre_ids = [g['id'] for g in genres]
        genre_names = [g['name'] for g in genres]
        genre_keys = ['any', 'all', 'none']
        genre_headings = ['Include ANY Genre', 'Include ALL Genres', 'Exclude Genres']
        for k in ('any', 'all', 'none'):
            saved[k] = [g for g in saved[k] if g in genre_ids]
        
        i = -1
        while 1:
            genre_indices = {'any': [genre_ids.index(g) for g in saved['any']],
                             'all': [genre_ids.index(g) for g in saved['all']],
                             'none': [genre_ids.index(g) for g in saved['none']]}
            
            items = [
                ['Any', ', '.join(genre_names[j] for j in genre_indices['any']) or 'None'],
                ['All', ', '.join(genre_names[j] for j in genre_indices['all']) or 'None'],
                ['Exclude', ', '.join(genre_names[j] for j in genre_indices['none']) or 'None']
            ]
            i = advanced_menu('Genres', items, i)
            
            if i < 0:
                break
            if i == 0:
                saved.update({'any': [], 'all': [], 'none': []})
            else:
                genre_key, genre_heading = genre_keys[i - 1], genre_headings[i - 1]
                pre = [genre_ids.index(g) for g in saved[genre_key]]
                sel = genre_menu(genre_heading, genre_names, pre, True)
                if sel is None:
                    continue
                saved[genre_key] = [genre_ids[i] for i in sel]
        
        strings = []
        where = []
        if genre_indices['any']:
            strings.append('ANY(%s)' % ','.join(genre_names[i] for i in genre_indices['any']))
            where.append('(%s)' % (' OR '.join('genre_ids LIKE "%s"' % ('%' + g + '%') for g in saved['any'])))
        if genre_indices['all']:
            strings.append('ALL(%s)' % ','.join(genre_names[i] for i in genre_indices['all']))
            where.append(' AND '.join('genre_ids LIKE "%s"' % ('%' + g + '%') for g in saved['all']))
        if genre_indices['none']:
            strings.append('EXCLUDE(%s)' % ','.join(genre_names[i] for i in genre_indices['none']))
            where.append(' AND '.join('genre_ids NOT LIKE "%s"' % ('%' + g + '%') for g in saved['none']))
        
        saved.update({'string': ' | '.join(strings) or 'None', 'where': ' AND '.join(where) or ''})
        self.__advanced_search_data['filters']['genres'] = saved
        self.__save_advanced_search()
        return saved
    
    def __advanced_people(self):
        saved = self.__get_advanced_people()
        
        saved_people = saved.get('people', [])
        collaboration = saved.get('collaboration', False)
        i = -1
        while 1:
            items = [
                ['Add Person', ', '.join(p['name'] for p in saved_people) or 'None'],
                ['Remove People', f'{len(saved_people)} people added'],
                ['Collaboration', str(collaboration)]
            ]
            i = advanced_menu('People', items, i)
            if i < 0:
                break
            if i == 0:
                saved_people = []
            elif i == 1:
                person = person_alpha(saved_people)
                if person:
                    saved_people.append(person)
                    saved_people.sort(key=lambda k: k['name'])
            elif i == 2:
                if not saved_people:
                    continue
                if len(saved_people) == 1:
                    saved_people = []
                else:
                    sel = menu('Remove People', [p['name'] for p in saved_people], [], True)
                    if sel:
                        delete_ids = [saved_people[i]['id'] for i in sel]
                        saved_people = [p for p in saved_people if p['id'] not in delete_ids]
            else:
                collaboration = not collaboration
        
        strings = []
        where = []
        joiner = ' AND ' if collaboration else ' OR '
        for p in saved_people:
            s_id = '%<' + p['id'] + '>%'
            where.append(f'(cast_ids LIKE "{s_id}" OR crew_ids LIKE "{s_id}")')
            strings.append(p['name'])
        
        saved = {
            'string': joiner.join(strings) or 'None',
            'where': joiner.join(where),
            'people': saved_people,
            'collaboration': collaboration
        }
        self.__advanced_search_data['filters']['people'] = saved
        self.__save_advanced_search()
        return saved
    