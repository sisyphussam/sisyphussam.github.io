import sqlite3
from xbmcvfs import translatePath
import json

import modules.kodi_utils

SETTINGS_DB = translatePath('special://profile/addon_data/plugin.video.armaniflix/armani_settings.db')


class ArmaniSettings:
    def __init__(self):
        self.conn = sqlite3.connect(SETTINGS_DB)
        self.cursor = self.conn.cursor()
        
    def get(self, setting_id: str):
        self.cursor.execute('SELECT value FROM settings WHERE id = ?', (setting_id,))
        result = self.cursor.fetchone()
        if not result:
            return None
        return result[0]
    
    def get_json(self, setting_id: str):
        return json.loads(self.get(setting_id) or "{}")
    
    def is_source(self, imdb_id, hash_string):
        self.cursor.execute('SELECT COUNT(*) FROM sources WHERE imdb_id = ? AND hash = ?', (imdb_id, hash_string))
        result = self.cursor.fetchone()
        return result[0] > 0
    
    def set_source(self, imdb_id, hash_string):
        self.cursor.execute('INSERT OR REPLACE INTO sources (imdb_id, hash) VALUES(?, ?)', (imdb_id, hash_string))
        self.conn.commit()
        
    def get_user(self):
        return self.get('user_id'), self.get('user_name')
    
    def set_user(self, user_id: str, user_name: str):
        self.save('user_id', user_id)
        self.save('user_name', user_name)
        
    def save(self, setting_id: str, setting_value: str):
        self.cursor.execute('INSERT OR REPLACE INTO settings(id, value) VALUES(?, ?)', (setting_id, setting_value))
        self.conn.commit()
        
    def save_json(self, setting_id: str, setting_json: dict):
        self.save(setting_id, json.dumps(setting_json))